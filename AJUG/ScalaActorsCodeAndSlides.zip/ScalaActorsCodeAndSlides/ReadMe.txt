PrimeFinderApp is a somewhat contrived but illustrative example of the use 
of Scala actors to concurrently determine for some set of numbers, which
are prime and which are composite. Progressive results are displayed on
a bar graph. 

The program also served as a way to explore Scala features such as:

o traits;
o pattern matching and case classes;
o pre-condition checking with 'require';
o integration with external Java libraries (JFreeChart);
o where it makes sense to use mutable data structures, e.g. in order to 
  avoid resource exhaustion;
o the ScalaTest framework for unit testing.

The program has dependencies upon 3 libraries apart from Scala itself. 
The first two:

  o jcommon-1.0.16.jar
  o jfreechart-1.0.13.jar

are available from http://sourceforge.net/projects/jfreechart/files/. 
These two additional jars are all you need to run the program. 

The 3rd is scalatest-1.0.jar which is required for running the unit tests
and is available from:

  http://www.artima.com/scalatest/

I used the Scala Eclipse plugin for code and test:

  http://www.scala-lang.org/node/94
    
Scala 2.7.7 has most recently been used for running the program and tests, 
but 2.7.3-final onward should be fine. See http://www.scala-lang.org/downloads.

Compared to most of my AJUG talks, the accompanying slides are fairly
light on detail. See also:

o A short Actors tutorial: http://www.scala-lang.org/node/242
o Odersky, Spoon, Venners, 2008, Programming Scala, Artima
o http://codemonkeyism.com/want-erlang-concurrency-but-are-stuck-with-java-4-alternatives/
o http://www.javaworld.com/javaworld/jw-03-2009/jw-03-actor-concurrency2.html
o http://en.wikipedia.org/wiki/Actor_model
    
Questions and comments to dbenn@computer.org

December 2009