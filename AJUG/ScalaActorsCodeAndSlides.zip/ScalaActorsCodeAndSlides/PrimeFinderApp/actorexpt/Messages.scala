package actorexpt

import scala.actors.Actor

/**
 * Prime checker messages.
 */

case class CheckPrime(num : Int, smallerNumList : List[Int], resultReceiver : Actor)

case class PrimenessResult(num : Int, isPrime : Boolean, resultSender : PrimeCheckerActor)

case class StartFinding()

case class CreateChartGUI(coordinator : PrimeCoordinator)

case class UpdateChart(actorIndex : Int, primesFound : Int, compositesFound : Int)

case class Finished(primeList : List[Int])

case class Quit()
