package actorexpt

// A trait that asks whether a number, N, is prime given
// a set of numbers smaller than it.

trait PrimeChecker {

  /**
   * Is N prime with respect to an ordered set of values 
   * less than N? 
   * 
   * This will be most efficient if each member of the set of 
   * numbers is prime and the square of the maximum value of 
   * that set is less than or equal to N.
   * 
   * The special case of the first prime is handled separately.
   * 
   * @param n The value whose primality is in question.
   * @param valsSmallerThanN The ordered set of values smaller than N.
   * @return True, if n is prime, False if not.
   */
  def isPrime(n : Int, valsSmallerThanN : List[Int]) : Boolean =
    return if (n == 2) true else valsSmallerThanN.filter(n % _ == 0).size == 0
}
