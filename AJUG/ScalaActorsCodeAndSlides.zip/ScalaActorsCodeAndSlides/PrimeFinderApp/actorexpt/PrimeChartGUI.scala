package actorexpt

import scala.actors.Actor

import org.jfree.chart.ChartFactory
import org.jfree.chart.ChartPanel
import org.jfree.chart.JFreeChart
import org.jfree.chart.axis.CategoryAxis
import org.jfree.chart.axis.CategoryLabelPositions
import org.jfree.chart.axis.NumberAxis
import org.jfree.chart.plot.CategoryPlot
import org.jfree.chart.plot.PlotOrientation
import org.jfree.chart.renderer.category.BarRenderer
import org.jfree.data.category.CategoryDataset
import org.jfree.data.category.DefaultCategoryDataset

import java.awt.Dimension

import javax.swing.JFrame

/**
 * A (JFreeChart) bar chart GUI to plot prime actor activities.
 * This class is also an actor. It receives chart update messages
 * and updates the chart accordingly.
 */
class PrimeChartGUI(numActors : Int) extends Actor {
    // Create a category dataset that has primes-found and composites
    // found categories for each of the number of specified actors.
      
    private val primesFoundCat = "Primes"
    private val compositesFoundCat = "Composites"
    private val actorPrefix = "actor "
    
    val dataset = new DefaultCategoryDataset

    
    for (i <- 1 to numActors) {    
      dataset.addValue(0, actorPrefix + i, primesFoundCat)
      dataset.addValue(0, actorPrefix + i, compositesFoundCat)
    }
        
    this.start()
        
    def act() {
      react {
        case CreateChartGUI(coordinator) => {
   
          val f = new JFrame()
          f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
          f.setSize(800, 600)
          
          val chartPanel = createChart()
          chartPanel.setPreferredSize(new Dimension((f.getWidth() * 0.75).toInt,
                                                    (f.getHeight() * 0.75).toInt))
          f.setContentPane(chartPanel)
          f.setVisible(true)
          
          Thread.sleep(2000) // TODO: instead use a window focus/state listener
          
          coordinator ! StartFinding
          
          act()
        }
       
        case UpdateChart(actorIndex : Int, primesFound : Int, compositesFound : Int) => {
          dataset.setValue(primesFound, actorPrefix + actorIndex, primesFoundCat)
          dataset.setValue(compositesFound, actorPrefix + actorIndex, compositesFoundCat)
          act()
        }
      }
    }
        
    private def createChart() : ChartPanel = {
      val chart = ChartFactory.createBarChart("Prime Checker Activity", // chart title
                                              "Actor",                  // domain axis label
                                              "Numbers Classified",     // range axis label
                                              dataset,                  // data
                                              PlotOrientation.VERTICAL, // orientation
                                              true,                     // include legend
                                              true,                     // tooltips?
                                              false                     // URLs?
                                             )
            
      return new ChartPanel(chart)
    }
}
