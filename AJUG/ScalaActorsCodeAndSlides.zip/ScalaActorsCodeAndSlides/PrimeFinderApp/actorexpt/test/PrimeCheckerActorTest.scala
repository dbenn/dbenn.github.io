package actorexpt.test

// scala.testing.SUnit is going away from Scala 2.8.0 so we'll 
// use ScalaTest (vs JUnit, TestNG etc) 

import org.scalatest._ 
import scala.actors.Actor

object PrimeCheckerActorTestRunner {
  def main(args : Array[String]) : Unit = {
    val suite = new PrimeCheckerActorTestSuite
    suite.execute()
  }
}

class PrimeCheckerActorTestSuite extends FunSuite { 
    test("Prime Checker Actor test 1: prime checker-receiver pair") {

      val candidate = 79

      // Create an actor to receive the prime result.
      val resultReceiverActor = new Actor {
        var finished : Boolean = false
        
        def act() {
          receive {
            case PrimenessResult(num, prime, resultSender) => {
              assert(resultSender.index == 1)
              assert(num == candidate)           
              assert(prime)
              assert(resultSender.primesFound == 1)
              assert(resultSender.compositesFound == 0)
              finished = true
            }
            
            case Quit => exit()
          }
       }
    }
    resultReceiverActor.start

    // Create and start the prime checking actor.
    val primeCheckerActor = new PrimeCheckerActor(1)
    primeCheckerActor.start
            
    // Ask actor if candidate is prime.
    val num = candidate
    primeCheckerActor ! CheckPrime(num, (2 until num).toList, resultReceiverActor)

    while (!resultReceiverActor.finished) { Thread.sleep(10) }
            
    primeCheckerActor ! Quit
    resultReceiverActor ! Quit
  }
}
