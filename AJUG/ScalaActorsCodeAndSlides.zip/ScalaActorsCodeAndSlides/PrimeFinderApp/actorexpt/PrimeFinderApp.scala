package actorexpt

import scala.actors.Actor

// The prime finder application driver.

object PrimeFinderApp extends Actor with Primes {
  
  val upperLimit = 4750
  val numCheckers = 7        
  val coordinator = new PrimeCoordinator(upperLimit, numCheckers, this)
  
  def main(args : Array[String]) : Unit = {
    this.start    
  }
  
  def act() {
    receive {
      case Finished(primeList) => {
        println("Found " + primeList.size + " primes up to " + upperLimit + ": " + primeList)
        val primesWePreparedEarlier = primesLessThan10000.takeWhile(_ <= upperLimit)
        println("There are " + primesWePreparedEarlier.size + " (pre-computed) primes up to " + upperLimit + ": " + primesWePreparedEarlier)
        assert(primeList.size == primesWePreparedEarlier.size)
        assert(primeList == primesWePreparedEarlier)
        exit()
      }
    }
  }
}
