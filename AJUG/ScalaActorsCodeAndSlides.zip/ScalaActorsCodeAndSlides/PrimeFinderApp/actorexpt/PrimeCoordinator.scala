package actorexpt

import scala.actors.Actor

import scala.collection.mutable.ArrayBuffer

// This class coordinates prime checker actors to find
// all prime numbers up to the specified maximum.

// Notes:
// - Can't pass previously found primes to checker actor because the
//   list would not be guaranteed to be exhaustive in the presence of 
//   concurrency.
  
class PrimeCoordinator(upperBound : Int, numCheckers : Int, driver : Actor) extends Actor {
  
  require(upperBound >= 2)
  require(numCheckers <= (upperBound-2))
  
  // The candidate values to be checked for primality.
  var candidates = (2 to upperBound).toList
  
  val checkers = new ArrayBuffer[PrimeCheckerActor]
  
  val resultsNeeded = candidates.size-checkers.size
  var resultCount = 0
  
  for (i <- 1 to numCheckers) {
    checkers += new PrimeCheckerActor(i)
  }
  
  println("** Created " + checkers.size + 
          " actors to find primes in the range 2.." + upperBound)
  
  // Start all the prime checker actors.
  checkers.foreach(checker => checker.start())

  // Numbers found to be prime.
  var primes : ArrayBuffer[Int] = new ArrayBuffer()
    
  // Create the chart GUI actor.
  val chartActor = new PrimeChartGUI(checkers.size)
  chartActor ! CreateChartGUI(this)
  
  this.start()
  
  def act() {
    react {
      // Assign an initial number to each prime checker actor.
      case StartFinding => {
        val firstNumsToBeChecked = candidates.take(checkers.size)
        val first = firstNumsToBeChecked.take(1).head
        
        firstNumsToBeChecked.foreach(i =>
          checkers(i-first) ! CheckPrime(i, (2 until i).toList, this))
          
        candidates = candidates.drop(checkers.size)
        
        act()
      }
   
      // A primeness checker actor has returned a result.
      case PrimenessResult(num, isPrime, checker) => {
        
        resultCount += 1
          
        if (isPrime) {
          this.primes += num
        }
        
        chartActor ! UpdateChart(checker.index, checker.primesFound, checker.compositesFound)
        
        if (resultCount == resultsNeeded) {
          // Send the correctly ordered primes to the driver, 
          // since they could be returned in any order by the 
          // checkers. Then tell ourselves to quit. 
          driver ! Finished(primes.toList.sort((x,y) => x < y))
          this ! Quit
        } else if (!candidates.isEmpty) {
          // There's still more numbers to check.
          val nextNum = candidates.take(1).head
          //checkers(i-first) ! CheckPrime(i, primes.toList.takeWhile(n => n*n <= i), this))
          // TODO: if primes.last squared is >= i, use primes list instead 
          checker ! CheckPrime(nextNum, (2 until nextNum).toList, this)
          this.candidates = this.candidates.drop(1)
        }
        
        act()
      }
      
      case Quit => {
        checkers.foreach(checker => checker ! Quit)
        println("** Coordinator exiting")
        exit()
      }
    }
  }
}
