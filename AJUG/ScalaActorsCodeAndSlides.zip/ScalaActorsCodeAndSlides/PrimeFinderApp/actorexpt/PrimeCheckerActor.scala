package actorexpt

import scala.actors.Actor

// An actor that checks the primeness of a number, N, given
// a list of numbers smaller than it, and another actor that 
// wants to be informed of the result. The intention is that
// the list will be all primes smaller than N.
  
class PrimeCheckerActor(actorIndex : Int) extends Actor with PrimeChecker {
  
  val index = actorIndex
  
  var primesFound = 0
  var compositesFound = 0
  
  def act() {
      react {
        case CheckPrime(num, numList, resultReceiver) => {
          val prime = isPrime(num, numList)
          if (prime) primesFound += 1 else compositesFound += 1
          resultReceiver ! PrimenessResult(num, prime, this)
          act()
        }
          
        case Quit => exit()
      }
    }
}
