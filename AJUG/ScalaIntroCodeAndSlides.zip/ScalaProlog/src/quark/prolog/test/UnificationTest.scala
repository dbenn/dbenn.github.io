package quark.prolog.test

// Unification UTs

// scala.testing.SUnit is going away from Scala 2.8.0 so we'll 
// use ScalaTest (vs JUnit, TestNG etc) 

import org.scalatest._ 
import quark.prolog._
import scala.collection.mutable.Map

object UnificationTestRunner {
  def main(args : Array[String]) : Unit = {
    val suite = new UnificationSuite
    suite.execute()
  }
}

class UnificationSuite extends FunSuite { 
   	test("Unification test 1") { 
   	  val srcTerm = new Term("boy(bill)")
   	  val destTerm = new Term("boy(frank)")
      val srcEnv = Map[String, String]()
      val destEnv = Map[String, String]()
      val unifier = new Unifier
      assert(unifier.unify(srcTerm, srcEnv, destTerm, destEnv) == false)
   	}

    test("Unification test 2") { 
      val srcTerm = new Term("boy(bill)")
   	  val destTerm = new Term("boy(bill)")
      val srcEnv = Map[String, String]()
      val destEnv = Map[String, String]()
      val unifier = new Unifier
      assert(unifier.unify(srcTerm, srcEnv, destTerm, destEnv) == true)
    }

    test("Unification test 3") { 
      val srcTerm = new Term("boy(frank)")
   	  val destTerm = new Term("boy(X)")
      val srcEnv = Map[String, String]()
      val destEnv = Map[String, String]("X" -> "bill")
      val unifier = new Unifier
      assert(unifier.unify(srcTerm, srcEnv, destTerm, destEnv) == false)
      assert(destEnv("X") == "bill")
    }

    test("Unification test 4") { 
      val srcTerm = new Term("boy(G)")
   	  val destTerm = new Term("boy(X)")
      val srcEnv = Map[String, String]()
      val destEnv = Map[String, String]()
      val unifier = new Unifier
      assert(unifier.unify(srcTerm, srcEnv, destTerm, destEnv) == true)
      assert(destEnv.size == 0)
    }

    test("Unification test 5") { 
      val srcTerm = new Term("boy(G)")
   	  val destTerm = new Term("boy(X)")
      val srcEnv = Map[String, String]("G" -> "frank")
      val destEnv = Map[String, String]()
      val unifier = new Unifier
      assert(unifier.unify(srcTerm, srcEnv, destTerm, destEnv) == true)
      assert(destEnv("X") == "frank")
    }
}
