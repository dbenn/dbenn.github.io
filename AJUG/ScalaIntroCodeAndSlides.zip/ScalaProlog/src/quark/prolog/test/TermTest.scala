package quark.prolog.test

// Term UTs

// scala.testing.SUnit is going away from Scala 2.8.0 so we'll 
// use ScalaTest (vs JUnit, TestNG etc) 

import org.scalatest._
import quark.prolog._

object TermTestRunner {
  def main(args : Array[String]) : Unit = {
    val suite = new TermSuite
    suite.execute()
  }
}

class TermSuite extends FunSuite { 
	test("Term with arity 1") { 
	    val term = new Term(" boy ( bill) ")
	    assert(term.toString() == "<Term: boy(bill)>")
    }

 	test("Term with arity 2") { 
 		val term = new Term("child(bill, joy)")
 		assert(term.toString() == "<Term: child(bill, joy)>")
    }

 	test("Term with missing second argument") { 
 	  try {
 		  val term = new Term("child(bill, )")
 		  println(term)
 	  } catch {
 	  	case ex: PrologError => {
 	  		assert(ex.mesg.startsWith("Fatal: Syntax error"))
 	     }
 	  }
 	}
}

