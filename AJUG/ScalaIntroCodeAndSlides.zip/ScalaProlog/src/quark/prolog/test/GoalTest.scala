package quark.prolog.test

// Goal UTs

// scala.testing.SUnit is going away from Scala 2.8.0 so we'll 
// use ScalaTest (vs JUnit, TestNG etc) 

import org.scalatest._ 
import quark.prolog._
import scala.collection.mutable.Map

object GoalTestRunner {
  def main(args : Array[String]) : Unit = {
    val suite = new GoalSuite
    suite.execute()
  }
}

class GoalSuite extends FunSuite { 
   	test("Goal test 1") { 
   		val rule = new Rule("child(X,Y) :- mother(Y,X)")
   		val parent = new Goal(rule)
 
   		assert(parent.parent == None)
   		assert(parent.env.isEmpty)
     
   		var env = Map[String, String]() // empty
   		val goal = new Goal(rule, parent, env)
  
   		assert(goal.rule == rule)
   		assert(goal.parent == Some(parent))
   		assert(goal.env == env) // structurally equivalent
   		assert(goal.index == 0)
     
   		// Further check that while goal.env and env are 
   		// structurally equivalent, they are also independent
   		// due to a deep copy within Goal. Note that mutable maps
        // are assumed!
   		var goalEnv = goal.env
   		goalEnv("a") = "b"
    	assert(goalEnv.keySet.size != env.keySet.size)
   	}
}
