package quark.prolog.test

// Rule UTs

// scala.testing.SUnit is going away from Scala 2.8.0 so we'll 
// use ScalaTest (vs JUnit, TestNG etc) 

import org.scalatest._ 
import quark.prolog._

object RuleTestRunner {
  def main(args : Array[String]) : Unit = {
    val suite = new RuleSuite
    suite.execute()
  }
}

class RuleSuite extends FunSuite { 
   	test("Rule with arity 2") { 
   		val rule = new Rule("child(X,Y) :- mother(Y,X)")
   		assert(rule.head.toString == "<Term: child(X, Y)>")
   		assert(rule.goals.length == 1)
   		assert(rule.goals(0).toString == "<Term: mother(Y, X)>") // use foreach
   		assert(rule.toString == "<Rule: <Term: child(X, Y)> :- <Term: mother(Y, X)>>")
   	}

   	test("Rule with a head but no goals") {
   	  val rule = new Rule("child(X,Y)")
      assert(rule.head.toString == "<Term: child(X, Y)>")
      assert(rule.goals.length == 0)
   	}
}

