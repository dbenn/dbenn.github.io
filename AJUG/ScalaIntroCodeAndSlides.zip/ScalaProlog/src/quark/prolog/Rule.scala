package quark.prolog

class Rule(str : String) extends Fatal {
  val fields = str.split("""\s*:\-\s*""")
  val head = new Term(fields(0))
  var goals = Array[Term]()
  
  if (fields.length == 2) {
    // Sub-goals separated by commas. If only one, will
    // end with ")" not "),"
    val rhs = fields(1).replaceAll("""\),""", ");")
    val rhsFields = rhs.split(""";""")
    goals = rhsFields.map(new Term(_))
    if (goals.length == 0) {
      fatal("Syntax error in rule's RHS '" + fields(1) + "'")
    }
  }
  
  override def toString() : String = goals.length match {
      case 0 => head.toString
      case _ => {
    	  val goalStr = goals(0) + (("" /: goals.drop(1)) (_+", "+_))
    	  "<Rule: " + head + " :- " + goalStr + ">"
      }
  }
}
