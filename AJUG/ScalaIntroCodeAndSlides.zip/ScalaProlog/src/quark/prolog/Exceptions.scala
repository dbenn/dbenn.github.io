package quark.prolog

class PrologError(msg : String) extends Exception {
  var mesg = msg
  
  override def toString() = msg
}
