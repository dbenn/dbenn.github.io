package quark.prolog

import scala.collection.mutable.Map

// This trait clones an environment.

trait EnvCloner {
  
	def copy(env : Map[String, String]) : 
	  Map[String, String] = {
    	var newEnv = Map[String, String]()
    	env.foreach(newEnv += _)
    	newEnv
	}
}
