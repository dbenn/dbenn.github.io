package quark.prolog

trait Fatal {
  def fatal(mesg : String) {
    throw new PrologError("Fatal: " + mesg)
  }
}
