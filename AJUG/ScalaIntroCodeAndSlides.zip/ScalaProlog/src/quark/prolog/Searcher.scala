package quark.prolog

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Queue

// TODO: create an abstract base class for all Searchers

class Searcher(rules : ArrayBuffer[Rule], unifier : Unifier) extends EnvCloner{

  def search(term : Term, trace : Boolean) {
    // Create a top-level goal to get started with.
    val goal = new Goal(new Rule("all(done):-x(y)"))
    goal.rule.goals = Array(term)
    val queue = new Queue[Goal]()
    queue.enqueue(goal)
    
    while (!queue.isEmpty) {
    	// Get next goal to be considered.
    	val curr = queue.dequeue
    	if (trace) println("dequeued " + curr)
    	// Is this goal finished?
    	if (curr.index >= curr.rule.goals.length) {
    	  // Yes. Top-level goal based upon original term?
    	  if (curr.parent == None) {
    	    // Yes. The current goal is not only complete but
    	    // has no parent goal. No more to do. Report solution.
    	    if (!curr.env.isEmpty) {
    	    	curr.env.keySet.foreach(key => {
    	    		printf("%s = %s\n", key, curr.env(key))
                  }
    	    	)
    	    } else {
    	    	println("Yes")
    	   	}
    	  } else {
    		// We're finished with the current goal, but the current
    	    // goal has a parent. Resume parent goal with copied env.
    	    val Some(aParentGoal) = curr.parent
    	    val parentGoal = aParentGoal.copy()
    	    unifier.unify(curr.rule.head, curr.env,
                       	  parentGoal.rule.goals(parentGoal.index),
    	    			  parentGoal.env)
    	    parentGoal.index += 1
    	    queue.enqueue(parentGoal)
          }
    	} else {
    	  // No, we aren't finished with the current goal yet.
    	  val term = curr.rule.goals(curr.index)
    	  // Walk down the rule-base until we find a rule-head that
    	  // matches the current goal term.
          var i = 0
          while (i < rules.length) {
            val rule = rules(i)
            i += 1
    	  //for (rule <- rules) {
    	    // TODO: add an equality operator: Rule.==(rule,term)
    	    if (rule.head.pred == term.pred &&
    	    	rule.head.args.length == term.args.length) {
    	    	// Create a sub-goal, try to unify it given the
    	    	// current environment. If it unifies, we queue
    	    	// up this child goal for further processing. 
    	    	val child = new Goal(rule, curr)
    	    	val unified = unifier.unify(term, curr.env,
    	    				  			    rule.head, child.env)
    	    	if (unified) {
    	    		queue.enqueue(child)
    	    	}
    	    }
    	  }
    	}
     }
  }  
}
