package quark.prolog

import scala.collection.mutable.Map

  // A Goal is a rule in at a certain point in its computation. 
  // env contains definitions (so far), index indexes the current term
  // being satisfied, parent is another Goal which spawned this one
  // and which we will unify back to when this Goal is complete.

  // TODO: create an abstract base class for all Unifiers

class Unifier {
  
   // Update dest env from src; return true if unification succeeds.    
  /**
   * Update dest env from src; return true if unification succeeds.   
   * 
   * @param srcTerm The source term (to be unified against the destTerm)
   * @param srcEnv The source environment
   * @param destTerm The target term for unification
   * @param destEnv The environment to be updated if unification succeeds
   * @return Whether or not unification succeeded
   */
   def unify(srcTerm : Term, srcEnv : Map[String, String],
  					destTerm : Term, destEnv : Map[String, String]) : Boolean = {
  				
    if (srcTerm.args.length != destTerm.args.length) return false
    if (srcTerm.pred != destTerm.pred) return false
    
    //val argRange = new Range(0, srcTerm.args.length, 1)
    // TODO: rewrite in a functional style

    var i = 0
    //for (i <- argRange) {
    while (i < srcTerm.args.length) {    
      val srcArg = srcTerm.args(i)
      val destArg = destTerm.args(i)
      
      val srcValue = srcArg match {
        // This is a variable, so return its value in the source env, or None.
        case s : String if (s >= "A" && s <= "Z") => {
          try {
        	  Some(srcEnv(srcArg))
          } catch {
            case _ => None
          }
        }
        
        // It's just a literal predicate argument.
        case _ => Some(srcArg)
      }
      
      if (srcValue != None) {
        val Some(srcVal) = srcValue
        if (destArg >= "A" && destArg <= "Z") {
          // This is a variable in the destination env.
          val destValue = try {
            Some(destEnv(destArg))
          } catch {
            case _ => None
          }
          
          if (destValue == None) {
            // The destination variable is not bound (in the dest env), so
            // we unify it with the source value obtained above.
            destEnv(destArg) = srcVal
          } else {
            // Otherwise, if the destination and source values don't match 
            // up, we won't unify. 
            val Some(destVal) = destValue
            if (destVal != srcVal) return false
          }
        } else if (destArg != srcVal) {
          // The destination argument is not equal to the source value
          // so we won't unify.
          return false
        }
      }
      
      i += 1
    }
    
    // If we get to this point, we've unified.
    return true
  }
}
