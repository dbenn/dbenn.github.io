package quark.prolog

import scala.util.matching.Regex

class Term (str : String) extends Fatal {
  var pred = "" 
  var args = Array[String]()
  
  val termPattern = """\s*(\w+)\s*\(\s*(.+)\s*\)\s*""".r
  val termPattern(predName, argStr) = str
  
  if (predName.length == 0 || argStr.length == 0) {
    fatal("Syntax error in term: '" + str + "'")
  } else {
    pred = predName
    val argsPattern = """^\w+(\s*,\s*\w+)*$""".r
    if ((argsPattern findFirstIn argStr) != None) {
      args = argStr.split("""\s*,\s*""")
    } else {
        fatal("Syntax error in term argument list: '" + argStr + "'")        
    }
  }
 
  override def toString() : String = {
    val argStr = args(0) + (("" /: args.drop(1)) (_+", "+_))
    return "<Term: " + pred + "(" + argStr + ")>"
  }
}
