// Prolog in Scala
// Equivalent of Prolog in Python http://openbookproject.net/py4fun/

// Notes:
// - Like the Python version, this is a simple Prolog implementation that only
//   permits facts with symbol (atom) arguments, classic Prolog rules and 
//   queries. Features such as numeric expressions, cuts, and grammar 
//   specification syntax are not supported.
// - This implementation differs from the Python version in that '?' is not 
//   used to denote a query, and in fact, a query may only be issued at the 
//   command-line.

// Future:
// - Improve upon Goal.copy(), make index private and add 2 funcs
// - Make response generation closer to standard Prolog.
// - Add more ScalaDoc -- see Unifier.scala for one example. :)
// - Add Design By Contract asserts, requires
// - Add a Searcher UT
// - Use ScalaCheck
// - Add a GUI
// - Use a Scala parser combinator instead of regex
// - Make functional anything remaining that is imperative.
  
package quark.prolog

import java.io.File
import scala.io.Source
import scala.util.matching.Regex
import scala.collection.mutable.ArrayBuffer

object Interp {  
  var rules = new ArrayBuffer[Rule]()
  val searcher = new Searcher(rules, new Unifier)
  var trace = false
  var mode = "ASSERT" // TODO: could use a case class instead
  
  def main(args : Array[String]) : Unit = {
	var finished = false
	var atStartup = true
 
	while (!finished) {
		try {
		  if (atStartup) {
			// Process optional init file.
			val initFile = "init.prl"
			if (new File(initFile).exists) {
				println("Processing " + initFile)
				for (line <- Source.fromFile(initFile).getLines)
					processLine(line)
			}
   
			// Process each file passed in as an argument.
			// If the argument "." is encountered, it forces an exit.
			for (arg <- args) {
				if (arg == ".")	quit
				println("Processing " + arg)
				for (line <- Source.fromFile(arg).getLines) 
					processLine(line)
			}
   
			atStartup = false
			mode = "QUERY"
		  }
		
		  // Process a line from standard input.
		  print("? ")
		  processLine(readLine())
		} catch {
			case ex: PrologError => println(ex.mesg) 
			case ex: MatchError => println(ex.getMessage)
 		}
    }
  }  
  
  private def processLine(line : String) {
    // Remove all whitespace and trailing linefeed.
    val str = line.replaceAll(" ","").replaceAll("\\.","").replaceAll("\n","")
    
    str match { 
    	// Ignore comments and empty lines.
    	case s : String if (("""^\s*\#""".r findFirstIn s) != None) => return
    	case s : String if (("""^\s*$""".r findFirstIn s) != None) => return
    	case "trace" => trace = !trace; return
    	case "dump" => dumpRules; return
    	case "quit" => quit
    	case _ => mode match {
    				case "ASSERT" => rules += new Rule(str)
    				case "QUERY" => searcher.search(new Term(str), trace)
    				case _ => throw new PrologError("Unknown mode!")
    			}
    } 
  }
  
  private def dumpRules() {
    rules.foreach(println)
  }
  
  private def quit() {
    println("Prolog exiting.")
    exit(1)
  }
}
