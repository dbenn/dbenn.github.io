package quark.prolog

import scala.collection.mutable.Map

class Goal(aRule : Rule, aParent : Option[Goal], 
           anEnv : Map[String, String]) extends Fatal with EnvCloner {
  // Public fields
  val rule = aRule
  val parent = aParent
  val env = copy(anEnv)  // deep copy
  var index = 0   // start search with first subgoal
  
  // Auxillary constructors
  def this(rule : Rule) = this(rule, None, Map[String, String]())
  
  def this(rule : Rule, parent : Goal) = 
    this(rule, Some(parent), Map[String, String]())
  
  def this(rule : Rule, parent : Goal, env : Map[String, String]) =
    this(rule, Some(parent), env)

  // TODO: instead override clone()?
  def copy() : Goal = {
    val oldIndex = index
    val newGoal = new Goal(rule, parent, copy(env))
    newGoal.index = oldIndex
    newGoal
  }
  
  override def toString() : String = {
    return "<Goal: " + rule + ":" + index + ":" + env + ">"
  }
}
