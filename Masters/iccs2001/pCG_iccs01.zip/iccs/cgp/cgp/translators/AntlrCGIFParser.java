// $ANTLR 2.7.0: "AntlrCGIFParser.g" -> "AntlrCGIFParser.java"$

    package cgp.translators;

	import antlr.SemanticException;

	import cgp.translators.ContextScope;
	import cgp.translators.ContextScopeStack;
	import cgp.translators.DefinedQuantifier;
	import cgp.translators.NumericQuantifier;

	import notio.Actor;
	import notio.Concept;
	import notio.ConceptAddError;
	import notio.ConceptReplaceException;
	import notio.ConceptType;
	import notio.ConceptTypeHierarchy;
	import notio.CopyingScheme;
	import notio.Designator;
	import notio.Graph;
	import notio.KnowledgeBase;
	import notio.LiteralDesignator;
	import notio.Macro;
	import notio.Marker;
	import notio.MarkerDesignator;
	import notio.MarkerSet;
	import notio.NameDesignator;
	import notio.Parser;
	import notio.QuantifierMacro;
	import notio.Referent;
	import notio.Relation;
	import notio.RelationAddError;
	import notio.RelationType;
	import notio.RelationTypeHierarchy;

	import java.util.ArrayList;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;
/**
 * A Notio CGIF parser for a conceptual graph language which embodies Guy
 * Mineau's process formalism.
 * Copyright (C) 2001 David Benn
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Note that this parser is based upon the modified June 2001 CG Standard 
 * found at: http://www.cs.nmsu.edu/~hdp/CGTools/cgstand/cgstandnmsu.html
 * This will be referred to as "The Standard" or "The CGIF Standard" herein. 
 *
 * All parser and lexer productions are preceded by the text from the 
 * aforementioned URL given for each production or its equivalent, although
 * the ordering may not be as found in that document depending upon what
 * makes sense for the ANTLR-based grammar. Notes and questions regarding
 * the original productions have been added.
 *
 * David Benn, June 2001
 */
public class AntlrCGIFParser extends antlr.LLkParser
       implements AntlrCGIFTokenTypes
 {

	// Extra instance fields.
    private CopyingScheme COPYING_SCHEME;
	private KnowledgeBase kBase;
	private ConceptTypeHierarchy conceptTypes;
	private RelationTypeHierarchy relationTypes;
	private ContextScopeStack contexts;
	
	// Constructor: also takes a KB.
	public AntlrCGIFParser(AntlrCGIFLexer lexer, KnowledgeBase kBase) {
		this(lexer);
		this.kBase = kBase;

		this.conceptTypes = kBase.getConceptTypeHierarchy();
		this.relationTypes = kBase.getRelationTypeHierarchy();
		
		COPYING_SCHEME = 
			new CopyingScheme(CopyingScheme.GR_COPY_DUPLICATE,
							  CopyingScheme.CN_COPY_DUPLICATE,
						      CopyingScheme.RN_COPY_DUPLICATE,
						      CopyingScheme.DG_COPY_DUPLICATE,
						      CopyingScheme.COMM_COPY_ON,
						      null);

		contexts = new ContextScopeStack();
		contexts.push(new ContextScope()); // top-level context scope
	}

protected AntlrCGIFParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public AntlrCGIFParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected AntlrCGIFParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public AntlrCGIFParser(TokenStream lexer) {
  this(lexer,1);
}

public AntlrCGIFParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final Actor  actor() throws RecognitionException, TokenStreamException {
		Actor a;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST actor_AST = null;
		
			a = null;
			String label = null;
			ArrayList inputs = new ArrayList();
			ArrayList outputs = new ArrayList();
			Concept c = null;
		
		
		AST tmp1_AST = null;
		if (inputState.guessing==0) {
			tmp1_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp1_AST);
		}
		match(LANGLE);
		label=type();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop3:
		do {
			if ((LA(1)==QUESTION||LA(1)==LBRACK)) {
				c=arc();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					inputs.add(c);
				}
			}
			else {
				break _loop3;
			}
			
		} while (true);
		}
		AST tmp2_AST = null;
		if (inputState.guessing==0) {
			tmp2_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp2_AST);
		}
		match(VERTBAR);
		{
		_loop5:
		do {
			if ((LA(1)==QUESTION||LA(1)==LBRACK)) {
				c=arc();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					outputs.add(c);
				}
			}
			else {
				break _loop5;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case COMMENT:
		{
			AST tmp3_AST = null;
			if (inputState.guessing==0) {
				tmp3_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp3_AST);
			}
			match(COMMENT);
			break;
		}
		case RANGLE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp4_AST = null;
		if (inputState.guessing==0) {
			tmp4_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp4_AST);
		}
		match(RANGLE);
		if ( inputState.guessing==0 ) {
			
								Concept[] in = (Concept[])inputs.toArray(new Concept[0]);
								Concept[] out = (Concept[])outputs.toArray(new Concept[0]);
								int valence = in.length + out.length;
								RelationType rt = relationTypes.getTypeByLabel(label);
								if (rt == null) {
									rt = new RelationType(label, valence);
									relationTypes.addTypeToHierarchy(rt);
								}
								a = new Actor(rt, in, out);
							
		}
		actor_AST = (AST)currentAST.root;
		returnAST = actor_AST;
		return a;
	}
	
	public final String  type() throws RecognitionException, TokenStreamException {
		String label;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_AST = null;
		AST str_AST = null;
		
			label = null;
		
		
		switch ( LA(1)) {
		case IDENTIFIER:
		{
			typeLabel();
			if (inputState.guessing==0) {
				str_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				label = str_AST.getText();
			}
			type_AST = (AST)currentAST.root;
			break;
		}
		case LPAREN:
		{
			typeExpression();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			type_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = type_AST;
		return label;
	}
	
	public final Concept  arc() throws RecognitionException, TokenStreamException {
		Concept c;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST arc_AST = null;
		
			c = null;
		
		
		switch ( LA(1)) {
		case LBRACK:
		{
			c=concept();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			arc_AST = (AST)currentAST.root;
			break;
		}
		case QUESTION:
		{
			c=boundLabel();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			arc_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = arc_AST;
		return c;
	}
	
	public final Concept  concept() throws RecognitionException, TokenStreamException {
		Concept c;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST concept_AST = null;
		
			// Get current context scope and push a new one
			// for this concept in case it turns out to be
			// a context. If it's not a context, no harm will
			// be done since it will simply not contain any
			// defining labels.
			ContextScope scope = contexts.peek();
			contexts.push(new ContextScope());
		
			// Concept and its components.
			c = new Concept();
			Concept bc = null; // bound concept from a coreference link
			String label = null;
			ConceptType ct = null;
			Referent r = null;
			Graph desc = null;
		String comment = null;
		
		
		AST tmp5_AST = null;
		if (inputState.guessing==0) {
			tmp5_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp5_AST);
		}
		match(LBRACK);
		{
		switch ( LA(1)) {
		case IDENTIFIER:
		case LPAREN:
		{
			label=type();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				
										// Set concept type, if a simple type name.
										// This is the only kind of type we'll handle
										// for now.
										if (label != null) {
											ct = conceptTypes.getTypeByLabel(label);
											if (ct == null) {
												ct = new ConceptType(label);
												conceptTypes.addTypeToHierarchy(ct);
											}
											c.setType(ct);
										}
									
			}
			break;
		}
		case COMMENT:
		case QUESTION:
		case RBRACK:
		case STAR:
		case COLON:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			
								// No concept type: Entity (Universal).
								if (ct == null) {
									ct = conceptTypes.getTypeByLabel("Universal");
									c.setType(ct);
								}
							
		}
		{
		boolean synPredMatched23 = false;
		if (((LA(1)==COLON))) {
			int _m23 = mark();
			synPredMatched23 = true;
			inputState.guessing++;
			try {
				{
				referent(c);
				corefLinks(scope, c);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched23 = false;
			}
			rewind(_m23);
			inputState.guessing--;
		}
		if ( synPredMatched23 ) {
			{
			referent(c);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			bc=corefLinks(scope, c);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			}
		}
		else {
			boolean synPredMatched26 = false;
			if (((LA(1)==QUESTION||LA(1)==STAR||LA(1)==COLON))) {
				int _m26 = mark();
				synPredMatched26 = true;
				inputState.guessing++;
				try {
					{
					corefLinks(scope, c);
					referent(c);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched26 = false;
				}
				rewind(_m26);
				inputState.guessing--;
			}
			if ( synPredMatched26 ) {
				{
				bc=corefLinks(scope, c);
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				referent(c);
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
			}
			else {
				boolean synPredMatched29 = false;
				if (((LA(1)==COLON))) {
					int _m29 = mark();
					synPredMatched29 = true;
					inputState.guessing++;
					try {
						{
						referent(c);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched29 = false;
					}
					rewind(_m29);
					inputState.guessing--;
				}
				if ( synPredMatched29 ) {
					referent(c);
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else if ((_tokenSet_0.member(LA(1)))) {
					bc=corefLinks(scope, c);
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else if ((LA(1)==COMMENT||LA(1)==RBRACK)) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}}
				}
				if ( inputState.guessing==0 ) {
					
										// A bound coreference label overrides the
										// newly created concept.
									    if (bc != null) c = bc;
									
				}
				{
				switch ( LA(1)) {
				case COMMENT:
				{
					AST tmp6_AST = null;
					if (inputState.guessing==0) {
						tmp6_AST = (AST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp6_AST);
					}
					match(COMMENT);
					break;
				}
				case RBRACK:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp7_AST = null;
				if (inputState.guessing==0) {
					tmp7_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp7_AST);
				}
				match(RBRACK);
				if ( inputState.guessing==0 ) {
					
								       contexts.pop(); // remove the current context's scope
								
				}
				concept_AST = (AST)currentAST.root;
				returnAST = concept_AST;
				return c;
			}
			
	public final Concept  boundLabel() throws RecognitionException, TokenStreamException {
		Concept c;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST boundLabel_AST = null;
		Token  label = null;
		AST label_AST = null;
		
			c = null;
		
		
		AST tmp8_AST = null;
		if (inputState.guessing==0) {
			tmp8_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp8_AST);
		}
		match(QUESTION);
		label = LT(1);
		if (inputState.guessing==0) {
			label_AST = (AST)astFactory.create(label);
			astFactory.addASTChild(currentAST, label_AST);
		}
		match(IDENTIFIER);
		if ( inputState.guessing==0 ) {
			
						       String id = label_AST.getText();
							   c = contexts.find(id);				  
							   if (c == null) {
								   throw new SemanticException("bound label '?"+id +
															   "' not found.");
							   }
						
		}
		boundLabel_AST = (AST)currentAST.root;
		returnAST = boundLabel_AST;
		return c;
	}
	
	public final Graph[]  cgStream() throws RecognitionException, TokenStreamException {
		Graph[] stream;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cgStream_AST = null;
		
			ArrayList list = new ArrayList();
			Graph g = null;
			stream = null;
		
		
		g=cg();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			if (!g.isBlank()) list.add(g);
		}
		{
		_loop11:
		do {
			if ((LA(1)==DOT)) {
				AST tmp9_AST = null;
				tmp9_AST = (AST)astFactory.create(LT(1));
				match(DOT);
				g=cg();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					if (!g.isBlank()) list.add(g);
				}
			}
			else {
				break _loop11;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			stream = (Graph[])list.toArray(new Graph[0]);
		}
		cgStream_AST = (AST)currentAST.root;
		returnAST = cgStream_AST;
		return stream;
	}
	
	public final Graph  cg() throws RecognitionException, TokenStreamException {
		Graph g;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cg_AST = null;
		Token  str = null;
		AST str_AST = null;
		
			g = new Graph();
			Actor a = null;
			Concept c = null;
			Object o = null;
			Relation r = null;
		
		
		{
		_loop18:
		do {
			switch ( LA(1)) {
			case LPAREN:
			{
				r=relation();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					
										try {
											g.addRelation(r); 
										} catch(ConceptAddError e) {
											// Notio says we have a reference to the same
											// concept in two different graphs, so copy all
										    // arguments just to be sure. Only happens when
											// adding a relation/actor to a graph not during
											// construction of the relation/actor.
											Concept[] args = r.getArguments();
											for (int i=0;i<args.length;i++) {
												r.replaceArgument(args[i],
																  args[i].copy(COPYING_SCHEME));
											}
											g.addRelation(r);
										} catch (RelationAddError e) {
									        // Should never happen because we new all relations
										    // unlike concepts which are sometimes taken from
										    // a symbol table via bound labels.
									    }
									
				}
				break;
			}
			case LANGLE:
			{
				a=actor();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					
										try {
											g.addRelation(a); 
										} catch(ConceptAddError e) {
											// Notio says we have a reference to the same
											// concept in two different graphs, so copy all
										    // arguments just to be sure. Only happens when
											// adding a relation/actor to a graph not during
											// construction of the relation/actor.
											Concept[] args = r.getArguments();
											for (int i=0;i<args.length;i++) {
												r.replaceArgument(args[i],
																  args[i].copy(COPYING_SCHEME));
											}
											g.addRelation(a);
										} catch (RelationAddError e) {
									        // Should never happen because we new all relations
										    // unlike concepts which are sometimes taken from
										    // a symbol table via bound labels.
									    }
									
				}
				break;
			}
			default:
				boolean synPredMatched15 = false;
				if (((LA(1)==NEGATION_PREFIX||LA(1)==LBRACK))) {
					int _m15 = mark();
					synPredMatched15 = true;
					inputState.guessing++;
					try {
						{
						match(NEGATION_PREFIX);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched15 = false;
					}
					rewind(_m15);
					inputState.guessing--;
				}
				if ( synPredMatched15 ) {
					specialContext(g);
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else {
					boolean synPredMatched17 = false;
					if (((LA(1)==NEGATION_PREFIX||LA(1)==LBRACK))) {
						int _m17 = mark();
						synPredMatched17 = true;
						inputState.guessing++;
						try {
							{
							match(LBRACK);
							specialConLabel();
							}
						}
						catch (RecognitionException pe) {
							synPredMatched17 = false;
						}
						rewind(_m17);
						inputState.guessing--;
					}
					if ( synPredMatched17 ) {
						specialContext(g);
						if (inputState.guessing==0) {
							astFactory.addASTChild(currentAST, returnAST);
						}
					}
					else if ((LA(1)==LBRACK)) {
						c=concept();
						if (inputState.guessing==0) {
							astFactory.addASTChild(currentAST, returnAST);
						}
						if ( inputState.guessing==0 ) {
							
												try {
											      g.addConcept(c);
												} catch (ConceptAddError e) {
													// Ignore for now. This was observed in the
													// context of examples/CGTools01/basic-info.cgp
													// when applied to Sowa's testmin.cgf CG stream.
												    // When a call to g.replaceGraph() was attempted
													// here, a stack overflow occurred, due to a deep 
													// exception stacking. In the case in question, 2
													// identical relations were being parsed from the
													// stream, so the upshot of ignoring this error in
													// that case is just that we end up with one relation
													// in the final output list, rather than 2, a 
													// desirable state of affairs. What worries me is
													// the cases I haven't seen that wouldn't turn out
													// so well, whatever they might be.
												}
											
						}
					}
					else if ((LA(1)==COMMENT)) {
						str = LT(1);
						if (inputState.guessing==0) {
							str_AST = (AST)astFactory.create(str);
							astFactory.addASTChild(currentAST, str_AST);
						}
						match(COMMENT);
						if ( inputState.guessing==0 ) {
							g.addComment(str_AST.getText());
						}
					}
				else {
					break _loop18;
				}
				}}
			} while (true);
			}
			cg_AST = (AST)currentAST.root;
			returnAST = cg_AST;
			return g;
		}
		
	public final void specialContext(
		Graph g
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST specialContext_AST = null;
		AST label_AST = null;
		
			Relation r = null;
			Graph desc = null;
		
		
		switch ( LA(1)) {
		case NEGATION_PREFIX:
		{
			r=negation();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				
								 try {
							       g.addRelation(r);
								 } catch(ConceptAddError e) {
									// Notio says we have a reference to the same
									// concept in two different graphs, so copy all
									// arguments just to be sure. Only happens when
									// adding a relation/actor to a graph not during
									// construction of the relation/actor.
									Concept[] args = r.getArguments();
									for (int i=0;i<args.length;i++) {
										r.replaceArgument(args[i],
														  args[i].copy(COPYING_SCHEME));
									}
									g.addRelation(r);
								 } catch (RelationAddError e) {
								    // Should never happen because we new all relations
									// unlike concepts which are sometimes taken from
									// a symbol table via bound labels.
								 }
							
			}
			specialContext_AST = (AST)currentAST.root;
			break;
		}
		case LBRACK:
		{
			AST tmp10_AST = null;
			if (inputState.guessing==0) {
				tmp10_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp10_AST);
			}
			match(LBRACK);
			specialConLabel();
			if (inputState.guessing==0) {
				label_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp11_AST = null;
			if (inputState.guessing==0) {
				tmp11_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp11_AST);
			}
			match(COLON);
			desc=cg();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp12_AST = null;
			if (inputState.guessing==0) {
				tmp12_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp12_AST);
			}
			match(RBRACK);
			if ( inputState.guessing==0 ) {
				
								   // Create a concept whose type is one of the special
								   // context labels, and whose referent is a descriptor.
								   String scLabel = label_AST.getText().toLowerCase();
							       ConceptType ct = conceptTypes.getTypeByLabel(scLabel);
								   if (ct == null) {
								       ct = new ConceptType(scLabel);
									   conceptTypes.addTypeToHierarchy(ct);				  
								   }
				
								   try {
							         g.addConcept(new Concept(ct, new Referent(desc)));
								   } catch (ConceptAddError e) {
									// Ignore this for now. See a *possibly* similar
									// scenario in the cg production.
								   }
							   	
			}
			specialContext_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = specialContext_AST;
	}
	
	public final void specialConLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST specialConLabel_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_if:
		{
			AST tmp13_AST = null;
			if (inputState.guessing==0) {
				tmp13_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp13_AST);
			}
			match(LITERAL_if);
			specialConLabel_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_then:
		{
			AST tmp14_AST = null;
			if (inputState.guessing==0) {
				tmp14_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp14_AST);
			}
			match(LITERAL_then);
			specialConLabel_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_either:
		{
			AST tmp15_AST = null;
			if (inputState.guessing==0) {
				tmp15_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp15_AST);
			}
			match(LITERAL_either);
			specialConLabel_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_or:
		{
			AST tmp16_AST = null;
			if (inputState.guessing==0) {
				tmp16_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp16_AST);
			}
			match(LITERAL_or);
			specialConLabel_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_sc:
		{
			AST tmp17_AST = null;
			if (inputState.guessing==0) {
				tmp17_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp17_AST);
			}
			match(LITERAL_sc);
			specialConLabel_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = specialConLabel_AST;
	}
	
	public final Relation  relation() throws RecognitionException, TokenStreamException {
		Relation r;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST relation_AST = null;
		
			r = null;
			String label = null;
			ArrayList argList = new ArrayList();
			Concept c = null;
		
		
		AST tmp18_AST = null;
		if (inputState.guessing==0) {
			tmp18_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp18_AST);
		}
		match(LPAREN);
		label=type();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop72:
		do {
			if ((LA(1)==QUESTION||LA(1)==LBRACK)) {
				c=arc();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					argList.add(c);
				}
			}
			else {
				break _loop72;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case COMMENT:
		{
			AST tmp19_AST = null;
			if (inputState.guessing==0) {
				tmp19_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp19_AST);
			}
			match(COMMENT);
			break;
		}
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp20_AST = null;
		if (inputState.guessing==0) {
			tmp20_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp20_AST);
		}
		match(RPAREN);
		if ( inputState.guessing==0 ) {
			
								// Create a relation given above type and arguments.
								Concept[] args=(Concept[])argList.toArray(new Concept[0]);
								RelationType rt = relationTypes.getTypeByLabel(label);
								if (rt == null) {
									rt = new RelationType(label, args.length);
									relationTypes.addTypeToHierarchy(rt);
								}
								r = new Relation(rt, args);
			
								// Add to type lattice. The currently active KB at the
								// time of parsing is the beneficiary of this, i.e. a
								// KnowledgeBase context doesn't in any sense create
								// a KB here. Only handle the greater-than relation
								// on types currently. Is this reasonable? This code
								// should probably be moved out of the parser. One may
								// also want to be able to turn this feature off.
								
								if (args.length == 2) {
								  String label1 = args[0].getType().getLabel();
								  String label2 = args[1].getType().getLabel();
								  if (label.equals("GT") && args.length == 2 &&
									(label1.equals("TypeLabel") &&
									 label2.equals("TypeLabel") ||
									 label1.equals("RelationLabel") &&
									 label2.equals("RelationLabel"))) {
									Referent ref1, ref2;
									Designator d1, d2;
									String t1, t2;
									String msg = "Invalid type designator.";
			
									ref1 = args[0].getReferent();
									d1 = ref1.getDesignator();
									if (d1 == null ||
										d1.getDesignatorKind() !=
										Designator.DESIGNATOR_LITERAL) {
										throw new SemanticException(msg);
									} else {
										Object o = ((LiteralDesignator)d1).getLiteral();
										if (o instanceof String) {
											t1 = (String)o;
										} else {
											throw new SemanticException(msg);
										}
									}
			
									ref2 = args[1].getReferent();
									d2 = ref2.getDesignator();
									Macro q = ref2.getQuantifier();
									if (d2 != null && d2.getDesignatorKind() ==
										Designator.DESIGNATOR_LITERAL) {
										Object o = ((LiteralDesignator)d2).getLiteral();
										if (o instanceof String) {
											// t1 > t2
											t2 = (String)o;
											if (label1.equals("TypeLabel")) {
											  ConceptType ct1;
											  ct1 = conceptTypes.getTypeByLabel(t1);
											  if (ct1 == null) {
												ct1 = new ConceptType(t1);
												conceptTypes.addTypeToHierarchy(ct1);
											  }
											  ConceptType ct2;
											  ct2 = conceptTypes.getTypeByLabel(t2);
											  if (ct2 == null) {
												ct2 = new ConceptType(t2);
												conceptTypes.addTypeToHierarchy(ct2);
											  }
											  conceptTypes.addSubTypeToType(ct1, ct2);
											} else {
											  RelationType rt1;
											  rt1 = relationTypes.getTypeByLabel(t1);
											  if (rt1 == null) {
												rt1 = new RelationType(t1);
												relationTypes.addTypeToHierarchy(rt1);
											  }
											  RelationType rt2;
											  rt2 = relationTypes.getTypeByLabel(t2) ;
											  if (rt2 == null) {
												rt2 = new RelationType(t2);
												relationTypes.addTypeToHierarchy(rt2);
											  }
											  relationTypes.addSubTypeToType(rt1, rt2);
											}
										} else {
											throw new SemanticException(msg);
										}
									} else if (q != null) {
										Macro macro = q;
										if (macro instanceof DefinedQuantifier) {
											Object[] res = macro.executeMacro(null);
											if (res != null) {
												// t1 > t2a, t2b, t2c ...
												ConceptType ct1 = null;
												RelationType rt1 = null;
												if (label1.equals("TypeLabel")) {
												  ct1 = conceptTypes.getTypeByLabel(t1);
												  if (ct1 == null) {
													ct1 = new ConceptType(t1);
													conceptTypes.addTypeToHierarchy(ct1);
												  }
												} else {
												  rt1 = relationTypes.getTypeByLabel(t1);
												  if (rt1 == null) {
													rt1 = new RelationType(t1);
													relationTypes.addTypeToHierarchy(rt1);
												  }
												}
			
												for (int i=0;i<res.length;i++) {
													t2 = (String)res[i];
													ConceptType ct2 = null;
													RelationType rt2 = null;
													if (label1.equals("TypeLabel")) {
												      ct2=conceptTypes.getTypeByLabel(t2);
												      if (ct2 == null) {
														ct2 = new ConceptType(t2);
														conceptTypes.
															addTypeToHierarchy(ct2);
													  }
													  conceptTypes.
													      addSubTypeToType(ct1, ct2);
													} else {
												      rt2=relationTypes.getTypeByLabel(t2);
												      if (rt2 == null) {
														rt2 = new RelationType(t2);
														relationTypes.
															addTypeToHierarchy(rt2);
													  }
													  relationTypes.
														  addSubTypeToType(rt1, rt2);
													}
												}
											} else {
												throw new SemanticException(msg);
											}
										} else {
											throw new SemanticException(msg);
										}
									} else {
										throw new SemanticException(msg);
									}
								  }
			}
							
		}
		relation_AST = (AST)currentAST.root;
		returnAST = relation_AST;
		return r;
	}
	
	public final void referent(
		Concept c
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST referent_AST = null;
		
			Referent r = new Referent(); // create a referent but only set it later
		
		
		AST tmp21_AST = null;
		if (inputState.guessing==0) {
			tmp21_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp21_AST);
		}
		match(COLON);
		if ( inputState.guessing==0 ) {
			c.setReferent(r);
		}
		{
		boolean synPredMatched63 = false;
		if (((_tokenSet_1.member(LA(1))))) {
			int _m63 = mark();
			synPredMatched63 = true;
			inputState.guessing++;
			try {
				{
				designator(r);
				descriptor(r);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched63 = false;
			}
			rewind(_m63);
			inputState.guessing--;
		}
		if ( synPredMatched63 ) {
			{
			designator(r);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			descriptor(r);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			}
		}
		else {
			boolean synPredMatched66 = false;
			if (((_tokenSet_2.member(LA(1))))) {
				int _m66 = mark();
				synPredMatched66 = true;
				inputState.guessing++;
				try {
					{
					descriptor(r);
					designator(r);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched66 = false;
				}
				rewind(_m66);
				inputState.guessing--;
			}
			if ( synPredMatched66 ) {
				{
				descriptor(r);
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				designator(r);
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
			}
			else {
				boolean synPredMatched69 = false;
				if (((_tokenSet_3.member(LA(1))))) {
					int _m69 = mark();
					synPredMatched69 = true;
					inputState.guessing++;
					try {
						{
						descriptor(r);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched69 = false;
					}
					rewind(_m69);
					inputState.guessing--;
				}
				if ( synPredMatched69 ) {
					descriptor(r);
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else if ((_tokenSet_1.member(LA(1)))) {
					designator(r);
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else if ((_tokenSet_0.member(LA(1)))) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}}
				}
				referent_AST = (AST)currentAST.root;
				returnAST = referent_AST;
			}
			
	public final Concept  corefLinks(
		ContextScope scope, Concept c
	) throws RecognitionException, TokenStreamException {
		Concept boundConcept;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST corefLinks_AST = null;
		
			Concept con = null;
			boundConcept = null;
			int count = 0;
		
		
		switch ( LA(1)) {
		case STAR:
		{
			defLabel(scope, c);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			corefLinks_AST = (AST)currentAST.root;
			break;
		}
		case COMMENT:
		case QUESTION:
		case RBRACK:
		case COLON:
		{
			{
			_loop36:
			do {
				if ((LA(1)==QUESTION)) {
					con=boundLabel();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					if ( inputState.guessing==0 ) {
						count++;
					}
				}
				else {
					break _loop36;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				
								   // Only take notice of this if there is one bound label,
								   // for now. This entails [?x] which is the same as ?x, 
								   // whereas I'm not clear about the meaning of something 
								   // like [?x ?y].
								   if (count == 1) {
								       boundConcept = con;
								   }
							
			}
			corefLinks_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = corefLinks_AST;
		return boundConcept;
	}
	
	public final void conjuncts() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST conjuncts_AST = null;
		
		typeTerm();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop33:
		do {
			if ((LA(1)==AMPERSAND)) {
				AST tmp22_AST = null;
				if (inputState.guessing==0) {
					tmp22_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp22_AST);
				}
				match(AMPERSAND);
				typeTerm();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop33;
			}
			
		} while (true);
		}
		conjuncts_AST = (AST)currentAST.root;
		returnAST = conjuncts_AST;
	}
	
	public final void typeTerm() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST typeTerm_AST = null;
		
			String label = null;
		
		
		{
		switch ( LA(1)) {
		case TILDE:
		{
			AST tmp23_AST = null;
			if (inputState.guessing==0) {
				tmp23_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp23_AST);
			}
			match(TILDE);
			break;
		}
		case IDENTIFIER:
		case LPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		label=type();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		typeTerm_AST = (AST)currentAST.root;
		returnAST = typeTerm_AST;
	}
	
	public final void defLabel(
		ContextScope enclosingContext, Concept theConcept
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST defLabel_AST = null;
		Token  label = null;
		AST label_AST = null;
		
		AST tmp24_AST = null;
		if (inputState.guessing==0) {
			tmp24_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp24_AST);
		}
		match(STAR);
		label = LT(1);
		if (inputState.guessing==0) {
			label_AST = (AST)astFactory.create(label);
			astFactory.addASTChild(currentAST, label_AST);
		}
		match(IDENTIFIER);
		if ( inputState.guessing==0 ) {
			
							   String id = label_AST.getText();
							   /*
								* Ignore such transgressions for now. In some cases
								* they actually make sense.
							   if (enclosingContext.get(id) != null) {
								   String msg = "label '*" + id + "' already defined " +
							                    "in this context.";
								   throw new SemanticException(msg);
							   }
							   */
							   enclosingContext.def(id, theConcept);
						
		}
		defLabel_AST = (AST)currentAST.root;
		returnAST = defLabel_AST;
	}
	
	public final void descriptor(
		Referent r
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST descriptor_AST = null;
		
			Graph desc = null;
		
		
		switch ( LA(1)) {
		case LBRACE:
		case PERCENT:
		{
			structure();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			descriptor_AST = (AST)currentAST.root;
			break;
		}
		case LANGLE:
		case COMMENT:
		case QUESTION:
		case NEGATION_PREFIX:
		case LBRACK:
		case RBRACK:
		case STAR:
		case HASH:
		case LPAREN:
		case QUOTEDSTR:
		case NAME:
		case INT_NUM:
		case FLOAT_NUM:
		case AT:
		{
			desc=cg();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				r.setDescriptor(desc);
			}
			descriptor_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = descriptor_AST;
	}
	
	public final void structure() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST structure_AST = null;
		
			Concept c = null;
		
		
		{
		switch ( LA(1)) {
		case PERCENT:
		{
			AST tmp25_AST = null;
			if (inputState.guessing==0) {
				tmp25_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp25_AST);
			}
			match(PERCENT);
			AST tmp26_AST = null;
			if (inputState.guessing==0) {
				tmp26_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp26_AST);
			}
			match(IDENTIFIER);
			break;
		}
		case LBRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp27_AST = null;
		if (inputState.guessing==0) {
			tmp27_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp27_AST);
		}
		match(LBRACE);
		{
		_loop83:
		do {
			if ((LA(1)==QUESTION||LA(1)==LBRACK)) {
				c=arc();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop83;
			}
			
		} while (true);
		}
		AST tmp28_AST = null;
		if (inputState.guessing==0) {
			tmp28_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp28_AST);
		}
		match(RBRACE);
		structure_AST = (AST)currentAST.root;
		returnAST = structure_AST;
	}
	
	public final void designator(
		Referent r
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST designator_AST = null;
		
			Object lit = null;
			Designator designator = null;
			QuantifierMacro macro = null;
		
		
		switch ( LA(1)) {
		case QUOTEDSTR:
		case INT_NUM:
		case FLOAT_NUM:
		{
			lit=literal();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				
								   MarkerSet mSet = kBase.getMarkerSet(); // really use this?
							       r.setDesignator(new LiteralDesignator(lit, mSet)); 
							
			}
			designator_AST = (AST)currentAST.root;
			break;
		}
		case HASH:
		case NAME:
		{
			designator=locator();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				
								   r.setDesignator(designator);	
							
			}
			designator_AST = (AST)currentAST.root;
			break;
		}
		case AT:
		{
			macro=quantifier();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				
									// A call to setQuantifier() seems to set the
								    // descriptor also. Whether this is a bug in
								    // Notio or pCG I'm not sure, but the former
								    // seems likely. Checking that a bogus one hasn't
									// been set and if it has, unsetting it, doesn't
								    // seem to make any difference.
									r.setQuantifier(macro);
							
			}
			designator_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = designator_AST;
	}
	
	public final Object  literal() throws RecognitionException, TokenStreamException {
		Object lit;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST literal_AST = null;
		Token  str = null;
		AST str_AST = null;
		
			lit = null;
		
		
		switch ( LA(1)) {
		case INT_NUM:
		case FLOAT_NUM:
		{
			lit=number();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			literal_AST = (AST)currentAST.root;
			break;
		}
		case QUOTEDSTR:
		{
			str = LT(1);
			if (inputState.guessing==0) {
				str_AST = (AST)astFactory.create(str);
				astFactory.addASTChild(currentAST, str_AST);
			}
			match(QUOTEDSTR);
			if ( inputState.guessing==0 ) {
				lit = str_AST.getText();
			}
			literal_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = literal_AST;
		return lit;
	}
	
	public final Designator  locator() throws RecognitionException, TokenStreamException {
		Designator d;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST locator_AST = null;
		Token  str = null;
		AST str_AST = null;
		
			d = null;
			String indiv = null;
			String indexical = null;
		
		
		if ((LA(1)==NAME)) {
			str = LT(1);
			if (inputState.guessing==0) {
				str_AST = (AST)astFactory.create(str);
				astFactory.addASTChild(currentAST, str_AST);
			}
			match(NAME);
			if ( inputState.guessing==0 ) {
				d = new NameDesignator(str_AST.getText());
			}
			locator_AST = (AST)currentAST.root;
		}
		else {
			boolean synPredMatched52 = false;
			if (((LA(1)==HASH))) {
				int _m52 = mark();
				synPredMatched52 = true;
				inputState.guessing++;
				try {
					{
					individualMarker();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched52 = false;
				}
				rewind(_m52);
				inputState.guessing--;
			}
			if ( synPredMatched52 ) {
				indiv=individualMarker();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					
									   MarkerSet mSet = kBase.getMarkerSet(); // really use this?
								       d = new MarkerDesignator(new Marker(mSet, indiv));
								
				}
				locator_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==HASH)) {
				indexical=indexical();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					
									   MarkerSet mSet = kBase.getMarkerSet(); // really use this?
								       d = new MarkerDesignator(new Marker(mSet, indexical));
								
				}
				locator_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			returnAST = locator_AST;
			return d;
		}
		
	public final QuantifierMacro  quantifier() throws RecognitionException, TokenStreamException {
		QuantifierMacro m;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST quantifier_AST = null;
		Token  n = null;
		AST n_AST = null;
		Token  id = null;
		AST id_AST = null;
		Token  str1 = null;
		AST str1_AST = null;
		Token  str2 = null;
		AST str2_AST = null;
		
			m = null;
			String name = null;
			ArrayList list = new ArrayList();
		
		
		AST tmp29_AST = null;
		if (inputState.guessing==0) {
			tmp29_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp29_AST);
		}
		match(AT);
		{
		switch ( LA(1)) {
		case UNSIGNEDINT:
		{
			n = LT(1);
			if (inputState.guessing==0) {
				n_AST = (AST)astFactory.create(n);
				astFactory.addASTChild(currentAST, n_AST);
			}
			match(UNSIGNEDINT);
			if ( inputState.guessing==0 ) {
				
										String s = null;
							    		try {
											s = n_AST.getText();
								    		int num = Integer.valueOf(s).intValue();
											m = new NumericQuantifier(num);
							    		} catch(NumberFormatException e) {
											throw new SemanticException(s + 
															": illegal number format");
										}
									
			}
			break;
		}
		case IDENTIFIER:
		{
			id = LT(1);
			if (inputState.guessing==0) {
				id_AST = (AST)astFactory.create(id);
				astFactory.addASTChild(currentAST, id_AST);
			}
			match(IDENTIFIER);
			if ( inputState.guessing==0 ) {
				
									  name = id_AST.getText();
									  if (name.equals("some") || name.equals("every")) {
										  // canonicty for existential & universal quantifiers
										  name = name.toLowerCase();
									  }
								
			}
			{
			if ((LA(1)==LBRACE)) {
				AST tmp30_AST = null;
				if (inputState.guessing==0) {
					tmp30_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp30_AST);
				}
				match(LBRACE);
				str1 = LT(1);
				if (inputState.guessing==0) {
					str1_AST = (AST)astFactory.create(str1);
					astFactory.addASTChild(currentAST, str1_AST);
				}
				match(QUOTEDSTR);
				if ( inputState.guessing==0 ) {
					list.add(str1_AST.getText());
				}
				{
				_loop59:
				do {
					if ((LA(1)==COMMA)) {
						AST tmp31_AST = null;
						if (inputState.guessing==0) {
							tmp31_AST = (AST)astFactory.create(LT(1));
							astFactory.addASTChild(currentAST, tmp31_AST);
						}
						match(COMMA);
						str2 = LT(1);
						if (inputState.guessing==0) {
							str2_AST = (AST)astFactory.create(str2);
							astFactory.addASTChild(currentAST, str2_AST);
						}
						match(QUOTEDSTR);
						if ( inputState.guessing==0 ) {
							list.add(str2_AST.getText());
						}
					}
					else {
						break _loop59;
					}
					
				} while (true);
				}
				AST tmp32_AST = null;
				if (inputState.guessing==0) {
					tmp32_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp32_AST);
				}
				match(RBRACE);
				if ( inputState.guessing==0 ) {
					
											// For example: @Col{"Foo", "Bar"}
											Object[] collection = list.toArray(new Object[0]);
										    m = new DefinedQuantifier(name, collection);
										
				}
			}
			else if ((_tokenSet_3.member(LA(1)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			if ( inputState.guessing==0 ) {
				
								       // Named quatifier with no collection,
									   // e.g.@some, @every
								       if (m == null) m = new DefinedQuantifier(name);
								
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		quantifier_AST = (AST)currentAST.root;
		returnAST = quantifier_AST;
		return m;
	}
	
	public final void disjuncts() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST disjuncts_AST = null;
		
		conjuncts();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop42:
		do {
			if ((LA(1)==VERTBAR)) {
				AST tmp33_AST = null;
				if (inputState.guessing==0) {
					tmp33_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp33_AST);
				}
				match(VERTBAR);
				conjuncts();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop42;
			}
			
		} while (true);
		}
		disjuncts_AST = (AST)currentAST.root;
		returnAST = disjuncts_AST;
	}
	
	public final void formalParameter() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST formalParameter_AST = null;
		
			String label = null;
		
		
		label=type();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		switch ( LA(1)) {
		case STAR:
		{
			defLabel(null, null);
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case RPAREN:
		case COMMA:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		formalParameter_AST = (AST)currentAST.root;
		returnAST = formalParameter_AST;
	}
	
	public final String  indexical() throws RecognitionException, TokenStreamException {
		String s;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST indexical_AST = null;
		Token  str = null;
		AST str_AST = null;
		
			s = null;
		
		
		AST tmp34_AST = null;
		if (inputState.guessing==0) {
			tmp34_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp34_AST);
		}
		match(HASH);
		{
		switch ( LA(1)) {
		case IDENTIFIER:
		{
			str = LT(1);
			if (inputState.guessing==0) {
				str_AST = (AST)astFactory.create(str);
				astFactory.addASTChild(currentAST, str_AST);
			}
			match(IDENTIFIER);
			if ( inputState.guessing==0 ) {
				s = str_AST.getText();
			}
			break;
		}
		case LANGLE:
		case COMMENT:
		case QUESTION:
		case NEGATION_PREFIX:
		case LBRACK:
		case RBRACK:
		case STAR:
		case LPAREN:
		case LBRACE:
		case PERCENT:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			if (s == null) s = "#";
		}
		indexical_AST = (AST)currentAST.root;
		returnAST = indexical_AST;
		return s;
	}
	
	public final String  individualMarker() throws RecognitionException, TokenStreamException {
		String s;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST individualMarker_AST = null;
		Token  str = null;
		AST str_AST = null;
		
			s = null;
		
		
		AST tmp35_AST = null;
		if (inputState.guessing==0) {
			tmp35_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp35_AST);
		}
		match(HASH);
		str = LT(1);
		if (inputState.guessing==0) {
			str_AST = (AST)astFactory.create(str);
			astFactory.addASTChild(currentAST, str_AST);
		}
		match(UNSIGNEDINT);
		if ( inputState.guessing==0 ) {
			s = str_AST.getText();
		}
		individualMarker_AST = (AST)currentAST.root;
		returnAST = individualMarker_AST;
		return s;
	}
	
	public final void lambdaExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lambdaExpression_AST = null;
		
			Graph body = null;
		
		
		AST tmp36_AST = null;
		if (inputState.guessing==0) {
			tmp36_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp36_AST);
		}
		match(LPAREN);
		AST tmp37_AST = null;
		if (inputState.guessing==0) {
			tmp37_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp37_AST);
		}
		match(LITERAL_lambda);
		signature();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		body=cg();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp38_AST = null;
		if (inputState.guessing==0) {
			tmp38_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp38_AST);
		}
		match(RPAREN);
		lambdaExpression_AST = (AST)currentAST.root;
		returnAST = lambdaExpression_AST;
	}
	
	public final void signature() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST signature_AST = null;
		
		AST tmp39_AST = null;
		if (inputState.guessing==0) {
			tmp39_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp39_AST);
		}
		match(LPAREN);
		{
		switch ( LA(1)) {
		case IDENTIFIER:
		case LPAREN:
		{
			formalParameter();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			{
			_loop77:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp40_AST = null;
					if (inputState.guessing==0) {
						tmp40_AST = (AST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp40_AST);
					}
					match(COMMA);
					formalParameter();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else {
					break _loop77;
				}
				
			} while (true);
			}
			break;
		}
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp41_AST = null;
		if (inputState.guessing==0) {
			tmp41_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp41_AST);
		}
		match(RPAREN);
		signature_AST = (AST)currentAST.root;
		returnAST = signature_AST;
	}
	
	public final Number  number() throws RecognitionException, TokenStreamException {
		Number num;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST number_AST = null;
		Token  n = null;
		AST n_AST = null;
		Token  m = null;
		AST m_AST = null;
		
			num = null;
		
		
		switch ( LA(1)) {
		case INT_NUM:
		{
			n = LT(1);
			if (inputState.guessing==0) {
				n_AST = (AST)astFactory.create(n);
				astFactory.addASTChild(currentAST, n_AST);
			}
			match(INT_NUM);
			if ( inputState.guessing==0 ) {
				
							    String s = n_AST.getText();
								// Java doesn't permit an integer to be preceded by "+".
								// This is not the case for floating point values!
								if (s.startsWith("+")) { s = s.substring(1); }
							    Long l;
							    try {
								    l = Long.valueOf(s);
								    num = l;
							    } catch(NumberFormatException e) {
								    throw new SemanticException(s + ": illegal number format");
								}
						
			}
			number_AST = (AST)currentAST.root;
			break;
		}
		case FLOAT_NUM:
		{
			m = LT(1);
			if (inputState.guessing==0) {
				m_AST = (AST)astFactory.create(m);
				astFactory.addASTChild(currentAST, m_AST);
			}
			match(FLOAT_NUM);
			if ( inputState.guessing==0 ) {
				
							    String s = m_AST.getText();
							    Double d;
							    try {
								    d = Double.valueOf(s);
								    num = d;
							    } catch(NumberFormatException e) {
								   throw new SemanticException(s + ": illegal number format");
								}
					
			}
			number_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = number_AST;
		return num;
	}
	
	public final Relation  negation() throws RecognitionException, TokenStreamException {
		Relation r;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST negation_AST = null;
		
			r = null;
			Graph desc = null;
		
		
		AST tmp42_AST = null;
		if (inputState.guessing==0) {
			tmp42_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp42_AST);
		}
		match(NEGATION_PREFIX);
		desc=cg();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp43_AST = null;
		if (inputState.guessing==0) {
			tmp43_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp43_AST);
		}
		match(RBRACK);
		if ( inputState.guessing==0 ) {
			
							   Concept[] args = new Concept[1];
							   String propLabel = "Proposition";
						       ConceptType ct = conceptTypes.getTypeByLabel(propLabel);
							   if (ct == null) {
							       ct = new ConceptType(propLabel);
								   conceptTypes.addTypeToHierarchy(ct);				  
							   }
							   args[0] = new Concept(ct);
							   args[0].setReferent(new Referent(desc)); // set descriptor
							   // (Neg [Proposition: desc])
							   String negLabel = "Neg";
							   RelationType rt = relationTypes.getTypeByLabel(negLabel);
							   if (rt == null) {
									rt = new RelationType(negLabel, 1);
									relationTypes.addTypeToHierarchy(rt);
							   }
							   r = new Relation(rt, args);
						
		}
		negation_AST = (AST)currentAST.root;
		returnAST = negation_AST;
		return r;
	}
	
	public final void typeLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST typeLabel_AST = null;
		
		AST tmp44_AST = null;
		if (inputState.guessing==0) {
			tmp44_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp44_AST);
		}
		match(IDENTIFIER);
		typeLabel_AST = (AST)currentAST.root;
		returnAST = typeLabel_AST;
	}
	
	public final void typeExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST typeExpression_AST = null;
		
		boolean synPredMatched87 = false;
		if (((LA(1)==LPAREN))) {
			int _m87 = mark();
			synPredMatched87 = true;
			inputState.guessing++;
			try {
				{
				match(LPAREN);
				match(LITERAL_lambda);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched87 = false;
			}
			rewind(_m87);
			inputState.guessing--;
		}
		if ( synPredMatched87 ) {
			lambdaExpression();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			typeExpression_AST = (AST)currentAST.root;
		}
		else if ((LA(1)==LPAREN)) {
			AST tmp45_AST = null;
			if (inputState.guessing==0) {
				tmp45_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp45_AST);
			}
			match(LPAREN);
			disjuncts();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp46_AST = null;
			if (inputState.guessing==0) {
				tmp46_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp46_AST);
			}
			match(RPAREN);
			typeExpression_AST = (AST)currentAST.root;
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		returnAST = typeExpression_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"LANGLE",
		"VERTBAR",
		"COMMENT",
		"RANGLE",
		"QUESTION",
		"IDENTIFIER",
		"DOT",
		"NEGATION_PREFIX",
		"LBRACK",
		"RBRACK",
		"AMPERSAND",
		"STAR",
		"HASH",
		"UNSIGNEDINT",
		"LPAREN",
		"\"lambda\"",
		"RPAREN",
		"QUOTEDSTR",
		"NAME",
		"INT_NUM",
		"FLOAT_NUM",
		"AT",
		"LBRACE",
		"COMMA",
		"RBRACE",
		"COLON",
		"\"if\"",
		"\"then\"",
		"\"either\"",
		"\"or\"",
		"\"sc\"",
		"PERCENT",
		"TILDE",
		"NUMBER",
		"EXPONENT",
		"LETTER",
		"DIGIT",
		"WS"
	};
	
	private static final long _tokenSet_0_data_[] = { 41280L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 65077248L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 34492192848L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	private static final long _tokenSet_3_data_[] = { 34427156816L, 0L };
	public static final BitSet _tokenSet_3 = new BitSet(_tokenSet_3_data_);
	
	}
