// $ANTLR 2.7.0: "AntlrCGIFParser.g" -> "AntlrCGIFParser.java"$

    package cgp.translators;

	import antlr.SemanticException;

	import cgp.translators.ContextScope;
	import cgp.translators.ContextScopeStack;
	import cgp.translators.DefinedQuantifier;
	import cgp.translators.NumericQuantifier;

	import notio.Actor;
	import notio.Concept;
	import notio.ConceptAddError;
	import notio.ConceptReplaceException;
	import notio.ConceptType;
	import notio.ConceptTypeHierarchy;
	import notio.CopyingScheme;
	import notio.Designator;
	import notio.Graph;
	import notio.KnowledgeBase;
	import notio.LiteralDesignator;
	import notio.Macro;
	import notio.Marker;
	import notio.MarkerDesignator;
	import notio.MarkerSet;
	import notio.NameDesignator;
	import notio.Parser;
	import notio.QuantifierMacro;
	import notio.Referent;
	import notio.Relation;
	import notio.RelationAddError;
	import notio.RelationType;
	import notio.RelationTypeHierarchy;

	import java.util.ArrayList;

public interface AntlrCGIFTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LANGLE = 4;
	int VERTBAR = 5;
	int COMMENT = 6;
	int RANGLE = 7;
	int QUESTION = 8;
	int IDENTIFIER = 9;
	int DOT = 10;
	int NEGATION_PREFIX = 11;
	int LBRACK = 12;
	int RBRACK = 13;
	int AMPERSAND = 14;
	int STAR = 15;
	int HASH = 16;
	int UNSIGNEDINT = 17;
	int LPAREN = 18;
	int LITERAL_lambda = 19;
	int RPAREN = 20;
	int QUOTEDSTR = 21;
	int NAME = 22;
	int INT_NUM = 23;
	int FLOAT_NUM = 24;
	int AT = 25;
	int LBRACE = 26;
	int COMMA = 27;
	int RBRACE = 28;
	int COLON = 29;
	int LITERAL_if = 30;
	int LITERAL_then = 31;
	int LITERAL_either = 32;
	int LITERAL_or = 33;
	int LITERAL_sc = 34;
	int PERCENT = 35;
	int TILDE = 36;
	int NUMBER = 37;
	int EXPONENT = 38;
	int LETTER = 39;
	int DIGIT = 40;
	int WS = 41;
}
