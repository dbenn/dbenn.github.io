// $ANTLR 2.7.0: "CGPInterpreter.g" -> "CGPInterpreter.java"$

    package cgp;

	import antlr.CommonAST;
    import antlr.SemanticException;

    import cgp.runtime.ActorException;
    import cgp.runtime.ActorType;
    import cgp.runtime.BooleanType;
    import cgp.runtime.ConceptType;
    import cgp.runtime.FileType;
    import cgp.runtime.FormalParameter;
    import cgp.runtime.FunctionType;
    import cgp.runtime.GraphType;
    import cgp.runtime.KBase;
    import cgp.runtime.KnowledgeBaseStack;
    import cgp.runtime.LambdaType;
    import cgp.runtime.LastException;
    import cgp.runtime.ListType;
    import cgp.runtime.Namespace;
    import cgp.runtime.NumberType;
    import cgp.runtime.ProcessType;
    import cgp.runtime.Rule;
    import cgp.runtime.ReturnException;
    import cgp.runtime.Scope;
    import cgp.runtime.ScopeStack;
    import cgp.runtime.StringType;
    import cgp.runtime.SubActorInfo;
    import cgp.runtime.Type;
    import cgp.runtime.UndefinedType;

    import java.io.File;
    import java.io.IOException;
    import java.util.Enumeration;
    import java.util.LinkedList;
    import java.util.List;
    import java.util.Properties;

    import notio.Actor;
    import notio.Concept;
    import notio.ConceptReplaceException;
    import notio.Graph;
    import notio.Relation;
    import notio.TypeAddError;
    import notio.TypeChangeError;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

/**
 * A conceptual graph language which embodies Guy Mineau's process formalism.
 * Copyright (C) 2000,2001 David Benn
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Conceptual Graph Processes interpreter.
 *
 * David Benn, June-October 2000, June 2001
 */
public class CGPInterpreter extends antlr.TreeParser
       implements CGPInterpreterTokenTypes
 {

    // ** Interpreter initialisation code.
    ScopeStack scopes;
    Scope topLevelScope;
    KnowledgeBaseStack kbases;
    KBase topLevelKBase;
    boolean trace;
	String[] args;
    CommonAST tree;

    public CGPInterpreter(String[] args, CommonAST tree) {
		this();
		this.trace = false;
		this.args = args; // pCG command-line arguments
        this.tree = tree;
    }
public CGPInterpreter() {
	tokenNames = _tokenNames;
}

	public final void program(AST _t) throws RecognitionException {
		
		AST program_AST_in = (AST)_t;
		
		// ** Code that must be executed at the start of each 
		// ** complete program run.
		
		// Create a scope stack and make it available to all Type instances.
		// TBD: Probably should put such setters in CGP class.
		scopes = new ScopeStack();
		Type.setScopeStack(scopes);
		
		// Create the top-level scope.
		topLevelScope = new Scope();
		scopes.push(topLevelScope);
		
		// Create a knowledge base stack and make it available
		// to all Type instances.
		kbases = new KnowledgeBaseStack();
		Type.setKBStack(kbases);
		
		// Create the top-level knowledge base.
		topLevelKBase = new KBase();
		kbases.push(topLevelKBase);
		
		// Add environment variables to top-level scope for use
		// by pCG programs.
		ListType envars = new ListType();
		topLevelScope.def("_ENV", envars);
		Properties env = System.getProperties();
		Enumeration keys = env.propertyNames();
		while (keys.hasMoreElements()) {
				String key = (String)keys.nextElement();
				String value = env.getProperty(key);
				ListType pair = new ListType();
				pair.append(new StringType(key));
				pair.append(new StringType(value));
				envars.append(pair);
		}
		
			// Add command-line arguments to top-level scope for use
		// by pCG programs. Exclude name of the pCG program.
			ListType pCGArgs = new ListType();
		topLevelScope.def("_ARGS", pCGArgs);
			for (int i=1;i<args.length;i++) {
				pCGArgs.append(new StringType(args[i]));
			}
		
		
		{
		_loop3:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_tokenSet_0.member(_t.getType()))) {
				topLevelStatement(_t);
				_t = _retTree;
			}
			else {
				break _loop3;
			}
			
		} while (true);
		}
		_retTree = _t;
	}
	
	public final void topLevelStatement(AST _t) throws RecognitionException {
		
		AST topLevelStatement_AST_in = (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case OPTION_LIST:
		{
			optionStatement(_t);
			_t = _retTree;
			break;
		}
		case TYPE_DECL:
		{
			typeDecl(_t);
			_t = _retTree;
			break;
		}
		case FUN_DEF:
		{
			funDef(_t);
			_t = _retTree;
			break;
		}
		case LAMBDA_DEF:
		{
			lambdaDef(_t);
			_t = _retTree;
			break;
		}
		case ACTOR_DEF:
		{
			actorDef(_t);
			_t = _retTree;
			break;
		}
		case PROCESS_DEF:
		{
			processDef(_t);
			_t = _retTree;
			break;
		}
		case IF_STATEMENT:
		case WHILE_STATEMENT:
		case FOREACH_STATEMENT:
		case CALL:
		case VAR_ASSIGN:
		case ATTR_ASSIGN:
		case LIST_ASSIGN:
		case MEMBER_FUNCALL:
		case LITERAL_print:
		case LITERAL_println:
		case LITERAL_return:
		case LITERAL_exit:
		case LITERAL_last:
		case LITERAL_system:
		case LITERAL_assert:
		case LITERAL_retract:
		case LITERAL_apply:
		{
			statement(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void optionStatement(AST _t) throws RecognitionException {
		
		AST optionStatement_AST_in = (AST)_t;
		AST opt = null;
		AST str = null;
		
			String theOpt = null;
			boolean CGIFParserOption = false;
			boolean CGIFGenOption = false;
		
		
		AST __t6 = _t;
		AST tmp1_AST_in = (AST)_t;
		match(_t,OPTION_LIST);
		_t = _t.getFirstChild();
		{
		int _cnt9=0;
		_loop9:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==IDENT)) {
				opt = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							    theOpt = opt.getText();
							    if (theOpt.toUpperCase().equals("LFOUT")) {
								    CGP.LFOpt = true;
								} else if (theOpt.toUpperCase().equals("TRACE")) {
								    CGP.setTraceMode(true);
									trace = true;
									System.out.println("TRACE: " + tree.toStringList());
								} else if (theOpt.toUpperCase().equals("CGIFPARSER")) {
									// The option we're dealing with sets the CGIF parser.
									CGIFParserOption = true;
								} else if (theOpt.toUpperCase().equals("CGIFGEN")) {
									// The option we're dealing with sets the CGIF generator.
									CGIFGenOption = true;
								} else {
									String msg = "'" + theOpt + "' is an unknown option.";
									throw new SemanticException(msg);
								}
							
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case STRING:
				{
					str = (AST)_t;
					match(_t,STRING);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						
								    if (CGIFParserOption) {
										// Set the CGIF parser to something other than the
									    // default Notio CGIF parser.
									    CGP.CGIFParserOpt = str.getText();
						} else if (CGIFGenOption) {
										// Set the CGIF generator to something other than the
									    // default Notio CGIF generator.
									    CGP.CGIFGenOpt = str.getText();
						} else {
									    String msg = "'" + theOpt + "' option does not take the ";
										msg += "form of a name-value pair.";
										throw new SemanticException(msg);
									}
						
					}
					break;
				}
				case 3:
				case IDENT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
			}
			else {
				if ( _cnt9>=1 ) { break _loop9; } else {throw new NoViableAltException(_t);}
			}
			
			_cnt9++;
		} while (true);
		}
		_t = __t6;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void typeDecl(AST _t) throws RecognitionException {
		
		AST typeDecl_AST_in = (AST)_t;
		AST t = null;
		AST id1 = null;
		AST id2 = null;
		
		boolean isConceptDecl = false;
		String superTypeName = null;
		
		
		try {      // for error handling
			AST __t11 = _t;
			AST tmp2_AST_in = (AST)_t;
			match(_t,TYPE_DECL);
			_t = _t.getFirstChild();
			t = _t==ASTNULL ? null : (AST)_t;
			nodeKind(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						    // A correct parse guarantees one of
						    // the values in nodeKind, so if it's
						    // not a concept declaration, it's a 
						    // relation declaration.
						    if (t.getText().equals("concept")) {
							isConceptDecl = true;
						    }
						
			}
			id1 = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						      String typeName = id1.getText();
				
						      if (isConceptDecl) {
							  topLevelKBase.addConceptType(typeName);
						      } else {
							  topLevelKBase.addRelationType(typeName);
						      } 
						      
						      superTypeName = typeName;
						
			}
			{
			_loop13:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==IDENT)) {
					id2 = (AST)_t;
					match(_t,IDENT);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						
								      String typeName = id2.getText();
						
								      if (isConceptDecl) {
									  topLevelKBase.linkConceptTypes(superTypeName,
													typeName);
								      } else {
									  topLevelKBase.linkRelationTypes(superTypeName,
													 typeName);
								      } 
								      
								      superTypeName = typeName;		      
								
					}
				}
				else {
					break _loop13;
				}
				
			} while (true);
			}
			_t = __t11;
			_t = _t.getNextSibling();
		}
		catch (TypeAddError e) {
			if (inputState.guessing==0) {
				
					      String msg = "error adding type.";
					      throw new SemanticException(msg);	      
					
			} else {
				throw e;
			}
		}
		catch (TypeChangeError e) {
			if (inputState.guessing==0) {
				
					      String msg = "error changing type.";
					      throw new SemanticException(msg);	      
				
			} else {
				throw e;
			}
		}
		_retTree = _t;
	}
	
	public final void funDef(AST _t) throws RecognitionException {
		
		AST funDef_AST_in = (AST)_t;
		AST name = null;
		AST arg = null;
		AST b = null;
		
		LinkedList formals = new LinkedList();
		
		
		AST __t16 = _t;
		AST tmp3_AST_in = (AST)_t;
		match(_t,FUN_DEF);
		_t = _t.getFirstChild();
		name = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		_loop18:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==IDENT)) {
				arg = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					formals.add(new FormalParameter(arg.getText()));
				}
			}
			else {
				break _loop18;
			}
			
		} while (true);
		}
		b = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					    FunctionType func = new FunctionType(name.getText(),
						     	      	    (FormalParameter[])formals.
								      toArray(new FormalParameter[0]),
						     	      	     b);
					    scopes.peek().def(name.getText(), func);
					
		}
		_t = __t16;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void lambdaDef(AST _t) throws RecognitionException {
		
		AST lambdaDef_AST_in = (AST)_t;
		AST name = null;
		AST arg = null;
		
		LinkedList formals = new LinkedList();
		Type g = UndefinedType.undefined;
		
		
		AST __t25 = _t;
		AST tmp4_AST_in = (AST)_t;
		match(_t,LAMBDA_DEF);
		_t = _t.getFirstChild();
		name = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		int _cnt27=0;
		_loop27:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==IDENT)) {
				arg = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							      formals.add(new FormalParameter(arg.getText(), false)); 
							
				}
			}
			else {
				if ( _cnt27>=1 ) { break _loop27; } else {throw new NoViableAltException(_t);}
			}
			
			_cnt27++;
		} while (true);
		}
		g=expr(_t);
		_t = _retTree;
		if ( inputState.guessing==0 ) {
			
					    if (g instanceof GraphType) {
						LambdaType lambda = new LambdaType(name.getText(),
								   (FormalParameter[])formals.
								    toArray(new FormalParameter[0]),
								   (GraphType)g);	
						scopes.peek().def(name.getText(), lambda);
					    } else {
				    		String msg = "a lambda's body must be a graph.";
						throw new SemanticException(msg);
					    }
					
		}
		_t = __t25;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void actorDef(AST _t) throws RecognitionException {
		
		AST actorDef_AST_in = (AST)_t;
		AST name = null;
		AST arg = null;
		
		boolean isOut = false; // keep javac happy 
		LinkedList formals = new LinkedList();
		Type g = UndefinedType.undefined;
		
		
		AST __t20 = _t;
		AST tmp5_AST_in = (AST)_t;
		match(_t,ACTOR_DEF);
		_t = _t.getFirstChild();
		name = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		int _cnt22=0;
		_loop22:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==IDENT)) {
				arg = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							      //isOut = kind.getText().equals("out") ? true : false; 
							      formals.add(new FormalParameter(arg.getText(), isOut)); 
							      // ??? "out" as in mutatable? We only really handle 
							      // "in" parameters to actors, getting a whole mutated
							      // graph as a whole.
							
				}
			}
			else {
				if ( _cnt22>=1 ) { break _loop22; } else {throw new NoViableAltException(_t);}
			}
			
			_cnt22++;
		} while (true);
		}
		g=expr(_t);
		_t = _retTree;
		if ( inputState.guessing==0 ) {
			
					    if (g instanceof GraphType) {
						try {			    
					            ActorType actor = new ActorType(name.getText(),
				  		                      (FormalParameter[])formals.
							      	       toArray(new FormalParameter[0]),
						     	      	      (GraphType)g);
						    // Assume the graph is valid and add it to the
						    // current scope so that recursive actors are
						    // possible. If it's not valid, the next step
						    // will cause a fatal error anyway.
						    scopes.peek().def(name.getText(), actor);
						    // Check whether graph is valid at definition 
						    // time.
						    actor.studyGraph();
					  	} catch(ActorException e) {
				    		    String msg = "actor is not well-formed: ";
						    msg += e.getMessage();
						    throw new SemanticException(msg);
						}
					    } else {
				    		String msg = "an actor's body must be a graph.";
						throw new SemanticException(msg);
					    }
					
		}
		_t = __t20;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void processDef(AST _t) throws RecognitionException {
		
		AST processDef_AST_in = (AST)_t;
		AST processName = null;
		AST argKind = null;
		AST arg = null;
		AST b = null;
		AST ruleName = null;
		AST ruleOpt = null;
		AST actionBlockPre = null;
		AST matchExpr = null;
		AST actionBlockPost = null;
		AST mutateKBExpr = null;
		AST postCondOpt = null;
		
		boolean isOut = false;
		LinkedList formals = new LinkedList();
		AST initialBlock = null;
		LinkedList rules = new LinkedList();
		Rule rule = null;
		boolean negateGraph = false;
		LinkedList negateMatchGraphList = null;
		LinkedList matchList = null;
		boolean exportGraph = false;
		LinkedList exportGraphOptList = null;
		LinkedList mutateKBList = null;
		
		
		AST __t29 = _t;
		AST tmp6_AST_in = (AST)_t;
		match(_t,PROCESS_DEF);
		_t = _t.getFirstChild();
		processName = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		_loop31:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==LITERAL_in||_t.getType()==LITERAL_out)) {
				argKind = _t==ASTNULL ? null : (AST)_t;
				processParamKind(_t);
				_t = _retTree;
				arg = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							     String kind = argKind.getText();
							     isOut = kind.equals("out") ? true : false;  
							     formals.add(new FormalParameter(arg.getText(), isOut));
							
				}
			}
			else {
				break _loop31;
			}
			
		} while (true);
		}
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case BLOCK:
		{
			b = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						      initialBlock = b;
						
			}
			break;
		}
		case 3:
		case RULE_DEF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		{
		_loop52:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==RULE_DEF)) {
				AST __t34 = _t;
				AST tmp7_AST_in = (AST)_t;
				match(_t,RULE_DEF);
				_t = _t.getFirstChild();
				ruleName = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							      rule = new Rule(ruleName.getText());
							      rules.add(rule);
							      matchList = new LinkedList();
							      negateMatchGraphList = new LinkedList();
							      exportGraphOptList = new LinkedList();
							      mutateKBList = new LinkedList();
							
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPTION_LIST:
				{
					AST __t36 = _t;
					AST tmp8_AST_in = (AST)_t;
					match(_t,OPTION_LIST);
					_t = _t.getFirstChild();
					{
					int _cnt38=0;
					_loop38:
					do {
						if (_t==null) _t=ASTNULL;
						if ((_t.getType()==IDENT)) {
							ruleOpt = (AST)_t;
							match(_t,IDENT);
							_t = _t.getNextSibling();
							if ( inputState.guessing==0 ) {
								
											String theOpt = ruleOpt.getText();
											if (theOpt.toUpperCase().equals("EXPORT")) {
											    rule.setExportAllOpt(true);
											} else if (theOpt.toUpperCase().
												   equals("EXPORTASSERT")) {
											    rule.setExportAssertOpt(true);
											} else if (theOpt.toUpperCase().
												   equals("EXPORTRETRACT")) {
											    rule.setExportRetractOpt(true);
											} else {
											    String msg = "'" + theOpt + 
												"' is an unknown option.";
											    throw new SemanticException(msg);
											}
										
							}
						}
						else {
							if ( _cnt38>=1 ) { break _loop38; } else {throw new NoViableAltException(_t);}
						}
						
						_cnt38++;
					} while (true);
					}
					_t = __t36;
					_t = _t.getNextSibling();
					break;
				}
				case PRE_DEF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				AST __t39 = _t;
				AST tmp9_AST_in = (AST)_t;
				match(_t,PRE_DEF);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BLOCK:
				{
					actionBlockPre = (AST)_t;
					match(_t,BLOCK);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						
									    rule.setPreconditionActionBlock(actionBlockPre);
									
					}
					break;
				}
				case 3:
				case MATCH_EXPRESSION:
				case TILDE:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop43:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==MATCH_EXPRESSION||_t.getType()==TILDE)) {
						if ( inputState.guessing==0 ) {
							
										    negateGraph = false;
									
						}
						{
						if (_t==null) _t=ASTNULL;
						switch ( _t.getType()) {
						case TILDE:
						{
							AST tmp10_AST_in = (AST)_t;
							match(_t,TILDE);
							_t = _t.getNextSibling();
							if ( inputState.guessing==0 ) {
								negateGraph = true;
							}
							break;
						}
						case MATCH_EXPRESSION:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(_t);
						}
						}
						}
						matchExpr = (AST)_t;
						match(_t,MATCH_EXPRESSION);
						_t = _t.getNextSibling();
						if ( inputState.guessing==0 ) {
							
										    negateMatchGraphList.add(new Boolean(negateGraph));
										    matchList.add(matchExpr);
									
						}
					}
					else {
						break _loop43;
					}
					
				} while (true);
				}
				if ( inputState.guessing==0 ) {
					
								 rule.setMatchExpressions((AST[])matchList.
											  toArray(new AST[0]));
								 rule.setMatchGraphNegations(negateMatchGraphList);
							
				}
				_t = __t39;
				_t = _t.getNextSibling();
				AST __t44 = _t;
				AST tmp11_AST_in = (AST)_t;
				match(_t,POST_DEF);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BLOCK:
				{
					actionBlockPost = (AST)_t;
					match(_t,BLOCK);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						
									    rule.setPostconditionActionBlock(actionBlockPost);
									
					}
					break;
				}
				case 3:
				case MUTATE_KB_EXPRESSION:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop51:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==MUTATE_KB_EXPRESSION)) {
						mutateKBExpr = (AST)_t;
						match(_t,MUTATE_KB_EXPRESSION);
						_t = _t.getNextSibling();
						if ( inputState.guessing==0 ) {
							
										    exportGraph = false;
									
						}
						{
						if (_t==null) _t=ASTNULL;
						switch ( _t.getType()) {
						case OPTION_LIST:
						{
							AST __t48 = _t;
							AST tmp12_AST_in = (AST)_t;
							match(_t,OPTION_LIST);
							_t = _t.getFirstChild();
							{
							int _cnt50=0;
							_loop50:
							do {
								if (_t==null) _t=ASTNULL;
								if ((_t.getType()==IDENT)) {
									postCondOpt = (AST)_t;
									match(_t,IDENT);
									_t = _t.getNextSibling();
									if ( inputState.guessing==0 ) {
										
													      String theOpt = postCondOpt.getText();
													      if (theOpt.toUpperCase().equals("EXPORT")) {
														  exportGraph = true;
													      } else {
														  String msg = "'" + theOpt + 
														      "' is an unknown option.";
														  throw new SemanticException(msg);
													      }
													
									}
								}
								else {
									if ( _cnt50>=1 ) { break _loop50; } else {throw new NoViableAltException(_t);}
								}
								
								_cnt50++;
							} while (true);
							}
							_t = __t48;
							_t = _t.getNextSibling();
							break;
						}
						case 3:
						case MUTATE_KB_EXPRESSION:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(_t);
						}
						}
						}
						if ( inputState.guessing==0 ) {
							
										    // Add a postcondition graph to this rule's list.
										    mutateKBList.add(mutateKBExpr);
										    // Set options for this graph.
										    // May be more such calls later.
										    exportGraphOptList.add(new Boolean(exportGraph));
									
						}
					}
					else {
						break _loop51;
					}
					
				} while (true);
				}
				if ( inputState.guessing==0 ) {
					
								 // Set postcondition graph list for this rule.
								 rule.setMutateKBExpressions((AST[])mutateKBList.
											     toArray(new AST[0]));
								 // Set postcondition graph options for this list.
								 rule.setMutateGraphExportOpts(exportGraphOptList);
							
				}
				_t = __t44;
				_t = _t.getNextSibling();
				_t = __t34;
				_t = _t.getNextSibling();
			}
			else {
				break _loop52;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			
					     ProcessType process;
					     process = new ProcessType(processName.getText(),
							   (FormalParameter[])formals.
							    toArray(new FormalParameter[0]),
							   initialBlock,
							   (Rule[])rules.toArray(new Rule[0]));
					     scopes.peek().def(processName.getText(), process);
					
		}
		_t = __t29;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void statement(AST _t) throws RecognitionException {
		
		AST statement_AST_in = (AST)_t;
		
		Type r = UndefinedType.undefined;
		
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_print:
		case LITERAL_println:
		case LITERAL_return:
		case LITERAL_exit:
		case LITERAL_last:
		case LITERAL_system:
		case LITERAL_assert:
		case LITERAL_retract:
		case LITERAL_apply:
		{
			intrinsicStatement(_t);
			_t = _retTree;
			break;
		}
		case IF_STATEMENT:
		{
			ifStatement(_t);
			_t = _retTree;
			break;
		}
		case WHILE_STATEMENT:
		{
			whileStatement(_t);
			_t = _retTree;
			break;
		}
		case FOREACH_STATEMENT:
		{
			foreachStatement(_t);
			_t = _retTree;
			break;
		}
		case MEMBER_FUNCALL:
		{
			memberFunCall(_t);
			_t = _retTree;
			break;
		}
		case CALL:
		{
			r=call(_t);
			_t = _retTree;
			break;
		}
		case VAR_ASSIGN:
		case ATTR_ASSIGN:
		case LIST_ASSIGN:
		{
			assignment(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void nodeKind(AST _t) throws RecognitionException {
		
		AST nodeKind_AST_in = (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_concept:
		{
			AST tmp13_AST_in = (AST)_t;
			match(_t,LITERAL_concept);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_relation:
		{
			AST tmp14_AST_in = (AST)_t;
			match(_t,LITERAL_relation);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final Type  expr(AST _t) throws RecognitionException {
		Type r;
		
		AST expr_AST_in = (AST)_t;
		
		Type a = UndefinedType.undefined;
		r = UndefinedType.undefined;
		
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case MEMBER_FUNCALL:
		case ATTR_SELECTION:
		case LIST_SELECTION:
		case AND:
		case OR:
		case IS:
		case NOT:
		case GT:
		case LT:
		case GE:
		case LE:
		case EQ:
		case NE:
		case PLUS:
		case MINUS:
		case MUL:
		case LITERAL_div:
		case LITERAL_mod:
		{
			r=operationExpr(_t);
			_t = _retTree;
			break;
		}
		case CALL:
		{
			r=call(_t);
			_t = _retTree;
			break;
		}
		case ANON_FUN_DEF:
		case LIST:
		case CONCEPT_LITERAL:
		case GRAPH_LITERAL:
		case FILE_VALUE:
		case NEW_VALUE:
		case EMPTY_LIST:
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case STRING:
		case LITERAL_system:
		case LITERAL_apply:
		case LITERAL_activate:
		case NUMBER:
		case LITERAL_file:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		{
			r=factor(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
		return r;
	}
	
	public final void actorParamKind(AST _t) throws RecognitionException {
		
		AST actorParamKind_AST_in = (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_in:
		{
			AST tmp15_AST_in = (AST)_t;
			match(_t,LITERAL_in);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_out:
		{
			AST tmp16_AST_in = (AST)_t;
			match(_t,LITERAL_out);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void processParamKind(AST _t) throws RecognitionException {
		
		AST processParamKind_AST_in = (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_in:
		{
			AST tmp17_AST_in = (AST)_t;
			match(_t,LITERAL_in);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_out:
		{
			AST tmp18_AST_in = (AST)_t;
			match(_t,LITERAL_out);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void intrinsicStatement(AST _t) throws RecognitionException {
		
		AST intrinsicStatement_AST_in = (AST)_t;
		
		Type a = UndefinedType.undefined;
		Type b = UndefinedType.undefined;
		int exitCode = 0;
		
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_print:
		{
			AST __t56 = _t;
			AST tmp19_AST_in = (AST)_t;
			match(_t,LITERAL_print);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			_t = __t56;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				System.out.print(a);
			}
			break;
		}
		case LITERAL_println:
		{
			AST __t57 = _t;
			AST tmp20_AST_in = (AST)_t;
			match(_t,LITERAL_println);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			_t = __t57;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				System.out.println(a);
			}
			break;
		}
		case LITERAL_return:
		{
			AST __t58 = _t;
			AST tmp21_AST_in = (AST)_t;
			match(_t,LITERAL_return);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ANON_FUN_DEF:
			case CALL:
			case MEMBER_FUNCALL:
			case ATTR_SELECTION:
			case LIST_SELECTION:
			case LIST:
			case CONCEPT_LITERAL:
			case GRAPH_LITERAL:
			case FILE_VALUE:
			case NEW_VALUE:
			case EMPTY_LIST:
			case AND:
			case OR:
			case IS:
			case NOT:
			case IDENT:
			case LITERAL_function:
			case LITERAL_lambda:
			case LITERAL_actor:
			case LITERAL_process:
			case GT:
			case LITERAL_concept:
			case STRING:
			case LITERAL_system:
			case LITERAL_apply:
			case LT:
			case GE:
			case LE:
			case EQ:
			case NE:
			case PLUS:
			case MINUS:
			case MUL:
			case LITERAL_div:
			case LITERAL_mod:
			case LITERAL_activate:
			case NUMBER:
			case LITERAL_file:
			case LITERAL_true:
			case LITERAL_false:
			case LITERAL_number:
			case LITERAL_string:
			case LITERAL_boolean:
			case LITERAL_graph:
			case LITERAL_list:
			case LITERAL_undefined:
			{
				a=expr(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					scopes.peek().setReturnValue(a);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						    if (scopes.depth() > 1) {
							throw new ReturnException(); 
						    } else {
							String msg = "return can only be invoked from ";
							msg += "within a function, actor, or process.";
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t58;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_exit:
		{
			AST __t60 = _t;
			AST tmp22_AST_in = (AST)_t;
			match(_t,LITERAL_exit);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ANON_FUN_DEF:
			case CALL:
			case MEMBER_FUNCALL:
			case ATTR_SELECTION:
			case LIST_SELECTION:
			case LIST:
			case CONCEPT_LITERAL:
			case GRAPH_LITERAL:
			case FILE_VALUE:
			case NEW_VALUE:
			case EMPTY_LIST:
			case AND:
			case OR:
			case IS:
			case NOT:
			case IDENT:
			case LITERAL_function:
			case LITERAL_lambda:
			case LITERAL_actor:
			case LITERAL_process:
			case GT:
			case LITERAL_concept:
			case STRING:
			case LITERAL_system:
			case LITERAL_apply:
			case LT:
			case GE:
			case LE:
			case EQ:
			case NE:
			case PLUS:
			case MINUS:
			case MUL:
			case LITERAL_div:
			case LITERAL_mod:
			case LITERAL_activate:
			case NUMBER:
			case LITERAL_file:
			case LITERAL_true:
			case LITERAL_false:
			case LITERAL_number:
			case LITERAL_string:
			case LITERAL_boolean:
			case LITERAL_graph:
			case LITERAL_list:
			case LITERAL_undefined:
			{
				a=expr(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					
							    if (a instanceof NumberType) {
								// Make sure we have an integer exit code.
								exitCode = (int)((NumberType)a).round().getValue();
							    } else if (a instanceof StringType) {
								// Send error message to stderr and exit with a
								// non-zero value to indicate error to caller, 
								// e.g. shell.
								String msg = ((StringType)a).getValue();
								System.err.println(msg);
								exitCode = 1;
							    } else {
								String msg = "exit value must be a number or string.";
								throw new SemanticException(msg);
							    }
							
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						    System.exit(exitCode);
						
			}
			_t = __t60;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_last:
		{
			AST __t62 = _t;
			AST tmp23_AST_in = (AST)_t;
			match(_t,LITERAL_last);
			_t = _t.getFirstChild();
			if ( inputState.guessing==0 ) {
				throw new LastException();
			}
			_t = __t62;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_system:
		{
			AST __t63 = _t;
			AST tmp24_AST_in = (AST)_t;
			match(_t,LITERAL_system);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				systemStatement(_t, a);
			}
			_t = __t63;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_assert:
		{
			AST __t64 = _t;
			AST tmp25_AST_in = (AST)_t;
			match(_t,LITERAL_assert);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						    if (a instanceof GraphType) {
							kbases.peek().assert((GraphType)a);
						    } else {
							String msg = "only graphs may be asserted.";
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t64;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_retract:
		{
			AST __t65 = _t;
			AST tmp26_AST_in = (AST)_t;
			match(_t,LITERAL_retract);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						    if (a instanceof GraphType) {
							kbases.peek().retract((GraphType)a);
						    } else {
							String msg = "only graphs may be retracted.";
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t65;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_apply:
		{
			AST __t66 = _t;
			AST tmp27_AST_in = (AST)_t;
			match(_t,LITERAL_apply);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			b=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				funApply(_t, a, b);
			}
			_t = __t66;
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void ifStatement(AST _t) throws RecognitionException {
		
		AST ifStatement_AST_in = (AST)_t;
		AST c = null;
		AST thenBlock = null;
		AST elseBlock = null;
		
		Type a = UndefinedType.undefined;
		boolean cond = false;
		
		
		AST __t70 = _t;
		AST tmp28_AST_in = (AST)_t;
		match(_t,IF_STATEMENT);
		_t = _t.getFirstChild();
		c = (AST)_t;
		match(_t,CONDITION);
		_t = _t.getNextSibling();
		thenBlock = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					a = condition(c);
					if (a instanceof BooleanType) {
					    cond = ((BooleanType)a).getValue();
					    if (cond) {
						block(thenBlock);
					    }
					} else {
					    String msg = "expected boolean, found " + a.getType();
					    throw new SemanticException(msg);
					} 
				
		}
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case BLOCK:
		{
			elseBlock = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				if (!cond) block(elseBlock);
			}
			break;
		}
		case 3:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		_t = __t70;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void whileStatement(AST _t) throws RecognitionException {
		
		AST whileStatement_AST_in = (AST)_t;
		AST c = null;
		AST b = null;
		
		Type a = UndefinedType.undefined;
		boolean done = false;
		
		
		AST __t73 = _t;
		AST tmp29_AST_in = (AST)_t;
		match(_t,WHILE_STATEMENT);
		_t = _t.getFirstChild();
		c = (AST)_t;
		match(_t,CONDITION);
		_t = _t.getNextSibling();
		b = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					while (!done) {
					    a = condition(c);
					    if (a instanceof BooleanType) {
						if (((BooleanType)a).getValue() == true) {
						    try {
							block(b);
						    } catch (LastException e) {
							// a last statement was executed
							done = true;
						    }
						} else {
						    done = true;
						}
					    } else {
						String msg = "expected boolean, found " + a.getType();
						throw new SemanticException(msg);
					    }
					}
				
		}
		_t = __t73;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void foreachStatement(AST _t) throws RecognitionException {
		
		AST foreachStatement_AST_in = (AST)_t;
		AST id = null;
		AST b = null;
		
		Type a = UndefinedType.undefined;
		boolean done = false;
		
		
		AST __t75 = _t;
		AST tmp30_AST_in = (AST)_t;
		match(_t,FOREACH_STATEMENT);
		_t = _t.getFirstChild();
		id = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		a=expr(_t);
		_t = _retTree;
		b = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					if (a instanceof ListType) {
					    String var = id.getText();
					    List list = ((ListType)a).getValue();
					    for (int i=0;i<list.size() && !done;i++) {
						Type x = (Type)list.get(i);
						scopes.peek().def(var, x);
						try {
						    block(b);
						} catch (LastException e) {
						    // a last statement was executed
						    done = true;
						}
					    }
					} else {
					    String msg = "expected list, found " + a.getType();
					    throw new SemanticException(msg);
					}
				
		}
		_t = __t75;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void memberFunCall(AST _t) throws RecognitionException {
		
		AST memberFunCall_AST_in = (AST)_t;
		AST name = null;
		
		LinkedList args = null;
		Type obj = UndefinedType.undefined;
		
		
		AST __t83 = _t;
		AST tmp31_AST_in = (AST)_t;
		match(_t,MEMBER_FUNCALL);
		_t = _t.getFirstChild();
		obj=expr(_t);
		_t = _retTree;
		name = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		args=actualArgs(_t);
		_t = _retTree;
		_t = __t83;
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			obj.invokeMemberFunc(name.getText(), args.toArray());
		}
		_retTree = _t;
	}
	
	public final Type  call(AST _t) throws RecognitionException {
		Type r;
		
		AST call_AST_in = (AST)_t;
		AST ast = null;
		
		LinkedList args = null;
		Type obj = UndefinedType.undefined;
		r = UndefinedType.undefined;
		
		
		AST __t85 = _t;
		ast = _t==ASTNULL ? null :(AST)_t;
		match(_t,CALL);
		_t = _t.getFirstChild();
		obj=expr(_t);
		_t = _retTree;
		args=actualArgs(_t);
		_t = _retTree;
		_t = __t85;
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					    if (obj instanceof ActorType) {
						// re: use of #ast see generated Java code!
						r = actorCall(ast, obj, args, false); 
					    } else if (obj instanceof LambdaType) {
						// re: use of #ast see generated Java code!
						r = lambdaCall(ast, obj, args); 
					    } else if (obj instanceof FunctionType) {
						// re: use of #ast see generated Java code!
						r = funCall(ast, obj, args); 
					    } else if (obj instanceof ProcessType) {
						// re: use of #ast see generated Java code!
						r = processCall(ast, obj, args); 
					    } else {
						String msg = "expecting function, lambda, actor, ";
						msg += "or process; found " + obj.getType() + ".";  
						throw new SemanticException(msg);
					    }   
					
		}
		_retTree = _t;
		return r;
	}
	
	public final void assignment(AST _t) throws RecognitionException {
		
		AST assignment_AST_in = (AST)_t;
		AST id = null;
		AST attrName = null;
		
		Type a = UndefinedType.undefined;
		Type b = UndefinedType.undefined;
		Type c = UndefinedType.undefined;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case VAR_ASSIGN:
			{
				AST __t97 = _t;
				AST tmp32_AST_in = (AST)_t;
				match(_t,VAR_ASSIGN);
				_t = _t.getFirstChild();
				id = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				a=expr(_t);
				_t = _retTree;
				_t = __t97;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					scopes.peek().def(id.getText(), a);
				}
				break;
			}
			case LIST_ASSIGN:
			{
				AST __t98 = _t;
				AST tmp33_AST_in = (AST)_t;
				match(_t,LIST_ASSIGN);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				c=expr(_t);
				_t = _retTree;
				_t = __t98;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					a.setNthOp(b, c);
				}
				break;
			}
			case ATTR_ASSIGN:
			{
				AST __t99 = _t;
				AST tmp34_AST_in = (AST)_t;
				match(_t,ATTR_ASSIGN);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				attrName = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				b=expr(_t);
				_t = _retTree;
				_t = __t99;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					a.setAttr(attrName.getText(), b);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (IllegalArgumentException e) {
			if (inputState.guessing==0) {
				
					      String msg = "can't apply " + e.getMessage() + 
					                   " operation to values of type " + a.getType();
					      if (b != UndefinedType.undefined) {
						  // Dyadic.
						  msg += " and " + b.getType() + "."; 
					      } else {
						  // Monadic.
						  msg += "."; 
					      }
					      throw new SemanticException(msg);
					
			} else {
				throw e;
			}
		}
		catch (IndexOutOfBoundsException e) {
			if (inputState.guessing==0) {
				
					      // List access.
					      String msg = e.getMessage();
					      throw new SemanticException(msg);
					
			} else {
				throw e;
			}
		}
		_retTree = _t;
	}
	
	public final NumberType  systemStatement(AST _t,
		Type a
	) throws RecognitionException {
		NumberType r;
		
		AST systemStatement_AST_in = (AST)_t;
		
		r = new NumberType(-1); // default to some error condition
		
		if (a instanceof StringType) {
			Process p = null;
			try {
			    String command = ((StringType)a).getValue();
			    p = Runtime.getRuntime().exec(command);
			    try {
				p.waitFor(); // block pCG program until the command exits
			    } catch (InterruptedException e) {
				// Do nothing except get return value after catch block.
			    }
			    r = new NumberType(p.exitValue());
			} catch (IOException e) {
			    r = new NumberType(p.exitValue());
			} 
		} else {
			String msg = "system command must be a string.";
			throw new SemanticException(msg);
		} 
		
		
		_retTree = _t;
		return r;
	}
	
	public final Type  funApply(AST _t,
		Type a, Type b
	) throws RecognitionException {
		Type r;
		
		AST funApply_AST_in = (AST)_t;
		
		r = UndefinedType.undefined;
		
		if (a instanceof FunctionType && b instanceof ListType) {
			FunctionType f = (FunctionType)a;
			ListType actuals = (ListType)b;
			r = funCall(_t, f, actuals.getValue());
		} else {
			String msg = "function and argument list" +
			" expected, " + a.getType() + 
			" and " + b.getType() + " found.";
			throw new SemanticException(msg);
		}
		
		
		_retTree = _t;
		return r;
	}
	
	public final Type  condition(AST _t) throws RecognitionException {
		Type r;
		
		AST condition_AST_in = (AST)_t;
		
		Type c = UndefinedType.undefined;
		r = UndefinedType.undefined;
		
		
		AST __t77 = _t;
		AST tmp35_AST_in = (AST)_t;
		match(_t,CONDITION);
		_t = _t.getFirstChild();
		c=expr(_t);
		_t = _retTree;
		_t = __t77;
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			r = c;
		}
		_retTree = _t;
		return r;
	}
	
	public final void block(AST _t) throws RecognitionException {
		
		AST block_AST_in = (AST)_t;
		
		AST __t79 = _t;
		AST tmp36_AST_in = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getFirstChild();
		{
		_loop81:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_tokenSet_1.member(_t.getType()))) {
				statement(_t);
				_t = _retTree;
			}
			else {
				break _loop81;
			}
			
		} while (true);
		}
		_t = __t79;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final LinkedList  actualArgs(AST _t) throws RecognitionException {
		LinkedList list;
		
		AST actualArgs_AST_in = (AST)_t;
		
		list = new LinkedList();
		Type a = UndefinedType.undefined;
		Type b = UndefinedType.undefined;
		
		
		AST __t125 = _t;
		AST tmp37_AST_in = (AST)_t;
		match(_t,ACTUAL_ARGS);
		_t = _t.getFirstChild();
		{
		_loop127:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_tokenSet_2.member(_t.getType()))) {
				a=expr(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					list.add(a);
				}
			}
			else {
				break _loop127;
			}
			
		} while (true);
		}
		_t = __t125;
		_t = _t.getNextSibling();
		_retTree = _t;
		return list;
	}
	
	public final Type  funCall(AST _t,
		Type obj, LinkedList args
	) throws RecognitionException {
		Type r;
		
		AST funCall_AST_in = (AST)_t;
		
		FormalParameter[] formals = null;
		Type[] actuals = new Type[0];
		r = UndefinedType.undefined;
		FunctionType func = (FunctionType)obj;
		
		// Get formal and actual parameter lists.
		formals = func.getFormals();
		actuals = (Type[])args.toArray(actuals);
			
			// Proceed if there's no parameter length mismatch.
		if (formals.length == actuals.length) {
			    // Bind formal parameters to actuals in new scope. May be 0.
				Scope locals = scopes.push(new Scope());
				for (int i=0;i<formals.length;i++) {
					locals.def(formals[i].getName(), actuals[i]);
				}	
		
				// Define a "me" parameter which refers to this function.
				// This permits i) uniform error messages which refer to
				// the current function's name, and ii) anonymous recursive
				// functions.
				locals.def("me", func);
			
				// Is this a closure? If so, push the environment that existed
				// at the time of the definition. Note that this may override 
				// current variable values which may have "evolved" in the 
				// intervening period. Pushing this last ensures that the
				// closure's environment is updated, e.g. if variable x
				// exists in env and x is modified, it will be env's x, not
				// say, some x in the frame containing function parameters 
				// that will be modified. A consequence of pushing env last
				// is that local variables will now go into env, as will
				// return values. Another approach would simply be to
				// merge the locals scope above with this one. 
				Scope env = func.getEnv();
				if (env != null) {
					scopes.push(env);
				}
				
				// Evaluate the body of the function, handling
				// a return statement by catching an exception.
				try {				    	
					block(func.getCode());
				} catch(ReturnException e) {
					// Can get return value here or below.
					// Makes more sense here since r is 
					// otherwise undefined.
					r = scopes.peek().getReturnValue();
				}
				
				// Did we push an envionment above?
				if (env != null) {
					scopes.pop();
				} 
		
				// Pop function's local scope.
				scopes.pop();   
		} else {
				String msg = "parameter list length mismatch";
				throw new SemanticException(msg);
		}
		
		
		_retTree = _t;
		return r;
	}
	
/**
 * Mutate a copy of an actor's defining graph by executing its sub-actors.
 *
 * A sub-actor cannot execute until all its input concept referents
 * are bound. A sub-actor is either a user-defined pCG function or
 * another actor, permitting recursive actors.
 *
 * Input concept referents are assumed to be pCG literals. Note
 * that this does not include marker or descriptor referents.
 *
 * User-defined functions are passed input and output concepts.  
 */
	public final Type  actorCall(AST _t,
		Type obj, LinkedList args, boolean bindSinkToSource
	) throws RecognitionException {
		Type r;
		
		AST actorCall_AST_in = (AST)_t;
		
		FormalParameter[] formals = null;
		Type[] actuals = new Type[0];
		ActorType actor = (ActorType)obj; // precondition: obj is an actor
		r = UndefinedType.undefined;
		
		// Get actual parameter list.
		//
		// If null, assume this actor's defining graph already 
		// has bound source concept designators. This would be
		// true where no explicit actor type definition is
		// present, i.e. an anonymous actor.
		if (args != null) {
			actuals = (Type[])args.toArray(actuals);
		}
		
		// In the case where an anonymous actor is created,
		// it is assumed to have been created with a zero-length
		// formals array. The actuals array will already
		// be zero length (as created above), except in the case 
		// of a recursive anonymous actor where the initial actor
		// will indeed have been created with a zero-length formals
		// array, but there will be actuals passed, and we will have
		// to bind these!! In this case, formals.length will be 0 
		// while actuals.length will be a positive integer. But,
		// since an anonymous recursive actor will have no name 
		// designators in its source concepts, there will be no
		// names to bind to, so unless some source argument order
		// is assumed, anonymous recursive actors cannot be fully
		// implemented.
		if (actor.getFormals().length == actuals.length || bindSinkToSource) {
			// Make a copy of the defining graph.
			actor = (ActorType)actor.copy();
		
			// Bind actuals by source concept designator formal names 
			// or by source concept ordering?
			if (bindSinkToSource) {
			    actor.bindParametersToSourceConcepts(actuals);
			} else if (actuals.length > 0) {
			    actor.bindParameters(actuals);
			}
		
			// If any source arguments remain unbound and a suitably named
			// coference variable is defined, bind the source argument's
			// designator to this coreference variable. This is primarily
			// motivated by the fact that some graph projections may not
			// always result in all concept designators being bound, and 
			// that existing coreference variables may fulfill this need.
			// Indeed, some of Mineau's examples rely upon such coreference
			// being global (and he says this should be the case). I have
			// restricted the scope to the current knowledge base however.
			// Should this be extended to unbound sink concepts after
			// actor activation? No, since this means that an actor failed
			// to generate a result!
			ConceptType[] sources = ActorType.getSources(actor.getBody());
			for (int i=0;i<sources.length;i++) {
			    if (sources[i].hasVarDesignator()) {
				String name =
				    ((StringType)sources[i].getDesignatorValue()).getValue();
				Type value = kbases.peek().getCorefVarValue(name);
				if (!(value instanceof UndefinedType)) {
				    sources[i].setDesignatorValue(value);
				} 
			    }
			}
		
			// Invoke the actor and each of its subactors.
			actor.initActorExecution();
			while (actor.isExecutable()) {
			    SubActorInfo info = actor.getNextSubActor();
			    if (info == null) {
				// There are sub-actors on the run-list but none 
				// is ready for execution, so stop and return what
				// we have.
				break;
			    }
			    
			    if (trace) {
				System.out.println("TRACE: Invoking sub-actor \"" + info +
						   "\" in actor \"" + actor.getId() 
						   + "\"");
				
				ConceptType[] concepts = ActorType.getSinks(actor.
									    getBody());
			    }
			    
			    if (info.executor instanceof FunctionType) {
				// Invoke a function, mutating the graph of the 
				// executor as a result.
				LinkedList funArgs = new LinkedList();
				funArgs.addAll(info.inArgs);
				funArgs.addAll(info.outArgs);
				funCall(_t, info.executor, funArgs); // _t unused; see src
			    } else if (info.executor instanceof ActorType) {
				// Get designators from info.inArgs to give input args.
				// It is a precondition that each inArgs member is of type
				// ConceptType. We'll pass Type values to the actor.
				LinkedList actorArgs = new LinkedList();
				for (int i=0;i<info.inArgs.size();i++) {
				    ConceptType input = (ConceptType)info.inArgs.get(i);
				    actorArgs.add(input.getDesignatorValue());
				}
				// Invoke actor with input args.
				// _t (same as #ast in call?) is unused. 
				// See source generated by ANTLR.
				// Note that a copy of the defining graph will be
				// made upon this recursive call.
		
				// Is this a recursive anonymous actor? If so, tell
				// actorCall() to directly bind actuals to source concept 
				// designators instead of binding by name.
				ActorType subActor = (ActorType)info.executor;
				boolean sinkToSource = false;
				if (subActor.isAnonymous() && info.isSelfReferential) {
				    sinkToSource = true;
				}
				GraphType g;
				try {
				    g = (GraphType)actorCall(_t, subActor, actorArgs,
							     sinkToSource);
				} catch (ClassCastException e) {
				    String msg = "sub-actor '" + subActor.getId() + 
					"' returned an undefined value.";
				    throw new SemanticException(msg);
				}
				
				// Get sink concepts from resulting graph which is a
				// copy of the original sub-actor's graph. The reason for
				// obtaining output concepts via getSinks() here is that
				// the graph may be arbitrarily complex, consisting of
				// nested sub-actors. Contrast the use of getSinks() with
				// ActorType.getNextSubActor().
				ConceptType[] sinks = ActorType.getSinks(g);
				
				// Set corresponding output concepts in info.outArgs
				// assuming the same ordering of output as sink concepts.
				// We *ought* to check the type compatability of the 
				// corresponding concept types. At least check the number
				// of arguments.
				if (sinks.length != info.outArgs.size()) {
				    String msg = "caller actor '" + actor.getId() + 
					"' and callee sub-actor '" + actor.getId() +
					"' differ in output parameter list lengths.";
				    throw new SemanticException(msg);
				} else {
				    for (int i=0;i<sinks.length;i++) {
					ConceptType output = (ConceptType)info.
					    outArgs.get(i);
					output.setDesignatorValue(sinks[i].
								  getDesignatorValue());
				    }
				}
				
				// Set the resulting graph to be the output of this
				// sub-actor invocation, since this now contains the 
				// appropriately mutated concepts. NO! We want the
				// values of the sinks in the returned copied graph!
				//actor = subActor;
			    } else {
				String msg = "a sub-actor must be a function or actor";
				throw new SemanticException(msg);
			    }
			}
			
			// Return the mutated graph copy.
			r = actor.getBody();
		} else {
			String msg = "parameter list length mismatch";
			throw new SemanticException(msg);
		}
		
		
		_retTree = _t;
		return r;
	}
	
/**
 * Return a graph with name designators replaced by literal 
 * values or markers.
 */
	public final Type  lambdaCall(AST _t,
		Type obj, LinkedList args
	) throws RecognitionException {
		Type r;
		
		AST lambdaCall_AST_in = (AST)_t;
		
		FormalParameter[] formals = null;
		Type[] actuals = new Type[0];
		LambdaType lambda = (LambdaType)obj;
		r = UndefinedType.undefined;
		
		// Get actual parameter list.
		actuals = (Type[])args.toArray(actuals);
		
		if (lambda.getFormals().length == actuals.length) {
			// Get a copy of the defining graph.
			lambda = lambda.copy();
		
			// Bind source concept designators to actual parameters
			// and return the mutated graph copy.
			lambda.bindParameters(actuals);
			r = lambda.getBody();
		} else {
			String msg = "parameter list length mismatch";
			throw new SemanticException(msg);
		}
		
		
		_retTree = _t;
		return r;
	}
	
/**
 * Invoke a process -- the main point of pCG.
 */
	public final Type  processCall(AST _t,
		Type obj, LinkedList args
	) throws RecognitionException {
		Type r;
		
		AST processCall_AST_in = (AST)_t;
		
		FormalParameter[] formals = null;
		Type[] actuals = new Type[0];
		r = UndefinedType.undefined;
		ProcessType process = (ProcessType)obj;
		GraphType[] preParams = null;
		GraphType[] assertParams = null;
		GraphType[] retractParams = null;
		
		// Get formal and actual parameter lists.
		formals = process.getFormals();
		actuals = (Type[])args.toArray(actuals);
		
		if (formals.length == actuals.length) {
			// Create a new scope and KB.
			//
			// Whereas the new scope is used in conjunction with
			// scopes further down the stack as for functions, the 
			// new KB becomes the *active* one and its content is 
			// derived from the one it overrides, i.e. the one before 
			// it on the KB stack. So, the new KB benefits from the
			// graphs asserted previously, but does not pollute earlier
			// KBs, as per Mineau's suggestion that the operations
			// of a process should be local in scope.
			Scope locals = scopes.push(new Scope());
			KBase callerKBase = kbases.peek(); // in case option export enabled
			KBase theKBase = kbases.push(new KBase(kbases.peek()));
		
			// Define a "me" parameter which refers to this process.
			locals.def("me", process);
			
			// Handle actual parameters according to whether
			// the corresponding formal parameter is an input,
			// output, or trigger. All must be contexts, i.e
			// concepts with descriptor graphs as referents.
			//
			// Permitted "in" parameter concept types are: Proposition
			// and Condition, and permitted "out" parameter concept 
			// types are Proposition and Erasure. A major motivation for
			// requiring parameters to be concepts is that (apart from Mineau's
			// suggested usage) this is how they will appear in CGs anyway!
			LinkedList inP = new LinkedList();
			LinkedList assertP = new LinkedList();
			LinkedList retractP = new LinkedList();
			for (int i=0;i<formals.length;i++) {
			    if (actuals[i] instanceof ConceptType) {
				ConceptType p = (ConceptType)actuals[i];
				if (!p.isContext().getValue()) {
				    String msg = "parameters to a process must be contexts.";
				    throw new SemanticException(msg);		
				}
		
				// What is the context's type? Ignore its case.
				String contextType = p.getLabel().getValue().toUpperCase();
		
				// We know that a descriptor exists, so obtain it.
				// This is the graph we're actually interested in.
				GraphType pDesc = (GraphType)p.getDescriptor();
				
				if (formals[i].isIn()) {
				    if (contextType.equals("PROPOSITION")) {
					// Assert a trigger graph in this process's KB.
					theKBase.assert(pDesc);
				    } else if (contextType.equals("CONDITION")) {
					// Collect graph for use in first rule's precondition.
					inP.add(pDesc);
				    } else {
					String msg = "process 'in' parameters must be " +
					    "contexts of type PROPOSITION or CONDITION.";
					throw new SemanticException(msg);
				    }
				} else if (formals[i].isOut()) {
				    if (contextType.equals("PROPOSITION")) {
					// Collect graph for use in last rule's postcondition.
					assertP.add(pDesc);
				    } else if (contextType.equals("ERASURE")) {
					// Collect graph for use in last rule's postcondition.
					//
					// Note: according to dpANS, this should really be:
					//
					//  (neg)->[ ... ] or ~[ ... ] 
					retractP.add(pDesc);
				    } else {
					String msg = "process 'out' parameters must be " +
					    "contexts of type PROPOSITION or ERASURE.";
					throw new SemanticException(msg);
				    }
				}
			    } else {
				String msg = "parameters to a process must be contexts.";
				throw new SemanticException(msg);		
			    }
			}	
		
			// Make in and out parameters (except triggers) available as arrays.
			preParams = (GraphType[])inP.toArray(new GraphType[0]);
			assertParams = (GraphType[])assertP.toArray(new GraphType[0]);
			retractParams = (GraphType[])retractP.toArray(new GraphType[0]);
		
			// Execute initial block if present.
			AST initialBlock = process.getInitialBlock();
			if (initialBlock != null) {
			    // Execute the block. A ReturnException
			    // may be thrown at which point the process
			    // will be exited. See catch block near end of
			    // this method.
			    block(initialBlock);
			}
			
			// Get the rule set.
			Rule[] rules = process.getRules();
		
			boolean exitRuleReached = false;
		
			try {				
			    // Continue to iterate over the rule set while there are
			    // matches occurring. If all rules are iterated over and
			    // no pre-condition of any rule matches, there is nothing
			    // left to do since the process will never change the state
			    // of the KB. On a given match iteration, if a matching rule
			    // is found, the for loop should be exited since we can't say
			    // where in the rule set a match on the next iteration (of
			    // the outer loop) will occur -- it could be the next rule
			    // in sequence, or the first rule, or anywhere in between.
			    boolean matchOccurred;
			    do {
				matchOccurred = false;
		
				// Iterate over each rule in the rule set, executing action 
				// blocks, looking for matching preconditions and executing 
				// post-condition blocks. There may be no rules in which case 
				// we'll never enter this loop, and wouldn't *that* be dull!
				for (int i=0;i<rules.length;i++) {
				    // Get next rule.
				    Rule rule = rules[i];
				    
				    // Execute precondition action block if present.
				    AST preActionBlock = rule.getPreconditionActionBlock();
				    if (preActionBlock != null) {
					// Execute the block. A ReturnException may be
					// thrown, at which point the process will exit.
					// See catch block near end of this method.
					block(preActionBlock);
				    }
		
				    // Innocent until proven guilty.
				    boolean allMatch = true;
		
				    // Collect all matches for a current rule test
				    // and make available as a special variable in
				    // the current scope.
				    ListType matches = new ListType();
				    scopes.peek().def("_MATCHES", matches);
		
				    // Determine whether all pre-condition graphs match.
				    // This includes preconditions passed as input parameters,
				    // which are assumed to be included in the rule zero.
				    // If one doesn't match, don't evaluate any more.
				    // If they all match, execute the post-condition block.
		
				    if (i == 0) {
					for (int j=0;j<preParams.length;j++) {
					    if (!matchFound(_t, preParams[j], theKBase, 
							    matches)) {
						allMatch = false;
						break;
					    }			    
					}
				    }
		
				    if (allMatch) {
					AST[] preconditions = rule.getMatchExpressions();
					for (int j=0;j<preconditions.length;j++) {
					    // Get the next (hopefully) graph to be matched.
					    Type value = matchExpression(preconditions[j]);
		
					    // Attempt a match.
					    boolean isMatch = 
						matchFound(_t, value, theKBase, matches);
		
					    // Is this graph to be negated?
					    if (rule.getMatchGraphNegation(j)) { 
						isMatch = !isMatch;
					    }
		
					    if (!isMatch) {
						allMatch = false;
						break;
					    }
					}
				    }
				    
				    if (allMatch) {
					// Execute postcondition action block if present.
					AST postActionBlock = 
					    rule.getPostconditionActionBlock();
					if (postActionBlock != null) {
					    // Execute the block. A ReturnException may be
					    // thrown, at which point the process will exit.
					    // See catch block near end of this method.
					    block(postActionBlock);
					}
		
					// Mutate the current KB with the postconditions.
					AST[] postconditions = rule.getMutateKBExpressions();
					for (int j=0;j<postconditions.length;j++) {
					    // Get the next (hopefully) singleton graph and
					    // its options.
					    Type value = mutateKBExpression(postconditions[j]);
					    boolean export = rule.getMutateGraphExportOpt(j);
					    mutateKB(_t, value, export, rule, 
						     theKBase, callerKBase);
					}
		
					matchOccurred = true;
		
					// The final rule is a special case. If its 
					// precondition matches, its postconditions will 
					// be handled above as normal, but then the process
					// will exit after any output parameters are 
					// asserted/retracted in the caller's KB, rather 
					// than restarting a search for matches at the start 
					// of the rule set again.
					//
					// TBD: It may be preferable to permit multiple rules 
					// to be designated exit (or export) points for 
					// increased flexibility. This is similar to the way 
					// in which a function may return at any point.
					
					if (i == rules.length-1) {
					    exitRuleReached = true;
					}
					
					// A rule has matched on this round, so start
					// at the top for the next matching round (unless
					// this is the last rule, as detailed above).
					break;
				    }
				}
			    } while (matchOccurred && !exitRuleReached);
			} catch(ReturnException e) {
			    // Get return value and pop current scope and KB.
			    // Under normal circumstances, this will be undefined
			    // since a process should end with assertions/retractions.
			    r = locals.getReturnValue();
			}
		
			// Cleanup the scope and KB stack.
			scopes.pop();    
			KBase processKB = kbases.pop();
		
			// If the final rule was matched, bind coreference variables in
			// the rule's postcondition graphs using the process's KB, then
			// assert/retract these graphs in the caller's KB.
			if (exitRuleReached) {
			    KBase callerKB = kbases.peek();
		
			    for (int i=0;i<assertParams.length;i++) {
				GraphType g = assertParams[i];
				processKB.bindCorefVars(g);
				callerKB.assert(g, false); // false = don't bind vars
			    }
		
			    for (int i=0;i<retractParams.length;i++) {
				GraphType g = retractParams[i];
				processKB.bindCorefVars(g);
				callerKB.retract(g, false); // false = don't bind vars
			    }
			}
		} else {
			String msg = "parameter list length mismatch.";
			throw new SemanticException(msg);
		}
		
		
		_retTree = _t;
		return r;
	}
	
	public final Type  matchExpression(AST _t) throws RecognitionException {
		Type r;
		
		AST matchExpression_AST_in = (AST)_t;
		
		r = UndefinedType.undefined;
		
		
		AST __t91 = _t;
		AST tmp38_AST_in = (AST)_t;
		match(_t,MATCH_EXPRESSION);
		_t = _t.getFirstChild();
		r=expr(_t);
		_t = _retTree;
		_t = __t91;
		_t = _t.getNextSibling();
		_retTree = _t;
		return r;
	}
	
	public final Type  mutateKBExpression(AST _t) throws RecognitionException {
		Type r;
		
		AST mutateKBExpression_AST_in = (AST)_t;
		
		r = UndefinedType.undefined;
		
		
		AST __t93 = _t;
		AST tmp39_AST_in = (AST)_t;
		match(_t,MUTATE_KB_EXPRESSION);
		_t = _t.getFirstChild();
		r=expr(_t);
		_t = _retTree;
		_t = __t93;
		_t = _t.getNextSibling();
		_retTree = _t;
		return r;
	}
	
	public final boolean  matchFound(AST _t,
		Type value, KBase theKBase, ListType matches
	) throws RecognitionException {
		boolean matched;
		
		AST matchFound_AST_in = (AST)_t;
		
		matched = false;
		
		if (value instanceof GraphType) {
			// Take a copy since it may be mutated below, e.g. see
			// isActorWithProjections case below.
			GraphType g = ((GraphType)value).copy();
			
			boolean isExact = false;
			boolean isValidProjection = false;
			boolean isActorWithProjections = false;
			
			// Is this a process invocation?
			// If so, simply invoke it. This case differs
			// from those below in that its invocation
			// is assumed to have some useful side effect
			// on the current KB and there is nothing to
			// match. Match defaults to true, as above.
			Type actorNode = getSingletonActorNode(_t, g);
			if (actorNode instanceof ProcessType) {
			    LinkedList args = g.getConcepts().getValue();
			    // In this context, any return value cannot 
			    // be utilised, so ignore it. 
			    Type r = processCall(_t, actorNode, args);
			} else {
			    // Try an exact match on each graph in the
			    // KB first, as this may be quite common.
			    // Otherwise try a projection on each graph
			    // in the KB. If this does not work, it may
			    // be because we are dealing with an actor
			    // being to glue together graphs from different
			    // parts of the KB. If this is so, we must
			    // attempt to project each graph in the
			    // actor graph against the KB's content.
			    // Note: I cannot see how anything other
			    // than an actor graph makes sense in the
			    // latter case, otherwise just what do we
			    // *mean* by a match?
			    isExact = theKBase.exactMatch(g);
			    if (isExact && !g.containsActorNodes()) { 
				// Collect non-actor graph with exact match.
				// If the graph is also an actor, it will be 
				// collected later (see below).
				matches.append(g);
			    }
		
			    if (!isExact) {
				GraphType pG = theKBase.projectionMatch(g);
				isValidProjection = pG != null;
		
				// Check that all variables are bound. This should
				// probably be done by the projection operation itself. (TBD)
				// It won't be valid to do this if the graph is an actor
				// since there may well be unbound variables!
				if (isValidProjection && !g.containsActorNodes()) {
				    ConceptType[] concepts = 
					(ConceptType[])pG.getConcepts().getValue().
					     toArray(new ConceptType[0]);
				    for (int i=0;i<concepts.length;i++) {
					if (concepts[i].hasVarDesignator()) {
					    isValidProjection = false;
					    break;
					}
				    }
				}
		
				if (isValidProjection) {
				    // Use this for future processing, i.e. actors.
				    // We could just rely upon coreferent variables being
				    // set by the projection's restrictions, but this is
				    // less efficient than using what's already there in
				    // the projection.
				    g = pG;
				    if (!g.containsActorNodes()) {
					// Collect non-actor graph with valid projection.
					// If the graph is also an actor, it will be 
					// collected later (see below).
					matches.append(g);
				    }		    
				}
			    }
		
			    if (!isExact && !isValidProjection && g.containsActorNodes()) {
				// Isolate each conceptual relation, create a graph
				// from it, and attempt a projection with it. The big
				// assumption here is that the actor's arguments are
				// part of single-relation graphs. If they are not, then 
				// the following is invalid since the whole sub-graph in
				// question (attached to an actor argument) should be
				// projected against the KB's graphs. So, a precondition
				// is that actor sources -- and sinks for that matter --
				// are single-relation graphs. The motto is, always
				// keep actors (and all graphs where possible), simple
				// for matching purposes.
		
				isActorWithProjections = true;
				Relation[] relations = g.getValue().getRelations();
				for (int i=0;i<relations.length;i++) {
				    // We don't examine actor relations, because
				    // it is assumed they will never be part of a
				    // graph in the KB. Another big assumption!
				    // If there are only actor relations, we have
				    // an otherwise blank graph which should match
				    // with anything! Flying thick and fast here!
				    // I've opened a can of works with respect to
				    // the meaning of "match".
				    //
				    // Once a projection is found, any coreference 
				    // variables from the projection's restrictions 
				    // will be bound to the desired values, for 
				    // subsequent use by the actor. In this case
				    // (as opposed to the single projection case
				    // above), doing so is simpler and more efficient
				    // than trying to bind the values in the original
				    // graph based upon the projection graph explicitly.
				    if (!(relations[i] instanceof Actor)) {
					GraphType subG = new GraphType(relations[i]);
					GraphType pG = theKBase.projectionMatch(subG);
					boolean isProjection = pG != null;
					
					if (!isProjection) {
					    isActorWithProjections = false;
					    break;
					}
				    }
				}
			    }
			    
			    if (isExact || isValidProjection || isActorWithProjections) {
				// Irrespective of the kind of match that took place, 
				// check for an actor in the graph and activate if present.
				if (g.containsActorNodes()) {
				   ActorType anonActor = new ActorType(g);
				   // Invoke actor with no arguments, since it is assumed
				   // to already have bound inputs.
				   GraphType h = (GraphType)actorCall(_t, anonActor, 
								      null, false);
				    
				   // Do the actual outputs match the target outputs? 
				   // Also need to check that original and current designators
				   // are not the same reference in case of a default value 
				   // having been used!
				    ConceptType[] targetSinks = ActorType.getSinks(g);
				    ConceptType[] actualSinks = ActorType.getSinks(h);
				    for (int k=0;k<targetSinks.length;k++) {
					Type targetDes, actualDes;
					targetDes = targetSinks[k].getDesignatorValue();
					actualDes = actualSinks[k].getDesignatorValue();
					if (trace) {
					    System.out.println("TRACE: " +
							       "\n target -> " + targetDes +
							       "\n actual -> " + actualDes +
							       "\n target type-> " + 
							       targetDes.getType() +
							       "\n actual type-> " + 
							       actualDes.getType() +
							       "\n target == actual: " +
							       (targetDes == actualDes) +
							       "\n target eq actual: " +
							       targetDes.equals(actualDes));
					}
		
					// A match occurs if one of the following is true:
					//
					// 1. The original sink had a variable designator
					//    (?x, *x) and the computed sink does not, i.e.
					//    the sink's referent has been computed.
					//
					// 2. The original sink didn't have a variable 
					//    designator and the value of the computed 
					//    sink's referent matches the original's,
					//    i.e. the original sink had a default
					//    referent value against which a comparison
					//    must be made.
					if (targetSinks[k].hasVarDesignator() &&
					    !actualSinks[k].hasVarDesignator()) {
					    String name = ((StringType)targetDes).getValue();
					    theKBase.addCorefVarMapping(name, actualDes);
					    matched = true;
					    // Collect result of actor activation.
					    matches.append(h);
					    break;
					}
		
					if (!targetSinks[k].hasVarDesignator() &&
					    targetDes != actualDes && 
					    targetDes.equals(actualDes)) {
					    matched = true;
					    // Collect result of actor activation.
					    matches.append(h);
					    break;
					}
				    }
				} else {
				    // No actors, so equivalent graphs or 
				    // valid projections means a match.
				    matched = true;
				}	
			    }
			}
		} else {			    
			String msg = "all process preconditions must be graphs.";
			throw new SemanticException(msg);		
		}
		
		
		_retTree = _t;
		return matched;
	}
	
	public final void mutateKB(AST _t,
		Type value, boolean export, Rule rule, 
	 KBase currKBase, KBase callerKBase
	) throws RecognitionException {
		
		AST mutateKB_AST_in = (AST)_t;
		
		if (value instanceof GraphType) {
			GraphType g = (GraphType)value;
			if (g.getValue().getNumberOfConcepts() == 1 &&
			    g.getValue().getNumberOfRelations() == 0) {
			    // Do we have a context?
			    ConceptType c = new ConceptType(g.getValue().getConcepts()[0]);
			    if (!c.isContext().getValue()) {
				String msg = "process rule postconditions must be contexts.";
				throw new SemanticException(msg);		
			    }
			    // What is the context's type? Ignore its case.
			    String contextType = c.getLabel().getValue().toUpperCase();
			    // Where there is a context there is a descriptor graph, the
			    // object of our interest here.
			    GraphType desc = (GraphType)c.getDescriptor();
		
			    // TBD: Should actor activation be carried out for
			    // postconditions also, followed by coref var binding
			    // (the latter is already done -- see KBase.bindCorefVars())?
			    if (contextType.equals("PROPOSITION")) {
				// Assert a graph into the active KB.
				if (export || 
				    rule.isExportAllOpt() || rule.isExportAssertOpt()) {
				    currKBase.bindCorefVars(desc);
				    callerKBase.assert(desc, false); // false=don't bind vars
				} else {
				    currKBase.assert(desc);
				} 
			    } else if (contextType.equals("ERASURE")) {
				// Retract a graph from the active KB.
				if (export || 
				    rule.isExportAllOpt() || rule.isExportRetractOpt()) {
				    currKBase.bindCorefVars(desc);
				    callerKBase.retract(desc, false); // false=don't bind vars
				} else {
				    currKBase.retract(desc);
				} 
		
			    } else {
				String msg = "process postconditions must be " +
				    "contexts of type PROPOSITION or ERASURE.";
				throw new SemanticException(msg);
			    }	    
			} else {
			    String msg = "process rule postconditions must be contexts.";
			    throw new SemanticException(msg);				    
			}				    
		}
		
		
		_retTree = _t;
	}
	
	public final Type  operationExpr(AST _t) throws RecognitionException {
		Type r;
		
		AST operationExpr_AST_in = (AST)_t;
		AST name = null;
		AST attrName = null;
		
		LinkedList args = null; // for member function call
		Type a = UndefinedType.undefined;
		Type b = UndefinedType.undefined;
		r = UndefinedType.undefined;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OR:
			{
				AST __t102 = _t;
				AST tmp40_AST_in = (AST)_t;
				match(_t,OR);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t102;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.orOp(b);
				}
				break;
			}
			case AND:
			{
				AST __t103 = _t;
				AST tmp41_AST_in = (AST)_t;
				match(_t,AND);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t103;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.andOp(b);
				}
				break;
			}
			case GT:
			{
				AST __t104 = _t;
				AST tmp42_AST_in = (AST)_t;
				match(_t,GT);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t104;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.gtOp(b);
				}
				break;
			}
			case LT:
			{
				AST __t105 = _t;
				AST tmp43_AST_in = (AST)_t;
				match(_t,LT);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t105;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.ltOp(b);
				}
				break;
			}
			case GE:
			{
				AST __t106 = _t;
				AST tmp44_AST_in = (AST)_t;
				match(_t,GE);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t106;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.geOp(b);
				}
				break;
			}
			case LE:
			{
				AST __t107 = _t;
				AST tmp45_AST_in = (AST)_t;
				match(_t,LE);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t107;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.leOp(b);
				}
				break;
			}
			case EQ:
			{
				AST __t108 = _t;
				AST tmp46_AST_in = (AST)_t;
				match(_t,EQ);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t108;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.eqOp(b);
				}
				break;
			}
			case NE:
			{
				AST __t109 = _t;
				AST tmp47_AST_in = (AST)_t;
				match(_t,NE);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t109;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.neOp(b);
				}
				break;
			}
			case IS:
			{
				AST __t110 = _t;
				AST tmp48_AST_in = (AST)_t;
				match(_t,IS);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t110;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.isOp(b);
				}
				break;
			}
			case PLUS:
			{
				AST __t111 = _t;
				AST tmp49_AST_in = (AST)_t;
				match(_t,PLUS);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t111;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.addOp(b);
				}
				break;
			}
			case MUL:
			{
				AST __t116 = _t;
				AST tmp50_AST_in = (AST)_t;
				match(_t,MUL);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t116;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.multiplyOp(b);
				}
				break;
			}
			case LITERAL_div:
			{
				AST __t117 = _t;
				AST tmp51_AST_in = (AST)_t;
				match(_t,LITERAL_div);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t117;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.divideOp(b);
				}
				break;
			}
			case LITERAL_mod:
			{
				AST __t118 = _t;
				AST tmp52_AST_in = (AST)_t;
				match(_t,LITERAL_mod);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t118;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.modulusOp(b);
				}
				break;
			}
			case NOT:
			{
				AST __t120 = _t;
				AST tmp53_AST_in = (AST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				_t = __t120;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.notOp();
				}
				break;
			}
			case MEMBER_FUNCALL:
			{
				AST __t121 = _t;
				AST tmp54_AST_in = (AST)_t;
				match(_t,MEMBER_FUNCALL);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				name = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				args=actualArgs(_t);
				_t = _retTree;
				_t = __t121;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.invokeMemberFunc(name.getText(), args.toArray());
				}
				break;
			}
			case LIST_SELECTION:
			{
				AST __t122 = _t;
				AST tmp55_AST_in = (AST)_t;
				match(_t,LIST_SELECTION);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				b=expr(_t);
				_t = _retTree;
				_t = __t122;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.getNthOp(b);
				}
				break;
			}
			case ATTR_SELECTION:
			{
				AST __t123 = _t;
				AST tmp56_AST_in = (AST)_t;
				match(_t,ATTR_SELECTION);
				_t = _t.getFirstChild();
				a=expr(_t);
				_t = _retTree;
				attrName = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				_t = __t123;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					r = a.getAttr(attrName.getText());
				}
				break;
			}
			default:
				boolean synPredMatched114 = false;
				if (((_t.getType()==MINUS))) {
					AST __t114 = _t;
					synPredMatched114 = true;
					inputState.guessing++;
					try {
						{
						AST __t113 = _t;
						AST tmp57_AST_in = (AST)_t;
						match(_t,MINUS);
						_t = _t.getFirstChild();
						expr(_t);
						_t = _retTree;
						expr(_t);
						_t = _retTree;
						_t = __t113;
						_t = _t.getNextSibling();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched114 = false;
					}
					_t = __t114;
					inputState.guessing--;
				}
				if ( synPredMatched114 ) {
					AST __t115 = _t;
					AST tmp58_AST_in = (AST)_t;
					match(_t,MINUS);
					_t = _t.getFirstChild();
					a=expr(_t);
					_t = _retTree;
					b=expr(_t);
					_t = _retTree;
					_t = __t115;
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						r = a.subtractOp(b);
					}
				}
				else if ((_t.getType()==MINUS)) {
					AST __t119 = _t;
					AST tmp59_AST_in = (AST)_t;
					match(_t,MINUS);
					_t = _t.getFirstChild();
					a=expr(_t);
					_t = _retTree;
					_t = __t119;
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						r = a.negateOp();
					}
				}
			else {
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (IllegalArgumentException e) {
			if (inputState.guessing==0) {
				
					      String msg = "can't apply " + e.getMessage() + 
					                   " operation to values of type " + a.getType();
					      if (b != UndefinedType.undefined) {
						  // Dyadic.
						  msg += " and " + b.getType() + "."; 
					      } else {
						  // Monadic.
						  msg += "."; 
					      }
					      throw new SemanticException(msg);
					
			} else {
				throw e;
			}
		}
		catch (IndexOutOfBoundsException e) {
			if (inputState.guessing==0) {
				
					      // List access.
					      String msg = e.getMessage();
					      throw new SemanticException(msg);
					
			} else {
				throw e;
			}
		}
		_retTree = _t;
		return r;
	}
	
	public final Type  factor(AST _t) throws RecognitionException {
		Type r;
		
		AST factor_AST_in = (AST)_t;
		AST num = null;
		AST str = null;
		AST g1 = null;
		AST g2 = null;
		AST theType = null;
		AST t = null;
		AST id = null;
		
		LinkedList list = null;
		Type a = UndefinedType.undefined;
		Type b = UndefinedType.undefined;
		r = UndefinedType.undefined;
		
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMBER:
		{
			num = (AST)_t;
			match(_t,NUMBER);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						    Double d;
						    try {
							d = Double.valueOf(num.getText());
						    } catch(NumberFormatException e) {
							throw new 
							    SemanticException(num + ": illegal number format");
						    }
						    r = new NumberType(d.doubleValue());
						
			}
			break;
		}
		case LITERAL_true:
		case LITERAL_false:
		{
			r=boolValue(_t);
			_t = _retTree;
			break;
		}
		case STRING:
		{
			str = (AST)_t;
			match(_t,STRING);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = new StringType(str.getText());
			}
			break;
		}
		case LIST:
		{
			AST __t129 = _t;
			AST tmp60_AST_in = (AST)_t;
			match(_t,LIST);
			_t = _t.getFirstChild();
			if ( inputState.guessing==0 ) {
				list = new LinkedList();
			}
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				list.addLast(a);
			}
			{
			_loop131:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_2.member(_t.getType()))) {
					b=expr(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						list.addLast(b);
					}
				}
				else {
					break _loop131;
				}
				
			} while (true);
			}
			_t = __t129;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						    r = new ListType(list); 
						
			}
			break;
		}
		case EMPTY_LIST:
		{
			AST __t132 = _t;
			AST tmp61_AST_in = (AST)_t;
			match(_t,EMPTY_LIST);
			_t = _t.getFirstChild();
			if ( inputState.guessing==0 ) {
				r = new ListType();
			}
			_t = __t132;
			_t = _t.getNextSibling();
			break;
		}
		case CONCEPT_LITERAL:
		{
			AST __t133 = _t;
			AST tmp62_AST_in = (AST)_t;
			match(_t,CONCEPT_LITERAL);
			_t = _t.getFirstChild();
			g1 = (AST)_t;
			match(_t,GRAPH_STRING);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = new ConceptType(g1.getText());
			}
			_t = __t133;
			_t = _t.getNextSibling();
			break;
		}
		case GRAPH_LITERAL:
		{
			AST __t134 = _t;
			AST tmp63_AST_in = (AST)_t;
			match(_t,GRAPH_LITERAL);
			_t = _t.getFirstChild();
			g2 = (AST)_t;
			match(_t,GRAPH_STRING);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = new GraphType(g2.getText());
			}
			_t = __t134;
			_t = _t.getNextSibling();
			break;
		}
		case FILE_VALUE:
		{
			AST __t135 = _t;
			AST tmp64_AST_in = (AST)_t;
			match(_t,FILE_VALUE);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						    if (a instanceof StringType) {
							try {
							    r = new FileType(((StringType)a).getValue());
							} catch (IOException e) {
							    // r will have undefined value by default.
							}
						    } else {
							String msg = "file path must be a string.";
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t135;
			_t = _t.getNextSibling();
			break;
		}
		case ANON_FUN_DEF:
		{
			r=anonFunDef(_t);
			_t = _retTree;
			break;
		}
		case NEW_VALUE:
		{
			AST __t136 = _t;
			AST tmp65_AST_in = (AST)_t;
			match(_t,NEW_VALUE);
			_t = _t.getFirstChild();
			theType = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						    // New types must be in defined directory.
						    // Make this arbitrary later?
						    String typeName = theType.getText();
						    String typePath = "cgp.runtime.newtypes." + typeName;
						    try {			    
							Class c = Class.forName(typePath);
							// newInstance() requires parameterless 
							// constructor; improve. Also, check that
							// this is a Type subclass before trying
							// to cast? We'll get a ClassCastException
							// anyway.
							r = (Type)c.newInstance();
						    } catch (Exception e) {
							String msg = "cannot create an instance of " +
							             typeName;
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t136;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case LITERAL_file:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		{
			t = _t==ASTNULL ? null : (AST)_t;
			typeValue(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				r = new StringType(t.getText());
			}
			break;
		}
		case IDENT:
		{
			id = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = scopes.find(id.getText());
			}
			break;
		}
		case LITERAL_system:
		{
			AST __t137 = _t;
			AST tmp66_AST_in = (AST)_t;
			match(_t,LITERAL_system);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				r = systemStatement(_t, a);
			}
			_t = __t137;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_activate:
		{
			AST __t138 = _t;
			AST tmp67_AST_in = (AST)_t;
			match(_t,LITERAL_activate);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						    if (a instanceof GraphType) {
							GraphType g = (GraphType)a;
							if (g.containsActorNodes()) {
							    // Is this an actor or a process?
							    Type actorNode = getSingletonActorNode(_t, g);
							    if (actorNode instanceof ProcessType) {
								LinkedList args = g.getConcepts().getValue();
								r = processCall(_t, actorNode, args);
							    } else {
								// No actual arguments since we are relying
								// upon the source concepts having already
								// been bound. Note that this poses a problem
								// for anonymous recursive actors since the
								// absence of formals (no variables in 
								// designators since latter already bound)
								// makes it impossible to bind actuals by
								// referring to names. Correspondence between
								// actuals and formals therefore becomes order
								// dependent in this situation, i.e. the sink
								// concepts of the preceding executor must 
								// map by order to the source concepts of
								// the recursive actor invocation.
								r = actorCall(_t, new ActorType(g), 
									      null, false);
							    }
							} else {
							    String msg = "invalid actor/process graph.";
							    throw new SemanticException(msg);
							}
						    } else {
							String msg = "actor/process graph expected.";
							throw new SemanticException(msg);
						    }
						
			}
			_t = __t138;
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_apply:
		{
			AST __t139 = _t;
			AST tmp68_AST_in = (AST)_t;
			match(_t,LITERAL_apply);
			_t = _t.getFirstChild();
			a=expr(_t);
			_t = _retTree;
			b=expr(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				r=funApply(_t, a, b);
			}
			_t = __t139;
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
		return r;
	}
	
	public final Type  boolValue(AST _t) throws RecognitionException {
		Type r;
		
		AST boolValue_AST_in = (AST)_t;
		
		r = UndefinedType.undefined;	
		
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_true:
		{
			AST tmp69_AST_in = (AST)_t;
			match(_t,LITERAL_true);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = new BooleanType(true);
			}
			break;
		}
		case LITERAL_false:
		{
			AST tmp70_AST_in = (AST)_t;
			match(_t,LITERAL_false);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r = new BooleanType(false);
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
		return r;
	}
	
	public final FunctionType  anonFunDef(AST _t) throws RecognitionException {
		FunctionType func;
		
		AST anonFunDef_AST_in = (AST)_t;
		AST arg = null;
		AST b = null;
		
		LinkedList formals = new LinkedList();
		func = null; // it *will* be initialised
		
		
		AST __t141 = _t;
		AST tmp71_AST_in = (AST)_t;
		match(_t,ANON_FUN_DEF);
		_t = _t.getFirstChild();
		{
		_loop143:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==IDENT)) {
				arg = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					formals.add(new FormalParameter(arg.getText()));
				}
			}
			else {
				break _loop143;
			}
			
		} while (true);
		}
		b = (AST)_t;
		match(_t,BLOCK);
		_t = _t.getNextSibling();
		if ( inputState.guessing==0 ) {
			
					    func = new FunctionType((FormalParameter[])formals.
								     toArray(new FormalParameter[0]),
								    b);
					
		}
		_t = __t141;
		_t = _t.getNextSibling();
		_retTree = _t;
		return func;
	}
	
	public final void typeValue(AST _t) throws RecognitionException {
		
		AST typeValue_AST_in = (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case LITERAL_number:
		{
			AST tmp72_AST_in = (AST)_t;
			match(_t,LITERAL_number);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_string:
		{
			AST tmp73_AST_in = (AST)_t;
			match(_t,LITERAL_string);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_boolean:
		{
			AST tmp74_AST_in = (AST)_t;
			match(_t,LITERAL_boolean);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_concept:
		{
			AST tmp75_AST_in = (AST)_t;
			match(_t,LITERAL_concept);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_graph:
		{
			AST tmp76_AST_in = (AST)_t;
			match(_t,LITERAL_graph);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_list:
		{
			AST tmp77_AST_in = (AST)_t;
			match(_t,LITERAL_list);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_function:
		{
			AST tmp78_AST_in = (AST)_t;
			match(_t,LITERAL_function);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_lambda:
		{
			AST tmp79_AST_in = (AST)_t;
			match(_t,LITERAL_lambda);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_actor:
		{
			AST tmp80_AST_in = (AST)_t;
			match(_t,LITERAL_actor);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_process:
		{
			AST tmp81_AST_in = (AST)_t;
			match(_t,LITERAL_process);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_file:
		{
			AST tmp82_AST_in = (AST)_t;
			match(_t,LITERAL_file);
			_t = _t.getNextSibling();
			break;
		}
		case LITERAL_undefined:
		{
			AST tmp83_AST_in = (AST)_t;
			match(_t,LITERAL_undefined);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final Type  getSingletonActorNode(AST _t,
		GraphType g
	) throws RecognitionException {
		Type obj;
		
		AST getSingletonActorNode_AST_in = (AST)_t;
		
		obj = UndefinedType.undefined;
		
		Actor[] actorNodes = g.getValue().getActorRelations();
		
		if (actorNodes.length == 1) {
			obj = scopes.find(actorNodes[0].getType().getLabel());
		}
		
		
		_retTree = _t;
		return obj;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"OPTION_LIST",
		"TYPE_DECL",
		"VALUE_SELECTOR",
		"BLOCK",
		"IF_STATEMENT",
		"WHILE_STATEMENT",
		"FOREACH_STATEMENT",
		"CONDITION",
		"FUN_DEF",
		"ANON_FUN_DEF",
		"LAMBDA_DEF",
		"ACTOR_DEF",
		"PROCESS_DEF",
		"RULE_DEF",
		"PRE_DEF",
		"MATCH_EXPRESSION",
		"MUTATE_KB_EXPRESSION",
		"POST_DEF",
		"CALL",
		"ACTUAL_ARGS",
		"VAR_ASSIGN",
		"ATTR_ASSIGN",
		"LIST_ASSIGN",
		"MEMBER_FUNCALL",
		"ATTR_SELECTION",
		"LIST_SELECTION",
		"LIST",
		"CONCEPT_LITERAL",
		"GRAPH_LITERAL",
		"FILE_VALUE",
		"NEW_VALUE",
		"EMPTY_LIST",
		"TYPE_VALUE",
		"AND",
		"OR",
		"IS",
		"NOT",
		"IDENT",
		"\"function\"",
		"\"lambda\"",
		"\"actor\"",
		"\"process\"",
		"GT",
		"SEMI",
		"\"concept\"",
		"\"relation\"",
		"LPAREN",
		"COMMA",
		"RPAREN",
		"\"is\"",
		"\"in\"",
		"\"out\"",
		"\"end\"",
		"\"initial\"",
		"\"rule\"",
		"\"pre\"",
		"\"action\"",
		"TILDE",
		"\"post\"",
		"\"option\"",
		"GETS",
		"STRING",
		"DOT",
		"\"print\"",
		"\"println\"",
		"\"return\"",
		"\"exit\"",
		"\"last\"",
		"\"system\"",
		"\"assert\"",
		"\"retract\"",
		"\"apply\"",
		"\"if\"",
		"\"then\"",
		"\"else\"",
		"\"while\"",
		"\"do\"",
		"\"foreach\"",
		"LBRACK",
		"RBRACK",
		"\"or\"",
		"\"and\"",
		"LT",
		"GE",
		"LE",
		"EQ",
		"NE",
		"PLUS",
		"MINUS",
		"MUL",
		"\"div\"",
		"\"mod\"",
		"\"not\"",
		"\"activate\"",
		"NUMBER",
		"GRAPH_STRING",
		"\"file\"",
		"\"new\"",
		"\"true\"",
		"\"false\"",
		"\"number\"",
		"\"string\"",
		"\"boolean\"",
		"\"graph\"",
		"\"list\"",
		"\"undefined\"",
		"LBRACE",
		"RBRACE",
		"COLON",
		"LETTER",
		"DIGIT",
		"METACHAR",
		"WS",
		"COMMENT"
	};
	
	private static final long _tokenSet_0_data_[] = { 255973168L, 4088L, 0L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 255854336L, 4088L, 0L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 422143615574016L, 70192646326530L, 0L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	}
	
