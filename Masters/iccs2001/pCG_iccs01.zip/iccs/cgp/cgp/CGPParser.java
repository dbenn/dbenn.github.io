// $ANTLR 2.7.0: "CGPParser.g" -> "CGPParser.java"$

    package cgp;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;
/**
 * A conceptual graph language which embodies Guy Mineau's process formalism.
 * Copyright (C) 2000 David Benn
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Conceptual Graph Processes parser.
 *
 * David Benn, June-October 2000
 */
public class CGPParser extends antlr.LLkParser
       implements CGPTokenTypes
 {

protected CGPParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public CGPParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected CGPParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public CGPParser(TokenStream lexer) {
  this(lexer,1);
}

public CGPParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void imaginaryTokenDefinitions() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST imaginaryTokenDefinitions_AST = null;
		
		AST tmp1_AST = null;
		if (inputState.guessing==0) {
			tmp1_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp1_AST);
		}
		match(OPTION_LIST);
		AST tmp2_AST = null;
		if (inputState.guessing==0) {
			tmp2_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp2_AST);
		}
		match(TYPE_DECL);
		AST tmp3_AST = null;
		if (inputState.guessing==0) {
			tmp3_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp3_AST);
		}
		match(VALUE_SELECTOR);
		AST tmp4_AST = null;
		if (inputState.guessing==0) {
			tmp4_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp4_AST);
		}
		match(BLOCK);
		AST tmp5_AST = null;
		if (inputState.guessing==0) {
			tmp5_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp5_AST);
		}
		match(IF_STATEMENT);
		AST tmp6_AST = null;
		if (inputState.guessing==0) {
			tmp6_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp6_AST);
		}
		match(WHILE_STATEMENT);
		AST tmp7_AST = null;
		if (inputState.guessing==0) {
			tmp7_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp7_AST);
		}
		match(FOREACH_STATEMENT);
		AST tmp8_AST = null;
		if (inputState.guessing==0) {
			tmp8_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp8_AST);
		}
		match(CONDITION);
		AST tmp9_AST = null;
		if (inputState.guessing==0) {
			tmp9_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp9_AST);
		}
		match(FUN_DEF);
		AST tmp10_AST = null;
		if (inputState.guessing==0) {
			tmp10_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp10_AST);
		}
		match(ANON_FUN_DEF);
		AST tmp11_AST = null;
		if (inputState.guessing==0) {
			tmp11_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp11_AST);
		}
		match(LAMBDA_DEF);
		AST tmp12_AST = null;
		if (inputState.guessing==0) {
			tmp12_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp12_AST);
		}
		match(ACTOR_DEF);
		AST tmp13_AST = null;
		if (inputState.guessing==0) {
			tmp13_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp13_AST);
		}
		match(PROCESS_DEF);
		AST tmp14_AST = null;
		if (inputState.guessing==0) {
			tmp14_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp14_AST);
		}
		match(RULE_DEF);
		AST tmp15_AST = null;
		if (inputState.guessing==0) {
			tmp15_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp15_AST);
		}
		match(PRE_DEF);
		AST tmp16_AST = null;
		if (inputState.guessing==0) {
			tmp16_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp16_AST);
		}
		match(MATCH_EXPRESSION);
		AST tmp17_AST = null;
		if (inputState.guessing==0) {
			tmp17_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp17_AST);
		}
		match(MUTATE_KB_EXPRESSION);
		AST tmp18_AST = null;
		if (inputState.guessing==0) {
			tmp18_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp18_AST);
		}
		match(POST_DEF);
		AST tmp19_AST = null;
		if (inputState.guessing==0) {
			tmp19_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp19_AST);
		}
		match(CALL);
		AST tmp20_AST = null;
		if (inputState.guessing==0) {
			tmp20_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp20_AST);
		}
		match(ACTUAL_ARGS);
		AST tmp21_AST = null;
		if (inputState.guessing==0) {
			tmp21_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp21_AST);
		}
		match(VAR_ASSIGN);
		AST tmp22_AST = null;
		if (inputState.guessing==0) {
			tmp22_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp22_AST);
		}
		match(ATTR_ASSIGN);
		AST tmp23_AST = null;
		if (inputState.guessing==0) {
			tmp23_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp23_AST);
		}
		match(LIST_ASSIGN);
		AST tmp24_AST = null;
		if (inputState.guessing==0) {
			tmp24_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp24_AST);
		}
		match(MEMBER_FUNCALL);
		AST tmp25_AST = null;
		if (inputState.guessing==0) {
			tmp25_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp25_AST);
		}
		match(ATTR_SELECTION);
		AST tmp26_AST = null;
		if (inputState.guessing==0) {
			tmp26_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp26_AST);
		}
		match(LIST_SELECTION);
		AST tmp27_AST = null;
		if (inputState.guessing==0) {
			tmp27_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp27_AST);
		}
		match(LIST);
		AST tmp28_AST = null;
		if (inputState.guessing==0) {
			tmp28_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp28_AST);
		}
		match(CONCEPT_LITERAL);
		AST tmp29_AST = null;
		if (inputState.guessing==0) {
			tmp29_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp29_AST);
		}
		match(GRAPH_LITERAL);
		AST tmp30_AST = null;
		if (inputState.guessing==0) {
			tmp30_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp30_AST);
		}
		match(FILE_VALUE);
		AST tmp31_AST = null;
		if (inputState.guessing==0) {
			tmp31_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp31_AST);
		}
		match(NEW_VALUE);
		AST tmp32_AST = null;
		if (inputState.guessing==0) {
			tmp32_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp32_AST);
		}
		match(EMPTY_LIST);
		AST tmp33_AST = null;
		if (inputState.guessing==0) {
			tmp33_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp33_AST);
		}
		match(TYPE_VALUE);
		AST tmp34_AST = null;
		if (inputState.guessing==0) {
			tmp34_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp34_AST);
		}
		match(AND);
		AST tmp35_AST = null;
		if (inputState.guessing==0) {
			tmp35_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp35_AST);
		}
		match(OR);
		AST tmp36_AST = null;
		if (inputState.guessing==0) {
			tmp36_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp36_AST);
		}
		match(IS);
		AST tmp37_AST = null;
		if (inputState.guessing==0) {
			tmp37_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp37_AST);
		}
		match(NOT);
		imaginaryTokenDefinitions_AST = (AST)currentAST.root;
		returnAST = imaginaryTokenDefinitions_AST;
	}
	
	public final void program() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST program_AST = null;
		
		{
		_loop4:
		do {
			if ((_tokenSet_0.member(LA(1)))) {
				topLevelStatement();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop4;
			}
			
		} while (true);
		}
		program_AST = (AST)currentAST.root;
		returnAST = program_AST;
	}
	
	public final void topLevelStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST topLevelStatement_AST = null;
		
		boolean synPredMatched7 = false;
		if (((LA(1)==LITERAL_concept||LA(1)==LITERAL_relation))) {
			int _m7 = mark();
			synPredMatched7 = true;
			inputState.guessing++;
			try {
				{
				nodeKind();
				match(IDENT);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched7 = false;
			}
			rewind(_m7);
			inputState.guessing--;
		}
		if ( synPredMatched7 ) {
			typeDecl();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			topLevelStatement_AST = (AST)currentAST.root;
		}
		else {
			boolean synPredMatched9 = false;
			if (((LA(1)==LITERAL_function))) {
				int _m9 = mark();
				synPredMatched9 = true;
				inputState.guessing++;
				try {
					{
					match(LITERAL_function);
					match(IDENT);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched9 = false;
				}
				rewind(_m9);
				inputState.guessing--;
			}
			if ( synPredMatched9 ) {
				funDef();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				topLevelStatement_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched11 = false;
				if (((LA(1)==LITERAL_lambda))) {
					int _m11 = mark();
					synPredMatched11 = true;
					inputState.guessing++;
					try {
						{
						match(LITERAL_lambda);
						match(IDENT);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched11 = false;
					}
					rewind(_m11);
					inputState.guessing--;
				}
				if ( synPredMatched11 ) {
					lambdaDef();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					topLevelStatement_AST = (AST)currentAST.root;
				}
				else {
					boolean synPredMatched13 = false;
					if (((LA(1)==LITERAL_actor))) {
						int _m13 = mark();
						synPredMatched13 = true;
						inputState.guessing++;
						try {
							{
							match(LITERAL_actor);
							match(IDENT);
							}
						}
						catch (RecognitionException pe) {
							synPredMatched13 = false;
						}
						rewind(_m13);
						inputState.guessing--;
					}
					if ( synPredMatched13 ) {
						actorDef();
						if (inputState.guessing==0) {
							astFactory.addASTChild(currentAST, returnAST);
						}
						topLevelStatement_AST = (AST)currentAST.root;
					}
					else {
						boolean synPredMatched15 = false;
						if (((LA(1)==LITERAL_process))) {
							int _m15 = mark();
							synPredMatched15 = true;
							inputState.guessing++;
							try {
								{
								match(LITERAL_process);
								match(IDENT);
								}
							}
							catch (RecognitionException pe) {
								synPredMatched15 = false;
							}
							rewind(_m15);
							inputState.guessing--;
						}
						if ( synPredMatched15 ) {
							processDef();
							if (inputState.guessing==0) {
								astFactory.addASTChild(currentAST, returnAST);
							}
							topLevelStatement_AST = (AST)currentAST.root;
						}
						else if ((LA(1)==LITERAL_option)) {
							optionList();
							if (inputState.guessing==0) {
								astFactory.addASTChild(currentAST, returnAST);
							}
							topLevelStatement_AST = (AST)currentAST.root;
						}
						else if ((_tokenSet_1.member(LA(1)))) {
							statement();
							if (inputState.guessing==0) {
								astFactory.addASTChild(currentAST, returnAST);
							}
							topLevelStatement_AST = (AST)currentAST.root;
						}
						else {
							throw new NoViableAltException(LT(1), getFilename());
						}
						}}}}
						returnAST = topLevelStatement_AST;
					}
					
	public final void nodeKind() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST nodeKind_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_concept:
		{
			AST tmp38_AST = null;
			if (inputState.guessing==0) {
				tmp38_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp38_AST);
			}
			match(LITERAL_concept);
			nodeKind_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_relation:
		{
			AST tmp39_AST = null;
			if (inputState.guessing==0) {
				tmp39_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp39_AST);
			}
			match(LITERAL_relation);
			nodeKind_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = nodeKind_AST;
	}
	
	public final void typeDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST typeDecl_AST = null;
		
		nodeKind();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp40_AST = null;
		if (inputState.guessing==0) {
			tmp40_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp40_AST);
		}
		match(IDENT);
		{
		_loop18:
		do {
			if ((LA(1)==GT)) {
				AST tmp41_AST = null;
				tmp41_AST = (AST)astFactory.create(LT(1));
				match(GT);
				AST tmp42_AST = null;
				if (inputState.guessing==0) {
					tmp42_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp42_AST);
				}
				match(IDENT);
			}
			else {
				break _loop18;
			}
			
		} while (true);
		}
		AST tmp43_AST = null;
		tmp43_AST = (AST)astFactory.create(LT(1));
		match(SEMI);
		if ( inputState.guessing==0 ) {
			typeDecl_AST = (AST)currentAST.root;
			typeDecl_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_DECL)).add(typeDecl_AST));
			currentAST.root = typeDecl_AST;
			currentAST.child = typeDecl_AST!=null &&typeDecl_AST.getFirstChild()!=null ?
				typeDecl_AST.getFirstChild() : typeDecl_AST;
			currentAST.advanceChildToEnd();
		}
		typeDecl_AST = (AST)currentAST.root;
		returnAST = typeDecl_AST;
	}
	
	public final void funDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST funDef_AST = null;
		
		AST tmp44_AST = null;
		tmp44_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_function);
		AST tmp45_AST = null;
		if (inputState.guessing==0) {
			tmp45_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp45_AST);
		}
		match(IDENT);
		AST tmp46_AST = null;
		tmp46_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		{
		switch ( LA(1)) {
		case IDENT:
		{
			AST tmp47_AST = null;
			if (inputState.guessing==0) {
				tmp47_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp47_AST);
			}
			match(IDENT);
			break;
		}
		case COMMA:
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop23:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp48_AST = null;
				tmp48_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				AST tmp49_AST = null;
				if (inputState.guessing==0) {
					tmp49_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp49_AST);
				}
				match(IDENT);
			}
			else {
				break _loop23;
			}
			
		} while (true);
		}
		AST tmp50_AST = null;
		tmp50_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		block();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			funDef_AST = (AST)currentAST.root;
			funDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(FUN_DEF)).add(funDef_AST));
			currentAST.root = funDef_AST;
			currentAST.child = funDef_AST!=null &&funDef_AST.getFirstChild()!=null ?
				funDef_AST.getFirstChild() : funDef_AST;
			currentAST.advanceChildToEnd();
		}
		funDef_AST = (AST)currentAST.root;
		returnAST = funDef_AST;
	}
	
	public final void lambdaDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lambdaDef_AST = null;
		
		AST tmp51_AST = null;
		tmp51_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_lambda);
		AST tmp52_AST = null;
		if (inputState.guessing==0) {
			tmp52_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp52_AST);
		}
		match(IDENT);
		AST tmp53_AST = null;
		tmp53_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		AST tmp54_AST = null;
		if (inputState.guessing==0) {
			tmp54_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp54_AST);
		}
		match(IDENT);
		{
		_loop30:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp55_AST = null;
				tmp55_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				AST tmp56_AST = null;
				if (inputState.guessing==0) {
					tmp56_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp56_AST);
				}
				match(IDENT);
			}
			else {
				break _loop30;
			}
			
		} while (true);
		}
		AST tmp57_AST = null;
		tmp57_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		AST tmp58_AST = null;
		tmp58_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_is);
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			lambdaDef_AST = (AST)currentAST.root;
			lambdaDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(LAMBDA_DEF)).add(lambdaDef_AST));
			currentAST.root = lambdaDef_AST;
			currentAST.child = lambdaDef_AST!=null &&lambdaDef_AST.getFirstChild()!=null ?
				lambdaDef_AST.getFirstChild() : lambdaDef_AST;
			currentAST.advanceChildToEnd();
		}
		lambdaDef_AST = (AST)currentAST.root;
		returnAST = lambdaDef_AST;
	}
	
	public final void actorDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST actorDef_AST = null;
		
		AST tmp59_AST = null;
		tmp59_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_actor);
		AST tmp60_AST = null;
		if (inputState.guessing==0) {
			tmp60_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp60_AST);
		}
		match(IDENT);
		AST tmp61_AST = null;
		tmp61_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		AST tmp62_AST = null;
		if (inputState.guessing==0) {
			tmp62_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp62_AST);
		}
		match(IDENT);
		{
		_loop26:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp63_AST = null;
				tmp63_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				AST tmp64_AST = null;
				if (inputState.guessing==0) {
					tmp64_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp64_AST);
				}
				match(IDENT);
			}
			else {
				break _loop26;
			}
			
		} while (true);
		}
		AST tmp65_AST = null;
		tmp65_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		AST tmp66_AST = null;
		tmp66_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_is);
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			actorDef_AST = (AST)currentAST.root;
			actorDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ACTOR_DEF)).add(actorDef_AST));
			currentAST.root = actorDef_AST;
			currentAST.child = actorDef_AST!=null &&actorDef_AST.getFirstChild()!=null ?
				actorDef_AST.getFirstChild() : actorDef_AST;
			currentAST.advanceChildToEnd();
		}
		actorDef_AST = (AST)currentAST.root;
		returnAST = actorDef_AST;
	}
	
	public final void processDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST processDef_AST = null;
		
		AST tmp67_AST = null;
		tmp67_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_process);
		AST tmp68_AST = null;
		if (inputState.guessing==0) {
			tmp68_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp68_AST);
		}
		match(IDENT);
		AST tmp69_AST = null;
		tmp69_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		{
		switch ( LA(1)) {
		case LITERAL_in:
		case LITERAL_out:
		{
			processParamKind();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp70_AST = null;
			if (inputState.guessing==0) {
				tmp70_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp70_AST);
			}
			match(IDENT);
			break;
		}
		case COMMA:
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop37:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp71_AST = null;
				tmp71_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				processParamKind();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp72_AST = null;
				if (inputState.guessing==0) {
					tmp72_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp72_AST);
				}
				match(IDENT);
			}
			else {
				break _loop37;
			}
			
		} while (true);
		}
		AST tmp73_AST = null;
		tmp73_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		{
		switch ( LA(1)) {
		case LITERAL_initial:
		{
			AST tmp74_AST = null;
			tmp74_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_initial);
			block();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case LITERAL_end:
		case LITERAL_rule:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop40:
		do {
			if ((LA(1)==LITERAL_rule)) {
				ruleDef();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop40;
			}
			
		} while (true);
		}
		AST tmp75_AST = null;
		tmp75_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_end);
		if ( inputState.guessing==0 ) {
			processDef_AST = (AST)currentAST.root;
			processDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(PROCESS_DEF)).add(processDef_AST));
			currentAST.root = processDef_AST;
			currentAST.child = processDef_AST!=null &&processDef_AST.getFirstChild()!=null ?
				processDef_AST.getFirstChild() : processDef_AST;
			currentAST.advanceChildToEnd();
		}
		processDef_AST = (AST)currentAST.root;
		returnAST = processDef_AST;
	}
	
	public final void optionList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST optionList_AST = null;
		
		AST tmp76_AST = null;
		tmp76_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_option);
		AST tmp77_AST = null;
		if (inputState.guessing==0) {
			tmp77_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp77_AST);
		}
		match(IDENT);
		{
		switch ( LA(1)) {
		case GETS:
		{
			AST tmp78_AST = null;
			tmp78_AST = (AST)astFactory.create(LT(1));
			match(GETS);
			AST tmp79_AST = null;
			if (inputState.guessing==0) {
				tmp79_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp79_AST);
			}
			match(STRING);
			break;
		}
		case SEMI:
		case COMMA:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop60:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp80_AST = null;
				tmp80_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				AST tmp81_AST = null;
				if (inputState.guessing==0) {
					tmp81_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp81_AST);
				}
				match(IDENT);
				{
				switch ( LA(1)) {
				case GETS:
				{
					AST tmp82_AST = null;
					tmp82_AST = (AST)astFactory.create(LT(1));
					match(GETS);
					AST tmp83_AST = null;
					if (inputState.guessing==0) {
						tmp83_AST = (AST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp83_AST);
					}
					match(STRING);
					break;
				}
				case SEMI:
				case COMMA:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
			}
			else {
				break _loop60;
			}
			
		} while (true);
		}
		AST tmp84_AST = null;
		tmp84_AST = (AST)astFactory.create(LT(1));
		match(SEMI);
		if ( inputState.guessing==0 ) {
			optionList_AST = (AST)currentAST.root;
			optionList_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(OPTION_LIST)).add(optionList_AST));
			currentAST.root = optionList_AST;
			currentAST.child = optionList_AST!=null &&optionList_AST.getFirstChild()!=null ?
				optionList_AST.getFirstChild() : optionList_AST;
			currentAST.advanceChildToEnd();
		}
		optionList_AST = (AST)currentAST.root;
		returnAST = optionList_AST;
	}
	
	public final void statement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST statement_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_print:
		case LITERAL_println:
		case LITERAL_return:
		case LITERAL_exit:
		case LITERAL_last:
		case LITERAL_system:
		case LITERAL_assert:
		case LITERAL_retract:
		case LITERAL_apply:
		{
			intrinsicStatement();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			statement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_if:
		{
			ifStatement();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			statement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_while:
		{
			whileStatement();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			statement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_foreach:
		{
			foreachStatement();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			statement_AST = (AST)currentAST.root;
			break;
		}
		case SEMI:
		{
			AST tmp85_AST = null;
			tmp85_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			statement_AST = (AST)currentAST.root;
			break;
		}
		default:
			boolean synPredMatched63 = false;
			if (((_tokenSet_2.member(LA(1))))) {
				int _m63 = mark();
				synPredMatched63 = true;
				inputState.guessing++;
				try {
					{
					factor();
					match(DOT);
					match(IDENT);
					actualArgs();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched63 = false;
				}
				rewind(_m63);
				inputState.guessing--;
			}
			if ( synPredMatched63 ) {
				memberFunCall();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp86_AST = null;
				tmp86_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				statement_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched65 = false;
				if (((_tokenSet_2.member(LA(1))))) {
					int _m65 = mark();
					synPredMatched65 = true;
					inputState.guessing++;
					try {
						{
						factor();
						actualArgs();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched65 = false;
					}
					rewind(_m65);
					inputState.guessing--;
				}
				if ( synPredMatched65 ) {
					call();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					AST tmp87_AST = null;
					tmp87_AST = (AST)astFactory.create(LT(1));
					match(SEMI);
					statement_AST = (AST)currentAST.root;
				}
				else if ((_tokenSet_2.member(LA(1)))) {
					assignment();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					statement_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}}
			returnAST = statement_AST;
		}
		
	public final void block() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST block_AST = null;
		
		{
		_loop33:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				statement();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop33;
			}
			
		} while (true);
		}
		AST tmp88_AST = null;
		tmp88_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_end);
		if ( inputState.guessing==0 ) {
			block_AST = (AST)currentAST.root;
			block_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(BLOCK)).add(block_AST));
			currentAST.root = block_AST;
			currentAST.child = block_AST!=null &&block_AST.getFirstChild()!=null ?
				block_AST.getFirstChild() : block_AST;
			currentAST.advanceChildToEnd();
		}
		block_AST = (AST)currentAST.root;
		returnAST = block_AST;
	}
	
/** Expression productions **
  *
  * Precedence of operators (from lowest to highest)
  * -----------------------				Associativity
  *							-------------
  *	or							L	
  *	and							L
  *	> < >= <= == !=	is (is: type equivalence operator)	L
  *	+ -							L
  *	* div mod						L
  *	- not (unary negation and logical complement)		L
  *	[] . (list indexing and attribute/method selection operators)
  *
  *	Notes:  - The above prec/assoc table (except for rel ops) is a subset 
  *		  of Java's but some names have changed for readability's sake.
  *		- and & or are NOT short circuit operators.
  *
  */
	public final void expr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_AST = null;
		
		andExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop91:
		do {
			if ((LA(1)==LITERAL_or)) {
				AST tmp89_AST = null;
				tmp89_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_or);
				andExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					expr_AST = (AST)currentAST.root;
					expr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(OR)).add(expr_AST));
					currentAST.root = expr_AST;
					currentAST.child = expr_AST!=null &&expr_AST.getFirstChild()!=null ?
						expr_AST.getFirstChild() : expr_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				break _loop91;
			}
			
		} while (true);
		}
		expr_AST = (AST)currentAST.root;
		returnAST = expr_AST;
	}
	
	public final void actorParamKind() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST actorParamKind_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_in:
		{
			AST tmp90_AST = null;
			if (inputState.guessing==0) {
				tmp90_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp90_AST);
			}
			match(LITERAL_in);
			actorParamKind_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_out:
		{
			AST tmp91_AST = null;
			if (inputState.guessing==0) {
				tmp91_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp91_AST);
			}
			match(LITERAL_out);
			actorParamKind_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = actorParamKind_AST;
	}
	
	public final void processParamKind() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST processParamKind_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_in:
		{
			AST tmp92_AST = null;
			if (inputState.guessing==0) {
				tmp92_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp92_AST);
			}
			match(LITERAL_in);
			processParamKind_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_out:
		{
			AST tmp93_AST = null;
			if (inputState.guessing==0) {
				tmp93_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp93_AST);
			}
			match(LITERAL_out);
			processParamKind_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = processParamKind_AST;
	}
	
	public final void ruleDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ruleDef_AST = null;
		
		AST tmp94_AST = null;
		tmp94_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_rule);
		AST tmp95_AST = null;
		if (inputState.guessing==0) {
			tmp95_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp95_AST);
		}
		match(IDENT);
		{
		switch ( LA(1)) {
		case LITERAL_option:
		{
			optionList();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case LITERAL_pre:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		preDef();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		postDef();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp96_AST = null;
		tmp96_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_end);
		if ( inputState.guessing==0 ) {
			ruleDef_AST = (AST)currentAST.root;
			ruleDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(RULE_DEF)).add(ruleDef_AST));
			currentAST.root = ruleDef_AST;
			currentAST.child = ruleDef_AST!=null &&ruleDef_AST.getFirstChild()!=null ?
				ruleDef_AST.getFirstChild() : ruleDef_AST;
			currentAST.advanceChildToEnd();
		}
		ruleDef_AST = (AST)currentAST.root;
		returnAST = ruleDef_AST;
	}
	
	public final void preDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST preDef_AST = null;
		
		AST tmp97_AST = null;
		tmp97_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_pre);
		{
		switch ( LA(1)) {
		case LITERAL_action:
		{
			AST tmp98_AST = null;
			tmp98_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_action);
			block();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case LPAREN:
		case LITERAL_end:
		case TILDE:
		case STRING:
		case LITERAL_system:
		case LITERAL_apply:
		case MINUS:
		case LITERAL_not:
		case LITERAL_activate:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop48:
		do {
			if ((_tokenSet_3.member(LA(1)))) {
				{
				switch ( LA(1)) {
				case TILDE:
				{
					AST tmp99_AST = null;
					if (inputState.guessing==0) {
						tmp99_AST = (AST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp99_AST);
					}
					match(TILDE);
					break;
				}
				case IDENT:
				case LITERAL_function:
				case LITERAL_lambda:
				case LITERAL_actor:
				case LITERAL_process:
				case LITERAL_concept:
				case LPAREN:
				case STRING:
				case LITERAL_system:
				case LITERAL_apply:
				case MINUS:
				case LITERAL_not:
				case LITERAL_activate:
				case NUMBER:
				case GRAPH_STRING:
				case LITERAL_file:
				case LITERAL_new:
				case LITERAL_true:
				case LITERAL_false:
				case LITERAL_number:
				case LITERAL_string:
				case LITERAL_boolean:
				case LITERAL_graph:
				case LITERAL_list:
				case LITERAL_undefined:
				case LBRACE:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				matchExpression();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop48;
			}
			
		} while (true);
		}
		AST tmp100_AST = null;
		tmp100_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_end);
		if ( inputState.guessing==0 ) {
			preDef_AST = (AST)currentAST.root;
			preDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(PRE_DEF)).add(preDef_AST));
			currentAST.root = preDef_AST;
			currentAST.child = preDef_AST!=null &&preDef_AST.getFirstChild()!=null ?
				preDef_AST.getFirstChild() : preDef_AST;
			currentAST.advanceChildToEnd();
		}
		preDef_AST = (AST)currentAST.root;
		returnAST = preDef_AST;
	}
	
	public final void postDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST postDef_AST = null;
		
		AST tmp101_AST = null;
		tmp101_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_post);
		{
		switch ( LA(1)) {
		case LITERAL_action:
		{
			AST tmp102_AST = null;
			tmp102_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_action);
			block();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case LPAREN:
		case LITERAL_end:
		case STRING:
		case LITERAL_system:
		case LITERAL_apply:
		case MINUS:
		case LITERAL_not:
		case LITERAL_activate:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop54:
		do {
			if ((_tokenSet_4.member(LA(1)))) {
				mutateKBExpression();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				{
				switch ( LA(1)) {
				case LITERAL_option:
				{
					optionList();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					break;
				}
				case IDENT:
				case LITERAL_function:
				case LITERAL_lambda:
				case LITERAL_actor:
				case LITERAL_process:
				case LITERAL_concept:
				case LPAREN:
				case LITERAL_end:
				case STRING:
				case LITERAL_system:
				case LITERAL_apply:
				case MINUS:
				case LITERAL_not:
				case LITERAL_activate:
				case NUMBER:
				case GRAPH_STRING:
				case LITERAL_file:
				case LITERAL_new:
				case LITERAL_true:
				case LITERAL_false:
				case LITERAL_number:
				case LITERAL_string:
				case LITERAL_boolean:
				case LITERAL_graph:
				case LITERAL_list:
				case LITERAL_undefined:
				case LBRACE:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
			}
			else {
				break _loop54;
			}
			
		} while (true);
		}
		AST tmp103_AST = null;
		tmp103_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_end);
		if ( inputState.guessing==0 ) {
			postDef_AST = (AST)currentAST.root;
			postDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(POST_DEF)).add(postDef_AST));
			currentAST.root = postDef_AST;
			currentAST.child = postDef_AST!=null &&postDef_AST.getFirstChild()!=null ?
				postDef_AST.getFirstChild() : postDef_AST;
			currentAST.advanceChildToEnd();
		}
		postDef_AST = (AST)currentAST.root;
		returnAST = postDef_AST;
	}
	
	public final void matchExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST matchExpression_AST = null;
		
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp104_AST = null;
		tmp104_AST = (AST)astFactory.create(LT(1));
		match(SEMI);
		if ( inputState.guessing==0 ) {
			matchExpression_AST = (AST)currentAST.root;
			matchExpression_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(MATCH_EXPRESSION)).add(matchExpression_AST));
			currentAST.root = matchExpression_AST;
			currentAST.child = matchExpression_AST!=null &&matchExpression_AST.getFirstChild()!=null ?
				matchExpression_AST.getFirstChild() : matchExpression_AST;
			currentAST.advanceChildToEnd();
		}
		matchExpression_AST = (AST)currentAST.root;
		returnAST = matchExpression_AST;
	}
	
	public final void mutateKBExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST mutateKBExpression_AST = null;
		
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp105_AST = null;
		tmp105_AST = (AST)astFactory.create(LT(1));
		match(SEMI);
		if ( inputState.guessing==0 ) {
			mutateKBExpression_AST = (AST)currentAST.root;
			mutateKBExpression_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(MUTATE_KB_EXPRESSION)).add(mutateKBExpression_AST));
			currentAST.root = mutateKBExpression_AST;
			currentAST.child = mutateKBExpression_AST!=null &&mutateKBExpression_AST.getFirstChild()!=null ?
				mutateKBExpression_AST.getFirstChild() : mutateKBExpression_AST;
			currentAST.advanceChildToEnd();
		}
		mutateKBExpression_AST = (AST)currentAST.root;
		returnAST = mutateKBExpression_AST;
	}
	
	public final void intrinsicStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST intrinsicStatement_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_print:
		{
			AST tmp106_AST = null;
			if (inputState.guessing==0) {
				tmp106_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp106_AST);
			}
			match(LITERAL_print);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp107_AST = null;
			tmp107_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_println:
		{
			AST tmp108_AST = null;
			if (inputState.guessing==0) {
				tmp108_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp108_AST);
			}
			match(LITERAL_println);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp109_AST = null;
			tmp109_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_last:
		{
			AST tmp110_AST = null;
			if (inputState.guessing==0) {
				tmp110_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp110_AST);
			}
			match(LITERAL_last);
			AST tmp111_AST = null;
			tmp111_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_system:
		{
			AST tmp112_AST = null;
			if (inputState.guessing==0) {
				tmp112_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp112_AST);
			}
			match(LITERAL_system);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp113_AST = null;
			tmp113_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_assert:
		{
			AST tmp114_AST = null;
			if (inputState.guessing==0) {
				tmp114_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp114_AST);
			}
			match(LITERAL_assert);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp115_AST = null;
			tmp115_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_retract:
		{
			AST tmp116_AST = null;
			if (inputState.guessing==0) {
				tmp116_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp116_AST);
			}
			match(LITERAL_retract);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp117_AST = null;
			tmp117_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_apply:
		{
			AST tmp118_AST = null;
			if (inputState.guessing==0) {
				tmp118_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp118_AST);
			}
			match(LITERAL_apply);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp119_AST = null;
			tmp119_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			intrinsicStatement_AST = (AST)currentAST.root;
			break;
		}
		default:
			boolean synPredMatched68 = false;
			if (((LA(1)==LITERAL_return))) {
				int _m68 = mark();
				synPredMatched68 = true;
				inputState.guessing++;
				try {
					{
					match(LITERAL_return);
					expr();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched68 = false;
				}
				rewind(_m68);
				inputState.guessing--;
			}
			if ( synPredMatched68 ) {
				AST tmp120_AST = null;
				if (inputState.guessing==0) {
					tmp120_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp120_AST);
				}
				match(LITERAL_return);
				expr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp121_AST = null;
				tmp121_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				intrinsicStatement_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==LITERAL_return)) {
				AST tmp122_AST = null;
				if (inputState.guessing==0) {
					tmp122_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp122_AST);
				}
				match(LITERAL_return);
				AST tmp123_AST = null;
				tmp123_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				intrinsicStatement_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched70 = false;
				if (((LA(1)==LITERAL_exit))) {
					int _m70 = mark();
					synPredMatched70 = true;
					inputState.guessing++;
					try {
						{
						match(LITERAL_exit);
						expr();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched70 = false;
					}
					rewind(_m70);
					inputState.guessing--;
				}
				if ( synPredMatched70 ) {
					AST tmp124_AST = null;
					if (inputState.guessing==0) {
						tmp124_AST = (AST)astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp124_AST);
					}
					match(LITERAL_exit);
					expr();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					AST tmp125_AST = null;
					tmp125_AST = (AST)astFactory.create(LT(1));
					match(SEMI);
					intrinsicStatement_AST = (AST)currentAST.root;
				}
				else if ((LA(1)==LITERAL_exit)) {
					AST tmp126_AST = null;
					if (inputState.guessing==0) {
						tmp126_AST = (AST)astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp126_AST);
					}
					match(LITERAL_exit);
					AST tmp127_AST = null;
					tmp127_AST = (AST)astFactory.create(LT(1));
					match(SEMI);
					intrinsicStatement_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}}
			returnAST = intrinsicStatement_AST;
		}
		
	public final void ifStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ifStatement_AST = null;
		
		AST tmp128_AST = null;
		tmp128_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_if);
		condition();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp129_AST = null;
		tmp129_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_then);
		block();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		switch ( LA(1)) {
		case LITERAL_else:
		{
			AST tmp130_AST = null;
			tmp130_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_else);
			block();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case EOF:
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case SEMI:
		case LITERAL_concept:
		case LITERAL_relation:
		case LPAREN:
		case LITERAL_end:
		case LITERAL_option:
		case STRING:
		case LITERAL_print:
		case LITERAL_println:
		case LITERAL_return:
		case LITERAL_exit:
		case LITERAL_last:
		case LITERAL_system:
		case LITERAL_assert:
		case LITERAL_retract:
		case LITERAL_apply:
		case LITERAL_if:
		case LITERAL_while:
		case LITERAL_foreach:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			ifStatement_AST = (AST)currentAST.root;
			ifStatement_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(IF_STATEMENT)).add(ifStatement_AST));
			currentAST.root = ifStatement_AST;
			currentAST.child = ifStatement_AST!=null &&ifStatement_AST.getFirstChild()!=null ?
				ifStatement_AST.getFirstChild() : ifStatement_AST;
			currentAST.advanceChildToEnd();
		}
		ifStatement_AST = (AST)currentAST.root;
		returnAST = ifStatement_AST;
	}
	
	public final void whileStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST whileStatement_AST = null;
		
		AST tmp131_AST = null;
		tmp131_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_while);
		condition();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp132_AST = null;
		tmp132_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_do);
		block();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			whileStatement_AST = (AST)currentAST.root;
			whileStatement_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(WHILE_STATEMENT)).add(whileStatement_AST));
			currentAST.root = whileStatement_AST;
			currentAST.child = whileStatement_AST!=null &&whileStatement_AST.getFirstChild()!=null ?
				whileStatement_AST.getFirstChild() : whileStatement_AST;
			currentAST.advanceChildToEnd();
		}
		whileStatement_AST = (AST)currentAST.root;
		returnAST = whileStatement_AST;
	}
	
	public final void foreachStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST foreachStatement_AST = null;
		
		AST tmp133_AST = null;
		tmp133_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_foreach);
		AST tmp134_AST = null;
		if (inputState.guessing==0) {
			tmp134_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp134_AST);
		}
		match(IDENT);
		AST tmp135_AST = null;
		tmp135_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_in);
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp136_AST = null;
		tmp136_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_do);
		block();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			foreachStatement_AST = (AST)currentAST.root;
			foreachStatement_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(FOREACH_STATEMENT)).add(foreachStatement_AST));
			currentAST.root = foreachStatement_AST;
			currentAST.child = foreachStatement_AST!=null &&foreachStatement_AST.getFirstChild()!=null ?
				foreachStatement_AST.getFirstChild() : foreachStatement_AST;
			currentAST.advanceChildToEnd();
		}
		foreachStatement_AST = (AST)currentAST.root;
		returnAST = foreachStatement_AST;
	}
	
	public final void factor() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST factor_AST = null;
		
		switch ( LA(1)) {
		case NUMBER:
		{
			AST tmp137_AST = null;
			if (inputState.guessing==0) {
				tmp137_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp137_AST);
			}
			match(NUMBER);
			factor_AST = (AST)currentAST.root;
			break;
		}
		case STRING:
		{
			AST tmp138_AST = null;
			if (inputState.guessing==0) {
				tmp138_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp138_AST);
			}
			match(STRING);
			factor_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_true:
		case LITERAL_false:
		{
			boolValue();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			factor_AST = (AST)currentAST.root;
			break;
		}
		case LBRACE:
		{
			listValue();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			factor_AST = (AST)currentAST.root;
			break;
		}
		case GRAPH_STRING:
		{
			graphValue();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			factor_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_new:
		{
			newValue();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			factor_AST = (AST)currentAST.root;
			break;
		}
		case IDENT:
		{
			AST tmp139_AST = null;
			if (inputState.guessing==0) {
				tmp139_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp139_AST);
			}
			match(IDENT);
			factor_AST = (AST)currentAST.root;
			break;
		}
		case LPAREN:
		{
			AST tmp140_AST = null;
			tmp140_AST = (AST)astFactory.create(LT(1));
			match(LPAREN);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp141_AST = null;
			tmp141_AST = (AST)astFactory.create(LT(1));
			match(RPAREN);
			factor_AST = (AST)currentAST.root;
			break;
		}
		default:
			boolean synPredMatched136 = false;
			if (((LA(1)==LITERAL_concept))) {
				int _m136 = mark();
				synPredMatched136 = true;
				inputState.guessing++;
				try {
					{
					match(LITERAL_concept);
					match(GRAPH_STRING);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched136 = false;
				}
				rewind(_m136);
				inputState.guessing--;
			}
			if ( synPredMatched136 ) {
				conceptValue();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				factor_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched138 = false;
				if (((LA(1)==LITERAL_file))) {
					int _m138 = mark();
					synPredMatched138 = true;
					inputState.guessing++;
					try {
						{
						match(LITERAL_file);
						factor();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched138 = false;
					}
					rewind(_m138);
					inputState.guessing--;
				}
				if ( synPredMatched138 ) {
					fileValue();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					factor_AST = (AST)currentAST.root;
				}
				else {
					boolean synPredMatched140 = false;
					if (((LA(1)==LITERAL_function))) {
						int _m140 = mark();
						synPredMatched140 = true;
						inputState.guessing++;
						try {
							{
							match(LITERAL_function);
							match(LPAREN);
							}
						}
						catch (RecognitionException pe) {
							synPredMatched140 = false;
						}
						rewind(_m140);
						inputState.guessing--;
					}
					if ( synPredMatched140 ) {
						anonFunDef();
						if (inputState.guessing==0) {
							astFactory.addASTChild(currentAST, returnAST);
						}
						factor_AST = (AST)currentAST.root;
					}
					else if ((_tokenSet_5.member(LA(1)))) {
						typeValue();
						if (inputState.guessing==0) {
							astFactory.addASTChild(currentAST, returnAST);
						}
						factor_AST = (AST)currentAST.root;
					}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}}}
				returnAST = factor_AST;
			}
			
	public final void actualArgs() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST actualArgs_AST = null;
		
		AST tmp142_AST = null;
		tmp142_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		{
		switch ( LA(1)) {
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case LPAREN:
		case STRING:
		case LITERAL_system:
		case LITERAL_apply:
		case MINUS:
		case LITERAL_not:
		case LITERAL_activate:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		{
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			break;
		}
		case COMMA:
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop81:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp143_AST = null;
				tmp143_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				expr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
			}
			else {
				break _loop81;
			}
			
		} while (true);
		}
		AST tmp144_AST = null;
		tmp144_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		if ( inputState.guessing==0 ) {
			actualArgs_AST = (AST)currentAST.root;
			actualArgs_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ACTUAL_ARGS)).add(actualArgs_AST));
			currentAST.root = actualArgs_AST;
			currentAST.child = actualArgs_AST!=null &&actualArgs_AST.getFirstChild()!=null ?
				actualArgs_AST.getFirstChild() : actualArgs_AST;
			currentAST.advanceChildToEnd();
		}
		actualArgs_AST = (AST)currentAST.root;
		returnAST = actualArgs_AST;
	}
	
	public final void memberFunCall() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST memberFunCall_AST = null;
		
		factor();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		AST tmp145_AST = null;
		tmp145_AST = (AST)astFactory.create(LT(1));
		match(DOT);
		AST tmp146_AST = null;
		if (inputState.guessing==0) {
			tmp146_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp146_AST);
		}
		match(IDENT);
		actualArgs();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			memberFunCall_AST = (AST)currentAST.root;
			memberFunCall_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(MEMBER_FUNCALL)).add(memberFunCall_AST));
			currentAST.root = memberFunCall_AST;
			currentAST.child = memberFunCall_AST!=null &&memberFunCall_AST.getFirstChild()!=null ?
				memberFunCall_AST.getFirstChild() : memberFunCall_AST;
			currentAST.advanceChildToEnd();
		}
		memberFunCall_AST = (AST)currentAST.root;
		returnAST = memberFunCall_AST;
	}
	
	public final void call() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST call_AST = null;
		
		factor();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		actualArgs();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			call_AST = (AST)currentAST.root;
			call_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CALL)).add(call_AST));
			currentAST.root = call_AST;
			currentAST.child = call_AST!=null &&call_AST.getFirstChild()!=null ?
				call_AST.getFirstChild() : call_AST;
			currentAST.advanceChildToEnd();
		}
		call_AST = (AST)currentAST.root;
		returnAST = call_AST;
	}
	
	public final void assignment() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST assignment_AST = null;
		
		boolean synPredMatched84 = false;
		if (((LA(1)==IDENT))) {
			int _m84 = mark();
			synPredMatched84 = true;
			inputState.guessing++;
			try {
				{
				match(IDENT);
				match(GETS);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched84 = false;
			}
			rewind(_m84);
			inputState.guessing--;
		}
		if ( synPredMatched84 ) {
			AST tmp147_AST = null;
			if (inputState.guessing==0) {
				tmp147_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp147_AST);
			}
			match(IDENT);
			AST tmp148_AST = null;
			tmp148_AST = (AST)astFactory.create(LT(1));
			match(GETS);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp149_AST = null;
			tmp149_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				assignment_AST = (AST)currentAST.root;
				assignment_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(VAR_ASSIGN)).add(assignment_AST));
				currentAST.root = assignment_AST;
				currentAST.child = assignment_AST!=null &&assignment_AST.getFirstChild()!=null ?
					assignment_AST.getFirstChild() : assignment_AST;
				currentAST.advanceChildToEnd();
			}
			assignment_AST = (AST)currentAST.root;
		}
		else {
			boolean synPredMatched86 = false;
			if (((_tokenSet_2.member(LA(1))))) {
				int _m86 = mark();
				synPredMatched86 = true;
				inputState.guessing++;
				try {
					{
					factor();
					match(LBRACK);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched86 = false;
				}
				rewind(_m86);
				inputState.guessing--;
			}
			if ( synPredMatched86 ) {
				factor();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp150_AST = null;
				tmp150_AST = (AST)astFactory.create(LT(1));
				match(LBRACK);
				expr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp151_AST = null;
				tmp151_AST = (AST)astFactory.create(LT(1));
				match(RBRACK);
				AST tmp152_AST = null;
				tmp152_AST = (AST)astFactory.create(LT(1));
				match(GETS);
				expr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				AST tmp153_AST = null;
				tmp153_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				if ( inputState.guessing==0 ) {
					assignment_AST = (AST)currentAST.root;
					assignment_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(LIST_ASSIGN)).add(assignment_AST));
					currentAST.root = assignment_AST;
					currentAST.child = assignment_AST!=null &&assignment_AST.getFirstChild()!=null ?
						assignment_AST.getFirstChild() : assignment_AST;
					currentAST.advanceChildToEnd();
				}
				assignment_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched88 = false;
				if (((_tokenSet_2.member(LA(1))))) {
					int _m88 = mark();
					synPredMatched88 = true;
					inputState.guessing++;
					try {
						{
						factor();
						match(DOT);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched88 = false;
					}
					rewind(_m88);
					inputState.guessing--;
				}
				if ( synPredMatched88 ) {
					factor();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					AST tmp154_AST = null;
					tmp154_AST = (AST)astFactory.create(LT(1));
					match(DOT);
					AST tmp155_AST = null;
					if (inputState.guessing==0) {
						tmp155_AST = (AST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp155_AST);
					}
					match(IDENT);
					AST tmp156_AST = null;
					tmp156_AST = (AST)astFactory.create(LT(1));
					match(GETS);
					expr();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					AST tmp157_AST = null;
					tmp157_AST = (AST)astFactory.create(LT(1));
					match(SEMI);
					if ( inputState.guessing==0 ) {
						assignment_AST = (AST)currentAST.root;
						assignment_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ATTR_ASSIGN)).add(assignment_AST));
						currentAST.root = assignment_AST;
						currentAST.child = assignment_AST!=null &&assignment_AST.getFirstChild()!=null ?
							assignment_AST.getFirstChild() : assignment_AST;
						currentAST.advanceChildToEnd();
					}
					assignment_AST = (AST)currentAST.root;
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}}
				returnAST = assignment_AST;
			}
			
	public final void condition() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST condition_AST = null;
		
		expr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			condition_AST = (AST)currentAST.root;
			condition_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CONDITION)).add(condition_AST));
			currentAST.root = condition_AST;
			currentAST.child = condition_AST!=null &&condition_AST.getFirstChild()!=null ?
				condition_AST.getFirstChild() : condition_AST;
			currentAST.advanceChildToEnd();
		}
		condition_AST = (AST)currentAST.root;
		returnAST = condition_AST;
	}
	
	public final void andExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST andExpr_AST = null;
		
		relExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop94:
		do {
			if ((LA(1)==LITERAL_and)) {
				AST tmp158_AST = null;
				tmp158_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_and);
				relExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					andExpr_AST = (AST)currentAST.root;
					andExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(AND)).add(andExpr_AST));
					currentAST.root = andExpr_AST;
					currentAST.child = andExpr_AST!=null &&andExpr_AST.getFirstChild()!=null ?
						andExpr_AST.getFirstChild() : andExpr_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				break _loop94;
			}
			
		} while (true);
		}
		andExpr_AST = (AST)currentAST.root;
		returnAST = andExpr_AST;
	}
	
	public final void relExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST relExpr_AST = null;
		
		addExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop104:
		do {
			switch ( LA(1)) {
			case GT:
			{
				{
				AST tmp159_AST = null;
				if (inputState.guessing==0) {
					tmp159_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp159_AST);
				}
				match(GT);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case LT:
			{
				{
				AST tmp160_AST = null;
				if (inputState.guessing==0) {
					tmp160_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp160_AST);
				}
				match(LT);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case GE:
			{
				{
				AST tmp161_AST = null;
				if (inputState.guessing==0) {
					tmp161_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp161_AST);
				}
				match(GE);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case LE:
			{
				{
				AST tmp162_AST = null;
				if (inputState.guessing==0) {
					tmp162_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp162_AST);
				}
				match(LE);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case EQ:
			{
				{
				AST tmp163_AST = null;
				if (inputState.guessing==0) {
					tmp163_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp163_AST);
				}
				match(EQ);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case NE:
			{
				{
				AST tmp164_AST = null;
				if (inputState.guessing==0) {
					tmp164_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp164_AST);
				}
				match(NE);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case LITERAL_is:
			{
				{
				AST tmp165_AST = null;
				tmp165_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_is);
				addExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				if ( inputState.guessing==0 ) {
					relExpr_AST = (AST)currentAST.root;
					relExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(IS)).add(relExpr_AST));
					currentAST.root = relExpr_AST;
					currentAST.child = relExpr_AST!=null &&relExpr_AST.getFirstChild()!=null ?
						relExpr_AST.getFirstChild() : relExpr_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				break _loop104;
			}
			}
		} while (true);
		}
		relExpr_AST = (AST)currentAST.root;
		returnAST = relExpr_AST;
	}
	
	public final void addExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST addExpr_AST = null;
		
		mulExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop109:
		do {
			if ((LA(1)==PLUS)) {
				{
				AST tmp166_AST = null;
				if (inputState.guessing==0) {
					tmp166_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp166_AST);
				}
				match(PLUS);
				mulExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
			}
			else if ((LA(1)==MINUS)) {
				{
				AST tmp167_AST = null;
				if (inputState.guessing==0) {
					tmp167_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp167_AST);
				}
				match(MINUS);
				mulExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
			}
			else {
				break _loop109;
			}
			
		} while (true);
		}
		addExpr_AST = (AST)currentAST.root;
		returnAST = addExpr_AST;
	}
	
	public final void mulExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST mulExpr_AST = null;
		
		unaryExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		_loop115:
		do {
			switch ( LA(1)) {
			case MUL:
			{
				{
				AST tmp168_AST = null;
				if (inputState.guessing==0) {
					tmp168_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp168_AST);
				}
				match(MUL);
				unaryExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case LITERAL_div:
			{
				{
				AST tmp169_AST = null;
				if (inputState.guessing==0) {
					tmp169_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp169_AST);
				}
				match(LITERAL_div);
				unaryExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			case LITERAL_mod:
			{
				{
				AST tmp170_AST = null;
				if (inputState.guessing==0) {
					tmp170_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp170_AST);
				}
				match(LITERAL_mod);
				unaryExpr();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				}
				break;
			}
			default:
			{
				break _loop115;
			}
			}
		} while (true);
		}
		mulExpr_AST = (AST)currentAST.root;
		returnAST = mulExpr_AST;
	}
	
	public final void unaryExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST unaryExpr_AST = null;
		
		switch ( LA(1)) {
		case MINUS:
		{
			AST tmp171_AST = null;
			if (inputState.guessing==0) {
				tmp171_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp171_AST);
			}
			match(MINUS);
			selectionExpr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			unaryExpr_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_not:
		{
			AST tmp172_AST = null;
			tmp172_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_not);
			selectionExpr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			if ( inputState.guessing==0 ) {
				unaryExpr_AST = (AST)currentAST.root;
				unaryExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NOT)).add(unaryExpr_AST));
				currentAST.root = unaryExpr_AST;
				currentAST.child = unaryExpr_AST!=null &&unaryExpr_AST.getFirstChild()!=null ?
					unaryExpr_AST.getFirstChild() : unaryExpr_AST;
				currentAST.advanceChildToEnd();
			}
			unaryExpr_AST = (AST)currentAST.root;
			break;
		}
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case LITERAL_concept:
		case LPAREN:
		case STRING:
		case LITERAL_system:
		case LITERAL_apply:
		case LITERAL_activate:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		{
			selectionExpr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			unaryExpr_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = unaryExpr_AST;
	}
	
	public final void selectionExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST selectionExpr_AST = null;
		
		callExpr();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		{
		switch ( LA(1)) {
		case LBRACK:
		{
			{
			AST tmp173_AST = null;
			tmp173_AST = (AST)astFactory.create(LT(1));
			match(LBRACK);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			AST tmp174_AST = null;
			tmp174_AST = (AST)astFactory.create(LT(1));
			match(RBRACK);
			}
			if ( inputState.guessing==0 ) {
				selectionExpr_AST = (AST)currentAST.root;
				selectionExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(LIST_SELECTION)).add(selectionExpr_AST));
				currentAST.root = selectionExpr_AST;
				currentAST.child = selectionExpr_AST!=null &&selectionExpr_AST.getFirstChild()!=null ?
					selectionExpr_AST.getFirstChild() : selectionExpr_AST;
				currentAST.advanceChildToEnd();
			}
			break;
		}
		case EOF:
		case IDENT:
		case LITERAL_function:
		case LITERAL_lambda:
		case LITERAL_actor:
		case LITERAL_process:
		case GT:
		case SEMI:
		case LITERAL_concept:
		case LITERAL_relation:
		case LPAREN:
		case COMMA:
		case RPAREN:
		case LITERAL_is:
		case LITERAL_option:
		case STRING:
		case LITERAL_print:
		case LITERAL_println:
		case LITERAL_return:
		case LITERAL_exit:
		case LITERAL_last:
		case LITERAL_system:
		case LITERAL_assert:
		case LITERAL_retract:
		case LITERAL_apply:
		case LITERAL_if:
		case LITERAL_then:
		case LITERAL_while:
		case LITERAL_do:
		case LITERAL_foreach:
		case RBRACK:
		case LITERAL_or:
		case LITERAL_and:
		case LT:
		case GE:
		case LE:
		case EQ:
		case NE:
		case PLUS:
		case MINUS:
		case MUL:
		case LITERAL_div:
		case LITERAL_mod:
		case LITERAL_not:
		case LITERAL_activate:
		case NUMBER:
		case GRAPH_STRING:
		case LITERAL_file:
		case LITERAL_new:
		case LITERAL_true:
		case LITERAL_false:
		case LITERAL_number:
		case LITERAL_string:
		case LITERAL_boolean:
		case LITERAL_graph:
		case LITERAL_list:
		case LITERAL_undefined:
		case LBRACE:
		case RBRACE:
		{
			break;
		}
		default:
			boolean synPredMatched120 = false;
			if (((LA(1)==DOT))) {
				int _m120 = mark();
				synPredMatched120 = true;
				inputState.guessing++;
				try {
					{
					match(DOT);
					match(IDENT);
					match(LPAREN);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched120 = false;
				}
				rewind(_m120);
				inputState.guessing--;
			}
			if ( synPredMatched120 ) {
				AST tmp175_AST = null;
				tmp175_AST = (AST)astFactory.create(LT(1));
				match(DOT);
				AST tmp176_AST = null;
				if (inputState.guessing==0) {
					tmp176_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp176_AST);
				}
				match(IDENT);
				actualArgs();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				if ( inputState.guessing==0 ) {
					selectionExpr_AST = (AST)currentAST.root;
					selectionExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(MEMBER_FUNCALL)).add(selectionExpr_AST));
					currentAST.root = selectionExpr_AST;
					currentAST.child = selectionExpr_AST!=null &&selectionExpr_AST.getFirstChild()!=null ?
						selectionExpr_AST.getFirstChild() : selectionExpr_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==DOT)) {
				{
				AST tmp177_AST = null;
				tmp177_AST = (AST)astFactory.create(LT(1));
				match(DOT);
				AST tmp178_AST = null;
				if (inputState.guessing==0) {
					tmp178_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp178_AST);
				}
				match(IDENT);
				}
				if ( inputState.guessing==0 ) {
					selectionExpr_AST = (AST)currentAST.root;
					selectionExpr_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ATTR_SELECTION)).add(selectionExpr_AST));
					currentAST.root = selectionExpr_AST;
					currentAST.child = selectionExpr_AST!=null &&selectionExpr_AST.getFirstChild()!=null ?
						selectionExpr_AST.getFirstChild() : selectionExpr_AST;
					currentAST.advanceChildToEnd();
				}
			}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		selectionExpr_AST = (AST)currentAST.root;
		returnAST = selectionExpr_AST;
	}
	
	public final void callExpr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST callExpr_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_system:
		{
			AST tmp179_AST = null;
			if (inputState.guessing==0) {
				tmp179_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp179_AST);
			}
			match(LITERAL_system);
			factor();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			callExpr_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_activate:
		{
			AST tmp180_AST = null;
			if (inputState.guessing==0) {
				tmp180_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp180_AST);
			}
			match(LITERAL_activate);
			factor();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			callExpr_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_apply:
		{
			AST tmp181_AST = null;
			if (inputState.guessing==0) {
				tmp181_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp181_AST);
			}
			match(LITERAL_apply);
			factor();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			factor();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			callExpr_AST = (AST)currentAST.root;
			break;
		}
		default:
			boolean synPredMatched131 = false;
			if (((_tokenSet_2.member(LA(1))))) {
				int _m131 = mark();
				synPredMatched131 = true;
				inputState.guessing++;
				try {
					{
					factor();
					actualArgs();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched131 = false;
				}
				rewind(_m131);
				inputState.guessing--;
			}
			if ( synPredMatched131 ) {
				call();
				if (inputState.guessing==0) {
					astFactory.addASTChild(currentAST, returnAST);
				}
				callExpr_AST = (AST)currentAST.root;
			}
			else {
				boolean synPredMatched133 = false;
				if (((_tokenSet_2.member(LA(1))))) {
					int _m133 = mark();
					synPredMatched133 = true;
					inputState.guessing++;
					try {
						{
						factor();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched133 = false;
					}
					rewind(_m133);
					inputState.guessing--;
				}
				if ( synPredMatched133 ) {
					factor();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
					callExpr_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}}
			returnAST = callExpr_AST;
		}
		
	public final void boolValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST boolValue_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_true:
		{
			AST tmp182_AST = null;
			if (inputState.guessing==0) {
				tmp182_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp182_AST);
			}
			match(LITERAL_true);
			boolValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_false:
		{
			AST tmp183_AST = null;
			if (inputState.guessing==0) {
				tmp183_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp183_AST);
			}
			match(LITERAL_false);
			boolValue_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = boolValue_AST;
	}
	
	public final void listValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST listValue_AST = null;
		
		boolean synPredMatched147 = false;
		if (((LA(1)==LBRACE))) {
			int _m147 = mark();
			synPredMatched147 = true;
			inputState.guessing++;
			try {
				{
				match(LBRACE);
				match(RBRACE);
				}
			}
			catch (RecognitionException pe) {
				synPredMatched147 = false;
			}
			rewind(_m147);
			inputState.guessing--;
		}
		if ( synPredMatched147 ) {
			AST tmp184_AST = null;
			tmp184_AST = (AST)astFactory.create(LT(1));
			match(LBRACE);
			AST tmp185_AST = null;
			tmp185_AST = (AST)astFactory.create(LT(1));
			match(RBRACE);
			if ( inputState.guessing==0 ) {
				listValue_AST = (AST)currentAST.root;
				listValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(EMPTY_LIST)).add(listValue_AST));
				currentAST.root = listValue_AST;
				currentAST.child = listValue_AST!=null &&listValue_AST.getFirstChild()!=null ?
					listValue_AST.getFirstChild() : listValue_AST;
				currentAST.advanceChildToEnd();
			}
			listValue_AST = (AST)currentAST.root;
		}
		else if ((LA(1)==LBRACE)) {
			AST tmp186_AST = null;
			tmp186_AST = (AST)astFactory.create(LT(1));
			match(LBRACE);
			expr();
			if (inputState.guessing==0) {
				astFactory.addASTChild(currentAST, returnAST);
			}
			{
			_loop149:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp187_AST = null;
					tmp187_AST = (AST)astFactory.create(LT(1));
					match(COMMA);
					expr();
					if (inputState.guessing==0) {
						astFactory.addASTChild(currentAST, returnAST);
					}
				}
				else {
					break _loop149;
				}
				
			} while (true);
			}
			AST tmp188_AST = null;
			tmp188_AST = (AST)astFactory.create(LT(1));
			match(RBRACE);
			if ( inputState.guessing==0 ) {
				listValue_AST = (AST)currentAST.root;
				listValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(LIST)).add(listValue_AST));
				currentAST.root = listValue_AST;
				currentAST.child = listValue_AST!=null &&listValue_AST.getFirstChild()!=null ?
					listValue_AST.getFirstChild() : listValue_AST;
				currentAST.advanceChildToEnd();
			}
			listValue_AST = (AST)currentAST.root;
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		returnAST = listValue_AST;
	}
	
	public final void graphValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST graphValue_AST = null;
		
		AST tmp189_AST = null;
		if (inputState.guessing==0) {
			tmp189_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp189_AST);
		}
		match(GRAPH_STRING);
		if ( inputState.guessing==0 ) {
			graphValue_AST = (AST)currentAST.root;
			graphValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(GRAPH_LITERAL)).add(graphValue_AST));
			currentAST.root = graphValue_AST;
			currentAST.child = graphValue_AST!=null &&graphValue_AST.getFirstChild()!=null ?
				graphValue_AST.getFirstChild() : graphValue_AST;
			currentAST.advanceChildToEnd();
		}
		graphValue_AST = (AST)currentAST.root;
		returnAST = graphValue_AST;
	}
	
	public final void conceptValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST conceptValue_AST = null;
		
		AST tmp190_AST = null;
		tmp190_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_concept);
		AST tmp191_AST = null;
		if (inputState.guessing==0) {
			tmp191_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp191_AST);
		}
		match(GRAPH_STRING);
		if ( inputState.guessing==0 ) {
			conceptValue_AST = (AST)currentAST.root;
			conceptValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CONCEPT_LITERAL)).add(conceptValue_AST));
			currentAST.root = conceptValue_AST;
			currentAST.child = conceptValue_AST!=null &&conceptValue_AST.getFirstChild()!=null ?
				conceptValue_AST.getFirstChild() : conceptValue_AST;
			currentAST.advanceChildToEnd();
		}
		conceptValue_AST = (AST)currentAST.root;
		returnAST = conceptValue_AST;
	}
	
	public final void fileValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST fileValue_AST = null;
		
		AST tmp192_AST = null;
		tmp192_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_file);
		factor();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			fileValue_AST = (AST)currentAST.root;
			fileValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(FILE_VALUE)).add(fileValue_AST));
			currentAST.root = fileValue_AST;
			currentAST.child = fileValue_AST!=null &&fileValue_AST.getFirstChild()!=null ?
				fileValue_AST.getFirstChild() : fileValue_AST;
			currentAST.advanceChildToEnd();
		}
		fileValue_AST = (AST)currentAST.root;
		returnAST = fileValue_AST;
	}
	
	public final void anonFunDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST anonFunDef_AST = null;
		
		AST tmp193_AST = null;
		tmp193_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_function);
		AST tmp194_AST = null;
		tmp194_AST = (AST)astFactory.create(LT(1));
		match(LPAREN);
		{
		switch ( LA(1)) {
		case IDENT:
		{
			AST tmp195_AST = null;
			if (inputState.guessing==0) {
				tmp195_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp195_AST);
			}
			match(IDENT);
			break;
		}
		case COMMA:
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop156:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp196_AST = null;
				tmp196_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				AST tmp197_AST = null;
				if (inputState.guessing==0) {
					tmp197_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp197_AST);
				}
				match(IDENT);
			}
			else {
				break _loop156;
			}
			
		} while (true);
		}
		AST tmp198_AST = null;
		tmp198_AST = (AST)astFactory.create(LT(1));
		match(RPAREN);
		block();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			anonFunDef_AST = (AST)currentAST.root;
			anonFunDef_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ANON_FUN_DEF)).add(anonFunDef_AST));
			currentAST.root = anonFunDef_AST;
			currentAST.child = anonFunDef_AST!=null &&anonFunDef_AST.getFirstChild()!=null ?
				anonFunDef_AST.getFirstChild() : anonFunDef_AST;
			currentAST.advanceChildToEnd();
		}
		anonFunDef_AST = (AST)currentAST.root;
		returnAST = anonFunDef_AST;
	}
	
	public final void newValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST newValue_AST = null;
		
		AST tmp199_AST = null;
		tmp199_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_new);
		factor();
		if (inputState.guessing==0) {
			astFactory.addASTChild(currentAST, returnAST);
		}
		if ( inputState.guessing==0 ) {
			newValue_AST = (AST)currentAST.root;
			newValue_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NEW_VALUE)).add(newValue_AST));
			currentAST.root = newValue_AST;
			currentAST.child = newValue_AST!=null &&newValue_AST.getFirstChild()!=null ?
				newValue_AST.getFirstChild() : newValue_AST;
			currentAST.advanceChildToEnd();
		}
		newValue_AST = (AST)currentAST.root;
		returnAST = newValue_AST;
	}
	
	public final void typeValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST typeValue_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_number:
		{
			AST tmp200_AST = null;
			if (inputState.guessing==0) {
				tmp200_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp200_AST);
			}
			match(LITERAL_number);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_string:
		{
			AST tmp201_AST = null;
			if (inputState.guessing==0) {
				tmp201_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp201_AST);
			}
			match(LITERAL_string);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_boolean:
		{
			AST tmp202_AST = null;
			if (inputState.guessing==0) {
				tmp202_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp202_AST);
			}
			match(LITERAL_boolean);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_concept:
		{
			AST tmp203_AST = null;
			if (inputState.guessing==0) {
				tmp203_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp203_AST);
			}
			match(LITERAL_concept);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_graph:
		{
			AST tmp204_AST = null;
			if (inputState.guessing==0) {
				tmp204_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp204_AST);
			}
			match(LITERAL_graph);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_list:
		{
			AST tmp205_AST = null;
			if (inputState.guessing==0) {
				tmp205_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp205_AST);
			}
			match(LITERAL_list);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_function:
		{
			AST tmp206_AST = null;
			if (inputState.guessing==0) {
				tmp206_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp206_AST);
			}
			match(LITERAL_function);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lambda:
		{
			AST tmp207_AST = null;
			if (inputState.guessing==0) {
				tmp207_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp207_AST);
			}
			match(LITERAL_lambda);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_actor:
		{
			AST tmp208_AST = null;
			if (inputState.guessing==0) {
				tmp208_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp208_AST);
			}
			match(LITERAL_actor);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_process:
		{
			AST tmp209_AST = null;
			if (inputState.guessing==0) {
				tmp209_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp209_AST);
			}
			match(LITERAL_process);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_file:
		{
			AST tmp210_AST = null;
			if (inputState.guessing==0) {
				tmp210_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp210_AST);
			}
			match(LITERAL_file);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_undefined:
		{
			AST tmp211_AST = null;
			if (inputState.guessing==0) {
				tmp211_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp211_AST);
			}
			match(LITERAL_undefined);
			typeValue_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = typeValue_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"OPTION_LIST",
		"TYPE_DECL",
		"VALUE_SELECTOR",
		"BLOCK",
		"IF_STATEMENT",
		"WHILE_STATEMENT",
		"FOREACH_STATEMENT",
		"CONDITION",
		"FUN_DEF",
		"ANON_FUN_DEF",
		"LAMBDA_DEF",
		"ACTOR_DEF",
		"PROCESS_DEF",
		"RULE_DEF",
		"PRE_DEF",
		"MATCH_EXPRESSION",
		"MUTATE_KB_EXPRESSION",
		"POST_DEF",
		"CALL",
		"ACTUAL_ARGS",
		"VAR_ASSIGN",
		"ATTR_ASSIGN",
		"LIST_ASSIGN",
		"MEMBER_FUNCALL",
		"ATTR_SELECTION",
		"LIST_SELECTION",
		"LIST",
		"CONCEPT_LITERAL",
		"GRAPH_LITERAL",
		"FILE_VALUE",
		"NEW_VALUE",
		"EMPTY_LIST",
		"TYPE_VALUE",
		"AND",
		"OR",
		"IS",
		"NOT",
		"IDENT",
		"\"function\"",
		"\"lambda\"",
		"\"actor\"",
		"\"process\"",
		"GT",
		"SEMI",
		"\"concept\"",
		"\"relation\"",
		"LPAREN",
		"COMMA",
		"RPAREN",
		"\"is\"",
		"\"in\"",
		"\"out\"",
		"\"end\"",
		"\"initial\"",
		"\"rule\"",
		"\"pre\"",
		"\"action\"",
		"TILDE",
		"\"post\"",
		"\"option\"",
		"GETS",
		"STRING",
		"DOT",
		"\"print\"",
		"\"println\"",
		"\"return\"",
		"\"exit\"",
		"\"last\"",
		"\"system\"",
		"\"assert\"",
		"\"retract\"",
		"\"apply\"",
		"\"if\"",
		"\"then\"",
		"\"else\"",
		"\"while\"",
		"\"do\"",
		"\"foreach\"",
		"LBRACK",
		"RBRACK",
		"\"or\"",
		"\"and\"",
		"LT",
		"GE",
		"LE",
		"EQ",
		"NE",
		"PLUS",
		"MINUS",
		"MUL",
		"\"div\"",
		"\"mod\"",
		"\"not\"",
		"\"activate\"",
		"NUMBER",
		"GRAPH_STRING",
		"\"file\"",
		"\"new\"",
		"\"true\"",
		"\"false\"",
		"\"number\"",
		"\"string\"",
		"\"boolean\"",
		"\"graph\"",
		"\"list\"",
		"\"undefined\"",
		"LBRACE",
		"RBRACE",
		"COLON",
		"LETTER",
		"DIGIT",
		"METACHAR",
		"WS",
		"COMMENT"
	};
	
	private static final long _tokenSet_0_data_[] = { -9221192804808523776L, 140720308658170L, 0L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 1616282092830720L, 140720308658170L, 0L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 1475544604475392L, 140720308486146L, 0L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	private static final long _tokenSet_3_data_[] = { 2307318553818169344L, 140733461825794L, 0L, 0L };
	public static final BitSet _tokenSet_3 = new BitSet(_tokenSet_3_data_);
	private static final long _tokenSet_4_data_[] = { 1475544604475392L, 140733461825794L, 0L, 0L };
	public static final BitSet _tokenSet_4 = new BitSet(_tokenSet_4_data_);
	private static final long _tokenSet_5_data_[] = { 347445674377216L, 69337952026624L, 0L, 0L };
	public static final BitSet _tokenSet_5 = new BitSet(_tokenSet_5_data_);
	
	}
