/*
 * An abstract class for multiplexing a vector of 7-segment LEDs.
 *
 * This class permits the separation of 2 concerns: LED vector display,
 * and what data is to be displayed. Application code can focus upon the
 * latter.
 *
 * A specified port is used to drive each segment in a single 7-segment
 * LED unit, while another is used to multiplex up to as many 7-segment
 * LED units as there are pins on the port.
 *
 * A decimal point on a specified LED unit may also be controlled
 * independently upon each LED vector multiplex.
 *
 * Notes:
 *
 * - muxPins.length dictates the number of LED units/digits.
 *
 * David Benn, September 2004
 */

package quark;

import stamp.core.CPU;

abstract public class SevenSegLEDMux {

    public final static int POINT_NOT_USED = -1;

    // Data and multiplexing ports.
    protected int dataPort;
    protected int muxPort;

    // Data and multiplexing pins.
    protected int[] dataPins;
    protected int[] muxPins;

    // Pointer to a vector of 7-segment LED units.
    protected char[] ledVector;

    // A string buffer for use when storing data into the LED vector.
    private StringBuffer buf;

    // The control pin for the right point on a 7-seg LED unit.
    protected int pointPin;

    // The on-time for each 7-segment LED unit in milliseconds
    // during multiplexing.
    protected int onTime;

    // Constructor.
    public SevenSegLEDMux(int dataPort,
                          int[] dataPins,
                          int pointPin,
                          int muxPort,
                          int[] muxPins,
                          int onTime) {
      this.dataPort = dataPort;
      this.dataPins = dataPins;
      this.pointPin = pointPin;
      this.muxPort = muxPort;
      this.muxPins = muxPins;
      this.ledVector = new char[muxPins.length];
      this.buf = new StringBuffer(muxPins.length);
      this.onTime = onTime;
    }

    /**
      * Set the value to be displayed given an integer.
      * The value is truncated if necessary.
      */
    public void setValue(int value) {
      buf.clear();
      buf.append(value);
      char[] bufArray = buf.toString().toCharArray();
      // Convert from ASCII characters to digits,
      // copying into our buffer with truncate.
      for (int i=0;i<ledVector.length && i < bufArray.length;i++) {
        ledVector[i] = (char) (bufArray[i] - '0');
      }
    }

    /**
     * Display the current vector.
     */
    abstract public void display();

    /**
     * Display the current vector also setting
     * the decimal point on one 7-seg LED unit.
     */
    abstract public void display(int unit);

    /**
     * Turn off all segments and select no 7-seg LED unit.
     */
    abstract public void blank();
}