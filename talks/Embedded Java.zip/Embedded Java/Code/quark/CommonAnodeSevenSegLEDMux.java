/*
 * A class for multiplexing a vector of common anode 7-segment LEDs.
 *
 * This class permits the separation of 2 concerns: LED vector display,
 * and what data is to be displayed. Application code can focus upon the
 * latter.
 *
 * A specified port is used to drive each segment in a single 7-segment
 * LED unit, while another is used to multiplex up to as many 7-segment
 * LED units as there are pins on the port in use.
 *
 * Segments may be arbitrarily wired with up to 256 (!) patterns per
 * 7-segment LED unit. The caller is responsible for specifying these
 * patterns and for setting the value to be displayed on the 7-segment
 * LED unit vector.
 *
 * A decimal point on a specified LED unit may also be controlled
 * independently upon each LED vector multiplex.
 *
 * Notes:
 *
 * - We would like to prevent pre-existing port data from being
 *   clobbered below. This is true for data port writes and mux
 *   port writes in blank().
 *
 * David Benn, September 2004
 */

package quark;

import stamp.core.CPU;
import quark.SevenSegLEDMux;

public class CommonAnodeSevenSegLEDMux extends SevenSegLEDMux {

    // Pointer to a vector of segment patterns.
    private char[] segPatterns;

    // Constructors.

    public CommonAnodeSevenSegLEDMux(int dataPort,
                                     int[] dataPins,
                                     int pointPin,
                                     int muxPort,
                                     int[] muxPins,
                                     int onTime,
                                     char[] segPatterns) {
        super(dataPort, dataPins, pointPin, muxPort, muxPins, onTime);

        this.segPatterns = segPatterns;

        // Set up data and point pins for output-low.
        for (int i=0;i<dataPins.length;i++) {
            CPU.writePin(dataPins[i], false);
        }

        if (pointPin != POINT_NOT_USED) {
            CPU.writePin(pointPin, false);
        }

        // Set up mux pins for output-high.
        for (int i=0;i<muxPins.length;i++) {
            CPU.writePin(muxPins[i], true);
        }

        blank();
    }

    /**
     * Display the current vector.
     */
    public void display() {
        for (int i=0;i<ledVector.length;i++) {
            CPU.writePort(dataPort, (byte) segPatterns[ledVector[i]]);
            CPU.writePin(muxPins[i], true); // high = on
            CPU.delay(onTime);
            CPU.writePin(muxPins[i], false); // low = off
        }
    }

    /**
     * Display the current vector also setting
     * the decimal point on one 7-seg LED unit.
     */
    public void display(int unit) {
        for (int i=0;i<ledVector.length;i++) {
            CPU.writePort(dataPort, (byte) segPatterns[ledVector[i]]);
            if (pointPin != POINT_NOT_USED && i == unit) {
                CPU.writePin(pointPin, false); // low = on
            } else {
                CPU.writePin(pointPin, true);  // high = off
            }
            CPU.writePin(muxPins[i], true); // high = on
            CPU.delay(onTime);
            CPU.writePin(muxPins[i], false); // low = off
        }
    }

    /**
     * Turn off all segments and select no 7-seg LED unit.
     */
    public void blank() {
        CPU.writePort(dataPort, (byte) 0xff);
        for (int i=0;i<muxPins.length;i++) {
            CPU.writePin(muxPins[i], false);
        }
    }
}