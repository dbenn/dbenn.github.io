// A digital thermometer using a DS1620 and a multiplexed
// 7-segment LED array. Accuracy is to one half of a degree.
//
// DS1620: DQ = P15 (via 1K resistor), CLK = P14, RST = P13.
// 7-seg array: cathode (data) pins 0..7, anode (select) pins 8..10.
//
// David Benn, September 2004

import quark.CommonAnodeSevenSegLEDMux;
import quark.SevenSegLEDMux;

import stamp.core.CPU;
import stamp.core.Timer;
import stamp.peripheral.sensor.temperature.DS1620;

public class Thermometer {

  // DS1620 values.
  private final static int DQ = CPU.pin15;
  private final static int CLK = CPU.pin14;
  private final static int RST = CPU.pin13;

  // 7-segment LED values.
  private final static int[] dataPins = {
        CPU.pin0, CPU.pin1, CPU.pin2, CPU.pin3,
        CPU.pin4, CPU.pin5, CPU.pin6, CPU.pin7
  };

  private final static int POINT_PIN = CPU.pin5;

  private final static int[] muxPins = {
      CPU.pin8, CPU.pin9, CPU.pin10
  };

  private final static int LED_MUX_ON_TIME = 50; // 50*95.48 ~ 4775 us

  private final static char[] segments = {
        0x28, // 0
        0xED, // 1
        0x34, // 2
        0xA4, // 3
        0xE1, // 4
        0xA2, // 5
        0x23, // 6
        0xEC, // 7
        0x20, // 8
        0xA0, // 9
  };

  private final static int ONE_SECOND = 10473;

  public static void main() {
    Timer timer = new Timer();
    timer.mark();

    DS1620 tempSensor = new DS1620(DQ, CLK, RST);

    SevenSegLEDMux leds =
      new CommonAnodeSevenSegLEDMux(CPU.PORTA, dataPins, POINT_PIN,
                                    CPU.PORTB, muxPins,
                                    LED_MUX_ON_TIME,
                                    segments);

    leds.setValue(getDegsCBy10(tempSensor));

    while(true) {
      // If one second has elapsed, get the temperature again.
      // Note: Entering this block without refreshing the display
      // causes a noticeable flicker. We could also invoke leds.display(1)
      // from within getDegsCBy10().
      if (timer.timeout(1000)) {
        timer.mark();
        leds.display(1);
        leds.setValue(getDegsCBy10(tempSensor));
        leds.display(1);
      }

      // Display temperature in degrees C to nearest half degree,
      // setting the (right) decimal point on the second unit from
      // right (since 7-segment LED units are numbered 0..2).
      leds.display(1);
    }
  }

  // Return temperature in degrees C to nearest half a
  // degree from DS1620 sensor, multiplied by 10 for
  // display purposes.
  private static int getDegsCBy10(DS1620 tempSensor) {
    int rawDegsC = tempSensor.getTempRaw();
    int degsC = rawDegsC >> 1;

    if (hasHalfDegreeComponent(rawDegsC)) {
      degsC = degsC * 10 + 5;
    } else {
      degsC = degsC * 10;
    }

    return degsC;
  }

  // If the raw degrees value has its LSB set, this represents
  // a half a degree.
  private static boolean hasHalfDegreeComponent(int rawDegs) {
    return (rawDegs & 0x01) == 1;
  }
}
