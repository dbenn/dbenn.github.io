; Java interop examples (Swing)

(import '(java.awt Color Graphics))
(import '(java.util Random))
(import '(javax.swing JComponent JFrame))

(defn make-frame [title left top width height]
  (doto (new JFrame title)
    (setBounds left top width height)))

(defn draw-line [x1 y1 x2 y2]
  (let [frame (make-frame "My Frame with a Line" 10 10 400 400) 
	canvas (proxy [JComponent] []
		      (paintComponent [gfx]
				      (. gfx (setColor Color/red))
				      (. gfx (drawLine x1 y1 x2 y2))))]
    (. frame (add canvas))
    (. frame (setVisible true))))

(draw-line 10 20 200 200)

(defn abs [n] (if (< n 0) (- n) n))

(defn rng [max] 
  (fn [] (let [r (new Random)] 
	   (abs (rem (. r nextInt) max)))))

(defn draw-random-lines [title left top width height num-lines color]
  (let [frame (make-frame title left top width height) 
	canvas (proxy 
		[JComponent] [] 
		(paintComponent [gfx]
				(. gfx (setColor color))
				(loop [i 0
				       x1 (rng width)
				       y1 (rng height)
				       x2 (rng width)
				       y2 (rng height)]
				  (. gfx (drawLine (x1) (y1) (x2) (y2)))
				  (if (< i num-lines) 
				    (recur (+ i 1)
					   x1
					   y1
					   x2
					   y2)))))]
    (. frame (add canvas))
    (. frame (setVisible true))))

(draw-random-lines "My Frame with Random Lines" 10 10 400 400 20 Color/magenta)
      
