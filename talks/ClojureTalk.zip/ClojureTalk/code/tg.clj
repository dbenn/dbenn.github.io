; Turtle Graphics Java interop.
;
; Invoke this script with something like:
;   java -cp $CLOJURE_JAR:. clojure.lang.Script "$@"

(import '(tg TGFrame))
(import '(java.awt Color))

(defmacro turn [frame heading] `(. ~frame (turn ~heading)))

(defmacro walk [frame steps] `(. ~frame (walk ~steps)))

(defn tree-helper [frame n]
  (if (>= n 5)
    (do
      (turn frame 30) (walk frame n)
      (tree-helper frame (* n 0.75))
      (walk frame (- n)) (turn frame (- 60))
      (walk frame n) (tree-helper frame (* n 0.75))
      (walk frame (- n)) (turn frame 30))))

(defn tree [len]
  (let [frame (new TGFrame "Tree" 10 10 400 400)]
    (tree-helper frame len)))

(tree 35)
