package tg;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JFrame;

/**
 * This class provides simple drawing and Turtle Graphics capabilities.
 */
public class TGFrame extends JFrame {
	private int x, y; // turtle's position
	private int angle; // turtle's angle
	private TGCanvas c;
	private Color color;

	public TGFrame(String title, int left, int top, int width, int height) {
		super(title);
		x = width / 2;
		y = height / 2;
		angle = 270; // point north
		c = new TGCanvas();
		this.add(c);
		this.setBounds(left, top, width, height);
		this.addWindowListener(new TGFrameListener());
		this.setVisible(true);
		color = c.getGraphics().getColor();
	}

	// --- General gfx methods ---

	public void setColor(Color color) {
		c.setForeground(color);
		this.color = color;
	}

	public void drawLine(int x1, int y1, int x2, int y2) {
		c.getGraphics().drawLine(x1, y1, x2, y2);
		c.lines.add(new Line(x1, y1, x2, y2, color));
	}

	// --- Turtle Graphics methods ---

	public void moveTo(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void lineTo(int x, int y) {
		drawLine(this.x, this.y, x, y);
		this.x = x;
		this.y = y;
	}

	public void turn(int degrees) {
		angle += degrees;
	}

	public void walk(int steps) {
		double theta = degs2rads(angle);
		int newX = (int) Math.round(this.x + steps * Math.cos(theta)); // fix!
		int newY = (int) Math.round(this.y + steps * Math.sin(theta)); // fix!
		drawLine(this.x, this.y, newX, newY);
		this.x = newX;
		this.y = newY;
	}

	private double degs2rads(int angle) {
		return angle / 57.295779;
	}
}

class TGFrameListener extends WindowAdapter {
	// Close and dispose the window upon a close request.
	public void windowClosing(WindowEvent e) {
		Window w = e.getWindow();
		w.setVisible(false);
		w.dispose();
	}
}

class TGCanvas extends JComponent {
	public List<Line> lines; // the lines on this canvas

	TGCanvas() {
		lines = new ArrayList<Line>();
	}

	public void paint(Graphics g) {
		// Draw all stored lines when the canvas needs repainting.
		for (Line line : lines) {
			g.setColor(line.color);
			g.drawLine(line.x1, line.y1, line.x2, line.y2);
		}
	}
}

class Line {
	public int x1, y1, x2, y2;
	public Color color;

	Line(int x1, int y1, int x2, int y2, Color color) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.color = color;
	}
}
